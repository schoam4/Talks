###############################
### MLM Day 4               ###
### KU Workshops 2023       ###
### Alexander Schoemann     ###
###############################

### Handling Nested Data ###

## Load packages needed
library(lme4)
library(lmerTest)
library(clubSandwich)
library(dplyr)


##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)

##Disaggregated regression

m1 <- lm(langpost ~ iq_verb, data=SB)
summary(m1)

##Aggregated regression

#use aggregate function to compute group means

langpost<-aggregate(SB$langpost, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)
iq_verb<-aggregate(SB$iq_verb, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)

grpmeans <- data.frame(cbind(langpost$x, iq_verb$x))
names(grpmeans) <- c('langpost', 'iq_verb')

summary(grpmeans)

m2 <- lm(langpost~iq_verb, data=grpmeans)
summary(m2)

##Adjusting standard errors

## use clubSandwich package
# Uses the lm() results
coef_test(m1, vcov = "CR2", 
          cluster = SB$schoolnr, test = "Satterthwaite")

##Fixed effects approach
m4 <- lm(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m4)

##ANCOVA (same as fixed effects approach)
m5 <- aov(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m5)


##Seperate regressions

mL <- lmList(langpost~iq_verb|schoolnr, data=SB, 
             pool=FALSE, na.action=na.omit)
summary(mL)

#Get mean intercept and across schools
colMeans(coef(mL))

#Plot seperate regression lines for all schools
plot(SB$iq_verb, SB$langpost, xlab = "iq_verb", ylab = "langpost", type = 'n')

for(i in 1:dim(coef(mL))[[1]]){
  abline(coef=coef(mL)[i,])
  
}

##Multilevel models

m6 <- lmer(langpost~ 1 + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m6)

#compute ICC
19.43/(64.57+19.43)

m6v <- lmer(iq_verb~ 1 + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m6v)

.5062/(.5062+3.8341)

### Adding Predictors ###

#fixed L1 predictor
m7 <- lmer(langpost~ 1 + iq_verb + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor

m8 <- lmer(langpost ~ 1 + iq_verb + (1+iq_verb|schoolnr), 
           data = SB, REML = FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m8, correlation = FALSE)

#Compare model with fixed and random slopes

anova(m7, m8)

#use ranova to test random effects
ranova(m8)

#confidence interval for all effects
confint(m8)

confint(m8, level = .90)

#fixed L2 predictor
m9 <- lmer(langpost~1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)

#Try to make it random (DON'T DO THIS!!!!!!)
m9d <- lmer(langpost~1 + percmino + (1 +percmino|schoolnr), 
           data = SB, REML = FALSE)
summary(m9d)

#random l1 and fixed L2 predictor

m10 <- lmer(langpost ~ 1 + iq_verb + percmino + sex + (1|schoolnr), 
            data = SB, REML = FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m10)

m11 <- lmer(langpost ~ 1 + iq_verb + percmino + sex + (1+iq_verb|schoolnr), 
            data = SB, REML = FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m11)

m12 <- lmer(langpost ~ 1 + iq_verb + percmino + sex + 
              (1+iq_verb + sex|schoolnr), 
            data = SB, REML = FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))

summary(m12)

anova(m10, m11, m12)

ranova(m12)

## Effect sizes

#Level specific r2 "by hand" for random slopes model
(64.57- 41.48)/64.57
(19.43 - 65.882)/19.43

# For R2 measures use the performance package
library(performance)

# Overall R2 conditional and marginal
r2(m7)
r2(m8)
r2(m9)

# Level specific R2
r2(m7, by_group = TRUE)
r2(m8, by_group = TRUE) #Doesn't make sense with random slopes!
r2(m9, by_group = TRUE)

# Rights and Sterba R2 from r2mlm
library(r2mlm)

r2mlm(m7)
r2mlm(m8)
r2mlm(m9)

r2mlm(m12)

#compare r2
r2mlm_comp(m7, m8) ## needs group mean centering

#standardized mean difference
m10 <- lmer(langpost~1 + sex + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m10)

sd(SB$langpost)

#use total SD for y
2.5679/9.003676

#use L1 SD for y
2.5679/8.035

# Standardized slopes

# Standardize outcomes and predictors

SB$langpostS <- scale(SB$langpost)
SB$iq_verbS <- scale(SB$iq_verb)
SB$percminoS <- scale(SB$percmino)

# Fit models with L1 and L2 predictors
# DO NOT USE THESE FOR HYPOTHESIS TESTING!
m7S <- lmer(langpostS~1 + iq_verbS + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m7S)

m9S <- lmer(langpostS~1 + percminoS + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9S)

m10S <- lmer(langpostS~1 + iq_verb + percminoS + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m10S)

# Use Hox (2010) computations from raw models

#Slope of verbal IQ
fixef(m7)

#SD verbal IQ
sd(SB$iq_verb)

#SD langpost
sd(SB$langpost)

#Standardized slope
(2.488094*2.06889)/9.003676

## Visualize random effects 

## pull out random effects

randE <- ranef(m12)

head(randE)

## dotplot
library(lattice)
dotplot(randE)

## use ggplot
library(ggplot2)
dd <- as.data.frame(randE)
  ggplot(dd, aes(y=grp,x=condval)) +
    geom_point() + facet_wrap(~term,scales="free_x") +
    geom_errorbarh(aes(xmin=condval -2*condsd,
                       xmax=condval +2*condsd), height=0)


### Centering ###

mean(SB$iq_verb, na.omit = TRUE)
  
# Grand mean centering
SB <- mutate(SB, IQV_CGM = iq_verb - 11.83406) 
  
SB <- mutate(SB, IQV_CGM2 = iq_verb - mean(SB$iq_verb))
  
# Group mean centering
#Use summarise command to compute group means
grpmeans<-summarise(group_by(SB, schoolnr), IQ_GM = mean(iq_verb))
grpmeans
  
##Merge group means back to data set by school (L2 unit)
SB<-merge(SB,grpmeans,by="schoolnr")
head(SB)
summary(SB)

# Group mean center
SB<- mutate(SB, IQV_CWC = (iq_verb - IQ_GM))
head(SB)
summary(SB)
  
#Uncentered
m1 <- lmer(langpost ~ 1 + iq_verb + (1 + iq_verb|schoolnr), 
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m1)
  
#Grand mean centered
m1Grand <- lmer(langpost ~ 1 + IQV_CGM + (1 + IQV_CGM|schoolnr),
                data=SB, REML=FALSE)
summary(m1Grand)
  
#Group mean centered
m1Group <- lmer(langpost ~ 1 + IQV_CWC + (1 + IQV_CWC|schoolnr), 
                data=SB, REML=FALSE)
summary(m1Group)
  
#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1 + IQV_CWC|schoolnr), 
                     data=SB, REML=FALSE)
summary(m1AddMeans)
ranova(m1AddMeans)

##Compare fixed effects...
fixEFF <-rbind(c(fixef(m1),NA),c(fixef(m1Grand),NA),c(fixef(m1Group),NA),fixef(m1AddMeans))
rownames(fixEFF) <- c("uncentered", "Grand Mean Centered", "Group Mean Centered", "Group Mean Centered with means")
colnames(fixEFF)[3] <- "Grp Mean iq_verb"
fixEFF
  
# Center the group means
SB <- mutate(SB, IQV_GMC = IQ_GM - mean(SB$IQ_GM))
#Group mean centered with means added back in Group means centered
m1AddMeans2 <- lmer(langpost ~ 1 + IQV_CWC + IQV_GMC + 
                      (1 + IQV_CWC|schoolnr), 
                      data=SB, REML=FALSE)
summary(m1AddMeans2)
  
  
# Conditional Value centering
SB <- mutate(SB, IQV_CONDV = iq_verb - 8)
  
m1Cond <- lmer(langpost ~ 1 + IQV_CONDV + 
               (1 + IQV_CONDV|schoolnr), 
               data=SB, REML=FALSE, 
               control = lmerControl(optimizer="Nelder_Mead"))
summary(m1Cond)
  
SB <- mutate(SB, IQV_CONDV2 = iq_verb - 13)

## Effect sizes  
r2(m1)
r2(m1Grand)
r2(m1Group)
r2(m1AddMeans)
  

r2mlm(m1)
r2mlm(m1Grand)
r2mlm(m1Group)
r2mlm(m1AddMeans)
  
r2mlm_comp(m1Group, m1AddMeans)
  
#Refit without random slopes
#Uncentered
m1 <- lmer(langpost ~ 1 + iq_verb + (1 |schoolnr), 
           data=SB, REML=FALSE)
summary(m1)
  
#Grand mean centered
m1Grand <- lmer(langpost ~ 1 + IQV_CGM + (1 |schoolnr),
                data=SB, REML=FALSE)
summary(m1Grand)
  
#Group mean centered
m1Group <- lmer(langpost ~ 1 + IQV_CWC + (1 |schoolnr), 
                data=SB, REML=FALSE)
summary(m1Group)
  
#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                       (1|schoolnr), data=SB, REML=FALSE)
summary(m1AddMeans)
r2(m1, by_group = TRUE)
r2(m1Grand, by_group = TRUE)
r2(m1Group, by_group = TRUE)
r2(m1AddMeans, by_group = TRUE)
  