###############################
####Exercises               ###
### KU Workshops 2023       ###
### Alexander Schoemann     ###
###############################


## Fitting CFAs (slide 144 Day 1)

library(psychTools)
library(lavaan)
library(semTools)


modEx1 <- '
EAl =~ energetic + vigorous + wakeful +wide.awake + full.of.pep
TAl =~ intense + jittery + fearful + tense + clutched.up

'

fitEx1 <- cfa(modEx1, data = msq, std.lv = TRUE)
summary(fitEx1, fit.measures = TRUE, standardized = TRUE)

modificationIndices(fitEx1, sort. = TRUE)


modEx2 <- '
EAl =~ energetic + vigorous + wakeful +wide.awake + full.of.pep
TAl =~ intense + jittery + fearful + tense + clutched.up
wakeful ~~  wide.awake
'

fitEx2 <- cfa(modEx2, data = msq, std.lv = TRUE)
summary(fitEx2, fit.measures = TRUE, standardized = TRUE)
modificationIndices(fitEx2, sort. = TRUE)


## Multiple Groups (slide 186 Day 1)

#configural model
modEx3 <- '
EAl =~ energetic + vigorous + wakeful +wide.awake + full.of.pep
TAl =~ intense + jittery + fearful + tense + clutched.up
'

fitEx3 <- cfa(modEx3, data = msqR, std.lv = TRUE, group = "form")
summary(fitEx3, fit.measures = TRUE, standardized = TRUE)
modificationIndices(fitEx3, sort. = TRUE)

#Add residual covariance of wakefull and wide.awake, estimated in both groups
modEx4 <- '
EAl =~ energetic + vigorous + wakeful +wide.awake + full.of.pep
TAl =~ intense + jittery + fearful + tense + clutched.up
wakeful ~~ wide.awake
'

fitEx4 <- cfa(modEx4, data = msqR, std.lv = TRUE, group = "form")
summary(fitEx4, fit.measures = TRUE, standardized = TRUE)
modificationIndices(fitEx3, sort. = TRUE)


# Weak invariance model
fitEx4w <- cfa(modEx4, data = msqR, std.lv = TRUE, group = "form",
               group.equal = c("loadings"))
summary(fitEx4w, fit.measures = TRUE, standardized = TRUE)
#model comparison, significant Chi-square but based on RMSEA of the difference
#and change in CFI, we have weak invariance
summary(compareFit(config = fitEx4, weak = fitEx4w))


# Strong invariance model
fitEx4s <- cfa(modEx4, data = msqR, std.lv = TRUE, group = "form",
               group.equal = c("loadings", "intercepts"))
summary(fitEx4s, fit.measures = TRUE, standardized = TRUE)
#model comparison, significant Chi-square but based on RMSEA of the difference
#and change in CFI, we have strong invariance
summary(compareFit(config = fitEx4, weak = fitEx4w, strong = fitEx4s))

# Mean invariance model
fitEx4m <- cfa(modEx4, data = msqR, std.lv = TRUE, group = "form",
               group.equal = c("loadings", "intercepts", "means"))
summary(fitEx4m, fit.measures = TRUE, standardized = TRUE)
#model comparison, significant Chi-square. Some means differ between groups
summary(compareFit(config = fitEx4, weak = fitEx4w, strong = fitEx4s, means = fitEx4m))
# Look at strong invariance model for mean differences. Means in group two
# are difference from 0, both means are significant. EA mean is higher in group 2
# TA mean is lower in group two

# Variance invariance model
fitEx4v <- cfa(modEx4, data = msqR, std.lv = TRUE, group = "form",
               group.equal = c("loadings", "intercepts", "lv.variances"))
summary(fitEx4v, fit.measures = TRUE, standardized = TRUE)
#model comparison, significant Chi-square. Some variances differ between groups
summary(compareFit(config = fitEx4, weak = fitEx4w, strong = fitEx4s, vars = fitEx4v))

## Phantom variable model to test covariance
modEx4ph <- '
EAl =~ energetic + vigorous + wakeful +wide.awake + full.of.pep
TAl =~ intense + jittery + fearful + tense + clutched.up
EAph =~ c(1,NA)*EAl
TAph =~ c(1,NA)*TAl

EAl ~~ 0*EAl
TAl ~~ 0*TAl
EAph ~~ 1*EAph
TAph ~~ 1*TAph

EAl ~~ 0*TAl
EAph ~~ 0*TAl
TAph ~~ 0*EAl
EAph ~~ TAph

EAph ~ 0*1
TAph ~ 0*1

wakeful ~~ wide.awake
'

# Phantom variable model
fitEx4ph <- cfa(modEx4ph, data = msqR, std.lv = TRUE, group = "form",
               group.equal = c("loadings", "intercepts"),
               group.partial = c('EAph =~ EAl', 'TAph =~ TAl'))
summary(fitEx4ph, fit.measures = TRUE, standardized = TRUE)

#Test latent corelations
fitEx4phc <- cfa(modEx4ph, data = msqR, std.lv = TRUE, group = "form",
                group.equal = c("loadings", "intercepts", 'lv.covariances'),
                group.partial = c('EAph =~ EAl', 'TAph =~ TAl'))
summary(fitEx4phc, fit.measures = TRUE, standardized = TRUE)
anova(fitEx4ph, fitEx4phc)
#Significant model comparison correlations differ between groups


## Power and sample size (slide 53 Day 2)


PopModEX <- 'F1 =~ .75*v1 + .75*v2 + .75*v3 + .75*v4 
F2 =~ .75*v5 + .75*v6 + .75*v7 + .75*v8 
F3 =~ .75*v9 + .75*v10 + .75*v11 + .75*v12
F1 ~~ 1*F1
F2 ~~ 1*F2
F3 ~~ 1*F3
F1 ~~ .3*F2
F1 ~~ .45*F3
F2 ~~ .3*F3

v1 ~~ .56*v1
v2 ~~ .56*v2
v3 ~~ .56*v3
v4 ~~ .56*v4
v5 ~~ .56*v5
v6 ~~ .56*v6
v7 ~~ .56*v7
v8 ~~ .56*v8
v9 ~~ .56*v9
v10 ~~ .56*v10
v11 ~~ .56*v11
v12 ~~ .56*v12
'

##Specify analysis model. The model we want to fit

AnModEX <- 'F1 =~ v1 + v2 + v3 + v4 
F2 =~ v5 + v6 + v7 + v8 
F3 =~ v9 + v10 + v11 + v12
'
##Run simulation with 50 reps for example. Normally you want more (1000+)!
outEX1 <- sim(nRep=50, model=AnModEX, n = 225, 
              generate = PopModEX, lavaanfun = "cfa", 
              std.lv = TRUE)

summary(outEX1)

##Run simulation with 50 reps for example. Normally you want more (1000+)!
outEX2 <- sim(nRep=50, model=AnModEX, n = 300, 
              generate = PopModEX, lavaanfun = "cfa", 
              std.lv = TRUE)

summary(outEX2)

##Run simulation with 50 reps for example. Normally you want more (1000+)!
outEX3 <- sim(nRep=50, model=AnModEX, n = 450, 
              generate = PopModEX, lavaanfun = "cfa", 
              std.lv = TRUE)

summary(outEX3)

## Mediation models (slide 86 Day 2)

datEX <- read.csv("ps4.csv")

#First fit a CFA
modEx5 <- '
TP =~ TP1 + TP2 + TP3 + TP4
OSE =~ OSE1 + OSE2 + OSE3 
PAL =~ PAL1 + PAL2 + PAL3 + PAL4 + PAL5
'

fitEx5 <- cfa(modEx5, data = datEX, std.lv = TRUE)
summary(fitEx5, fit.measures = TRUE, standardized = TRUE)

#Mediation model
modEx5m <- '
TP =~ TP1 + TP2 + TP3 + TP4
OSE =~ OSE1 + OSE2 + OSE3 
PAL =~ PAL1 + PAL2 + PAL3 + PAL4 + PAL5
OSE ~ a*TP
PAL ~ b*OSE + TP

ab := a*b
'

fitEx5m <- cfa(modEx5m, data = datEX, std.lv = TRUE)
summary(fitEx5m, fit.measures = TRUE, standardized = TRUE)

#Test indirect effect with Monte Carlo CI
monteCarloCI(object = fitEx5m, nRep = 100000)
#Significant indirect effect

## Longitudinal Models (slide 123 Day 2) 

#Code from Day2_code.R
library(psychTools)
#Put sai dataset into the enviornment
data(sai)

#Select the "SAM" study
saiSAM <- sai[sai$study == "SAM",]

#use reshape for converting to wide format

saiWide <- reshape(saiSAM, direction = "wide", 
                   idvar = "id", 
                   timevar = "time")
summary(saiWide)

## Set null model
modEx6null <-'
pleasant.1 ~~ v1*pleasant.1
rested.1 ~~ v2*rested.1
calm.1 ~~ v3*calm.1
secure.1 ~~ v4*secure.1
nervous.1 ~~ v5*nervous.1
upset.1 ~~ v6*upset.1
worrying.1 ~~ v7*worrying.1
rattled.1 ~~ v8*rattled.1

pleasant.3 ~~ v1*pleasant.3
rested.3 ~~ v2*rested.3
calm.3 ~~ v3*calm.3
secure.3 ~~ v4*secure.3
nervous.3 ~~ v5*nervous.3
upset.3 ~~ v6*upset.3
worrying.3 ~~ v7*worrying.3
rattled.3 ~~ v8*rattled.3

pleasant.1 ~ t1*1
rested.1 ~ t2*1
calm.1 ~ t3*1
secure.1 ~ t4*1
nervous.1 ~ t5*1
upset.1 ~ t6*1
worrying.1 ~ t7*1
rattled.1 ~ t8*1

pleasant.3 ~ t1*1
rested.3 ~ t2*1
calm.3 ~ t3*1
secure.3 ~ t4*1
nervous.3 ~ t5*1
upset.3 ~ t6*1
worrying.3 ~ t7*1
rattled.3 ~ t8*1
'
fitEx6null <- cfa(modEx6null, data=saiWide, meanstructure=TRUE, std.lv=TRUE)



#Configural invariance
modEx6 <- '
peace1 =~ pleasant.1 + rested.1 + calm.1 + secure.1
anx1 =~ nervous.1 + upset.1 + worrying.1 + rattled.1

peace3 =~ pleasant.3 + rested.3 + calm.3 + secure.3
anx3 =~ nervous.3 + upset.3 + worrying.3 + rattled.3

#Residual covariances
pleasant.1 ~~ pleasant.3
rested.1 ~~ rested.3
calm.1 ~~ calm.3
secure.1 ~~ secure.3
nervous.1 ~~ nervous.3
upset.1 ~~ upset.3
worrying.1 ~~ worrying.3
rattled.1 ~~ rattled.3
'
fitEx6 <- cfa(modEx6, data = saiWide, std.lv = TRUE, meanstructure = TRUE)
summary(fitEx6, fit.measures = TRUE, standardized = TRUE)
#Fit with correct null model:
fitmeasures(fitEx6, baseline.model = fitEx6null)

modificationindices(fitEx6, sort. = TRUE)


#Weak invariance
modEx6w <- '
peace1 =~ l1*pleasant.1 + l2*rested.1 + l3*calm.1 + l4*secure.1
anx1 =~ l5*nervous.1 + l6*upset.1 + l7*worrying.1 + l8*rattled.1

peace3 =~ l1*pleasant.3 + l2*rested.3 + l3*calm.3 + l4*secure.3
anx3 =~ l5*nervous.3 + l6*upset.3 + l7*worrying.3 + l8*rattled.3

#Residual covariances
pleasant.1 ~~ pleasant.3
rested.1 ~~ rested.3
calm.1 ~~ calm.3
secure.1 ~~ secure.3
nervous.1 ~~ nervous.3
upset.1 ~~ upset.3
worrying.1 ~~ worrying.3
rattled.1 ~~ rattled.3

#Free variances at time 2
peace3 ~~ NA*peace3
anx3 ~~ NA*anx3
'
fitEx6w <- cfa(modEx6w, data = saiWide, std.lv = TRUE, meanstructure = TRUE)
summary(fitEx6w, fit.measures = TRUE, standardized = TRUE)
summary(compareFit(config = fitEx6, weak = fitEx6w, baseline.model = fitEx6null))
#Based on change in CFI and RMSEA of the difference weak invariance holds

#Strong invariance
modEx6s <- '
peace1 =~ l1*pleasant.1 + l2*rested.1 + l3*calm.1 + l4*secure.1
anx1 =~ l5*nervous.1 + l6*upset.1 + l7*worrying.1 + l8*rattled.1

peace3 =~ l1*pleasant.3 + l2*rested.3 + l3*calm.3 + l4*secure.3
anx3 =~ l5*nervous.3 + l6*upset.3 + l7*worrying.3 + l8*rattled.3

#Residual covariances
pleasant.1 ~~ pleasant.3
rested.1 ~~ rested.3
calm.1 ~~ calm.3
secure.1 ~~ secure.3
nervous.1 ~~ nervous.3
upset.1 ~~ upset.3
worrying.1 ~~ worrying.3
rattled.1 ~~ rattled.3

#Free variances at time 2
peace3 ~~ NA*peace3
anx3 ~~ NA*anx3

#constrain intercepts

pleasant.1 ~ t1*1
rested.1 ~ t2*1
calm.1 ~ t3*1
secure.1 ~ t4*1
nervous.1 ~ t5*1
upset.1 ~ t6*1
worrying.1 ~ t7*1
rattled.1 ~ t8*1

pleasant.3 ~ t1*1
rested.3 ~ t2*1
calm.3 ~ t3*1
secure.3 ~ t4*1
nervous.3 ~ t5*1
upset.3 ~ t6*1
worrying.3 ~ t7*1
rattled.3 ~ t8*1

## Free latent means
peace3 ~ NA*1
anx3 ~ NA*1


'
fitEx6s <- cfa(modEx6s, data = saiWide, std.lv = TRUE)
summary(fitEx6s, fit.measures = TRUE, standardized = TRUE)
summary(compareFit(config = fitEx6, weak = fitEx6w,
                   strong = fitEx6s, baseline.model = fitEx6null))
#Based on change in CFI and RMSEA of the difference strong invariance holds

## Panel Model
modEx6p <- '
peace1 =~ l1*pleasant.1 + l2*rested.1 + l3*calm.1 + l4*secure.1
anx1 =~ l5*nervous.1 + l6*upset.1 + l7*worrying.1 + l8*rattled.1

peace3 =~ l1*pleasant.3 + l2*rested.3 + l3*calm.3 + l4*secure.3
anx3 =~ l5*nervous.3 + l6*upset.3 + l7*worrying.3 + l8*rattled.3

#Residual covariances
pleasant.1 ~~ pleasant.3
rested.1 ~~ rested.3
calm.1 ~~ calm.3
secure.1 ~~ secure.3
nervous.1 ~~ nervous.3
upset.1 ~~ upset.3
worrying.1 ~~ worrying.3
rattled.1 ~~ rattled.3

#Free variances at time 2
peace3 ~~ NA*peace3
anx3 ~~ NA*anx3

#constrain intercepts

pleasant.1 ~ t1*1
rested.1 ~ t2*1
calm.1 ~ t3*1
secure.1 ~ t4*1
nervous.1 ~ t5*1
upset.1 ~ t6*1
worrying.1 ~ t7*1
rattled.1 ~ t8*1

pleasant.3 ~ t1*1
rested.3 ~ t2*1
calm.3 ~ t3*1
secure.3 ~ t4*1
nervous.3 ~ t5*1
upset.3 ~ t6*1
worrying.3 ~ t7*1
rattled.3 ~ t8*1

## Free latent means
peace3 ~ NA*1
anx3 ~ NA*1

peace3 ~ peace1 + anx1
anx3 ~ anx1 + peace1

'
fitEx6p <- cfa(modEx6p, data = saiWide, std.lv = TRUE)
summary(fitEx6p, fit.measures = TRUE, standardized = TRUE)
