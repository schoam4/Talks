###############################
### SEM Day 2               ###
### KU Workshops 2023       ###
### Alexander Schoemann     ###
###############################

####Load packages for today
library(lavaan)
library(semPlot)
library(semTools)
library(psych)
library(Amelia)
library(mice)
library(simsem)
library(rockchalk)

### Missing Data

################################################################################
## data preparation
################################################################################

#Read data in (same as parcels data)
dat2 <- read.csv('Lec5.Parcel.csv')

## look at data
summary(dat2)
round(cor(dat2), 3)

################################################################################
## Fit CFA to unparceled data
################################################################################

mod81 <- 'Positive =~ great + cheerful + happy + good + glad + super
          Negative =~ sad + down + unhappy + blue + bad + terrible 
          '

fit81 <-  cfa(mod81, data=dat2, std.lv=TRUE)

summary(fit81, standardized=TRUE, fit.measures=TRUE)

semPaths(fit81, 'est')


################################################################################
## Fit CFA to unparceled data - 20% missing MCAR
################################################################################

#Read data in (same as parcels data)
dat3 <- read.csv('Lec5.Parcel.MCAR.csv')


## look at data
summary(dat3)
cor(dat3)
?cor
round(cor(dat3, use="complete.obs"),3)

#Fit with listwise deletion (lavaan default)
mod82 <- 'Positive =~ great + cheerful + happy + good + glad + super
          Negative =~ sad + down + unhappy + blue + bad + terrible 
          '

fit82 <-  cfa(mod82, data=dat3, std.lv=TRUE)

summary(fit82, standardized=TRUE, fit.measures=TRUE)

## Pairwise deletion

covPair <- cov(dat3, use = "pairwise.complete.obs")

fit82p <-  cfa(mod82, sample.cov=covPair, 
               sample.nobs = 759*.8, std.lv=TRUE)

summary(fit82p, standardized=TRUE, fit.measures=TRUE)


#Fit with FIML
fit83 <-  cfa(mod82, data=dat3, std.lv=TRUE, 
              missing='ml')

summary(fit83, standardized=TRUE, fit.measures=TRUE)
summary(fit81, standardized=TRUE, fit.measures=TRUE)

parameterEstimates(fit81)
parameterEstimates(fit83)

################################################################################
## Fit CFA to unparceled data - 20% missing MAR (based on great)
################################################################################

#Read data in (same as parcels data)
dat4 <- read.csv('Lec5.Parcel.MAR.csv')


## look at data
summary(dat4)
round(cor(dat4, use="complete.obs"),3)

#Fit with listwise deletion (lavaan default)
mod84 <- 'Positive =~ great + cheerful + happy + good + glad + super
          Negative =~ sad + down + unhappy + blue + bad + terrible 
          '

fit84 <-  cfa(mod84, data=dat4, std.lv=TRUE)

summary(fit84, standardized=TRUE, fit.measures=TRUE)

#Pairwise deletion
covPair2 <- cov(dat4, use = "pairwise.complete.obs")

fit84p <-  cfa(mod82, sample.cov=covPair, sample.nobs = 759, std.lv=TRUE)

summary(fit84p, standardized=TRUE, fit.measures=TRUE)

#Fit with FIML
fit85 <-  cfa(mod84, data=dat4, std.lv=TRUE, missing='fiml')

summary(fit85, standardized=TRUE, fit.measures=TRUE)
summary(fit81, standardized=TRUE, fit.measures=TRUE)


#Example using auxiliary variables. Pretend good is an auxiliary variable
mod84a <- 'Positive =~ cheerful + happy + glad + super +  great
          Negative =~ terrible + sad + down + unhappy + blue + bad   

'
fitAux <- cfa.auxiliary(mod84a, dat4, c("good"), std.lv = TRUE)
summary(fitAux, standardized=TRUE, fit.measures=TRUE)

##impute data using Amelia
#Only using 5 imputations to save time!
set.seed(12345)
imps <- amelia(dat4, m=5)

#Fit model with runMI (or in this case cfa.mi)
fit86 <- cfa.mi(mod84, data=imps$imputations, 
                std.lv=TRUE)
summary(fit86, standardized=TRUE, fmi = TRUE)
fitmeasures(fit86)

#Can do imputations and model fitting in one function call
#NOT recommended
fit86a <- cfa.mi(mod84, data=dat4, m = 5, 
                 std.lv=TRUE)
summary(fit86a, standardized=TRUE, fmi = TRUE)

#### Power

################################################################################
## Power: Satorra & Sarris method
################################################################################

# Use SSpower in semTools

##Specify population model. All fixed parameters
PopMod <- '
F1 =~ .7*v1 + .7*v2 + .7*v3 + .7*v4 + .7*v5
F2 =~ .7*v6 + .7*v7 + .7*v8 + .7*v9 + .7*v10
F1 ~~ 1*F1
F2 ~~ 1*F2
F1 ~~ .235*F2

v1 ~~ .51*v1
v2 ~~ .51*v2
v3 ~~ .51*v3
v4 ~~ .51*v4
v5 ~~ .51*v5
v6 ~~ .51*v6
v7 ~~ .51*v7
v8 ~~ .51*v8
v9 ~~ .51*v9
v10 ~~ .51*v10
'

#Specificy analysis model, parameter of interest fixed to 0
model <- '
f1 =~ v1 + v2 + v3 + v4 + v5
f2 =~ v6 + v7 + v8 + v9 + v10
f1 ~~ 0*f2
'

SSpower(model, 220, 1, PopMod)


################################################################################
## Power: Monte Carlo method (using simsem package)
################################################################################

##Specify population model. All fixed parameters

PopMod <- 'F1 =~ .7*v1 + .7*v2 + .7*v3 + .7*v4 + .7*v5
F2 =~ .7*v6 + .7*v7 + .7*v8 + .7*v9 + .7*v10
F1 ~~ 1*F1
F2 ~~ 1*F2
F1 ~~ .235*F2

v1 ~~ .51*v1
v2 ~~ .51*v2
v3 ~~ .51*v3
v4 ~~ .51*v4
v5 ~~ .51*v5
v6 ~~ .51*v6
v7 ~~ .51*v7
v8 ~~ .51*v8
v9 ~~ .51*v9
v10 ~~ .51*v10
'

##Specify analysis model. The model we want to fit

AnMod <- 'F1 =~ v1 + v2 + v3 + v4 + v5
F2 =~ v6 + v7 + v8 + v9 + v10
'

##Run simulation with 50 reps for example. Normally you want more (1000+)!
out <- sim(nRep=50, model=AnMod, n = 220, 
           generate = PopMod, lavaanfun = "cfa", 
           std.lv = TRUE)

summary(out)

#### Structural Models


################################################################################
## data preparation
################################################################################

## Data is in a tab delimited file with no names

dat <- read.table("11.Grade7.dat")

# This assigns names to each column in dat
names(dat) <- c("Agency1","Agency2","Agency3",
                "Intrin1","Intrin2","Intrin3",
                "Extrin1","Extrin2","Extrin3",
                "PosAFF1","PosAFF2","PosAFF3",
                "NegAFF1","NegAFF2","NegAFF3",
                "Gender","School2","School3","School4")

## Create scale scores for OLS regression

dat$AgencyO <- (dat$Agency1 + dat$Agency2 + dat$Agency3)/3
dat$IntrinO <- (dat$Intrin1 + dat$Intrin2 + dat$Intrin3)/3
dat$ExtrinO <- (dat$Extrin1 + dat$Extrin2 + dat$Extrin3)/3
dat$PosAFFO <- (dat$PosAFF1 + dat$PosAFF2 + dat$PosAFF3)/3
dat$NegAFFO <- (dat$NegAFF1 + dat$NegAFF2 + dat$NegAFF3)/3

################################################################################
## Example Path model predicting positive affect
################################################################################

mod70 <- lm(PosAFFO ~ AgencyO + IntrinO + ExtrinO, data=dat)
summary(mod70)
standardize(mod70)

mod71 <- '
PosAFFO ~ AgencyO + IntrinO + ExtrinO
'

fit71 <- sem(mod71, data = dat, fixed.x=FALSE)
summary(fit71, fit.measures=TRUE, standardized=TRUE)
#Get r^2
lavInspect(fit71, 'r2')


################################################################################
## Example Always start with a CFA
################################################################################
mod72 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
            Extrin =~ Extrin1 + Extrin2 + Extrin3
            Positive =~ PosAFF1 + PosAFF2 + PosAFF3
            '

fit72 <- cfa(mod72, data=dat, std.lv=TRUE)

summary(fit72, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example Change CFA to Structural (Latent) Regression
################################################################################
mod73 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
						Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3

            Positive ~ Agency + Intrin + Extrin
'

fit73 <- sem(mod73, data=dat, std.lv=TRUE)

summary(fit73, standardized=TRUE, fit.measures=TRUE)

lavInspect(fit73, 'r2')

semPaths(fit73)

################################################################################
## Example Add Negative Affect
################################################################################
mod74 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
						Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

            Positive ~ Agency + Intrin + Extrin
            Negative ~ Agency + Intrin + Extrin
						'

fit74 <- sem(mod74, data=dat, std.lv=TRUE)

summary(fit74, standardized=TRUE, fit.measures=TRUE)

lavInspect(fit74, 'r2')

## Are slopes different between positive and negative affect?
mod74e <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ b1*AgencyL + b2*IntrinL + b3*ExtrinL
            NegativeL ~ b4*AgencyL + b5*IntrinL + b6*ExtrinL
            
            diffA := b1 - b4
            diffI := b2 - b5
            diffE := b3 - b6
'

fit74e <- sem(mod74e, data=dat, std.lv=TRUE)

summary(fit74e, standardized=TRUE, fit.measures=TRUE)

# Positive predict negative
mod74p <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ PositiveL
						'

fit74p <- sem(mod74p, data=dat, std.lv=TRUE)
summary(fit74p, standardized=TRUE, fit.measures=TRUE)

# Negative predict positive
mod74n <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ AgencyL + IntrinL + ExtrinL
            PositiveL ~ NegativeL
						'

fit74n <- sem(mod74n, data=dat, std.lv=TRUE)
summary(fit74n, standardized=TRUE, fit.measures=TRUE)

anova(fit74, fit74p, fit74n)

################################################################################
## Example 7.5 -- Trim Non-Significant Paths
################################################################################
mod75 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						PositiveL ~ AgencyL + IntrinL
						NegativeL ~ ExtrinL
						'

fit75 <- sem(mod75, data=dat, std.lv=TRUE)

summary(fit75, standardized=TRUE, fit.measures=TRUE)

#Compare to unpruned model
anova(fit74, fit75)


################################################################################
## Example 7.6 -- Introduce Covariates, regress all constructs on them
################################################################################
mod76 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						AgencyL ~ Gender + School2 + School3 + School4
						IntrinL ~ Gender + School2 + School3 + School4
						ExtrinL ~ Gender + School2 + School3 + School4
						PositiveL ~ AgencyL + IntrinL + Gender + School2 + School3 + School4
						NegativeL ~ ExtrinL + Gender + School2 + School3 + School4
						'

fit76 <- sem(mod76, data=dat, std.lv=TRUE, fixed.x=TRUE)

summary(fit76, standardized=TRUE, fit.measures=TRUE)


#Gender: 1 = Girl

################################################################################
## Example 7.7 -- Trim Non-Significant Paths (again)
################################################################################
mod77 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
  					ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						IntrinL ~ Gender + School3 
						ExtrinL ~ Gender
						PositiveL ~ AgencyL + IntrinL 
						NegativeL ~ ExtrinL + Gender + School2 
           '

fit77 <-  sem(mod77, data=dat, std.lv=TRUE, fixed.x=FALSE)

summary(fit77, standardized=TRUE, fit.measures=TRUE)

anova(fit76, fit77)#Don't do this models contain different variables!


################################################################################
## Example 7.8 -- Covariate Controls as Semi-Partial Effects
################################################################################
mod78 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
  					ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						PositiveL ~ AgencyL + IntrinL + Gender + School2 + School3 + School4
						NegativeL ~ ExtrinL + Gender + School2 + School3 + School4
						'

fit78 <- sem(mod78, data=dat, std.lv=TRUE)

summary(fit78, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example 7.9 -- Covariate Controls as indirect Effects
################################################################################
mod79 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
  					ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						AgencyL ~ Gender + School2 + School3 + School4
						IntrinL ~ Gender + School2 + School3 + School4
						ExtrinL ~ Gender + School2 + School3 + School4
						PositiveL ~ AgencyL + IntrinL
						NegativeL ~ ExtrinL
						'

fit79 <- sem(mod79, data=dat, std.lv=TRUE)

summary(fit79, standardized=TRUE, fit.measures=TRUE)

#### Mediation

################################################################################
## data preparation
################################################################################

## read raw data file for mediation model
dat <- read.csv("mediation.csv")



################################################################################
## example Structural Regression, with Agency as auxiliary covariate
## C PATHWAY
################################################################################
mod91 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## Covariances
      Agency ~~ Intrin
      Positive ~~ Agency
# Regression
      Positive ~ Intrin
'

fit91 <- sem(mod91, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit91, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Mediation model
################################################################################
mod92 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent regression
      Agency ~ a*Intrin
      Positive ~ b*Agency + cprime*Intrin
## Define indirect effect
ab := a*b
tot := a*b + cprime
'

fit92 <- sem(mod92, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit92, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping
#Only  500 bootstraps to save time. Usually use 1000+
fit92b <- sem(mod92, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit92b, standardized=TRUE, fit.measures=TRUE)


#Get bootstrapped CI
parameterEstimates(fit92b)

summary(fit92b, fit.measures=TRUE, ci = TRUE)

##Monte Carlo CI

#If you provide the function with a lavaan object it 
# finds parameters with given names


monteCarloCI("a*b", object=fit92, plot=TRUE,
              rep = 1000000)


################################################################################
## example Structural Regression, with Intrinsic as auxiliary covariate
################################################################################
mod93 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
      Agency ~~ Intrin
      Positive ~~ Intrin
## latent regression
      Positive ~ Agency
'

fit93 <- sem(mod93, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit93, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Mediation model with Intrisic as the mediator
################################################################################
mod94 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent regression
      Intrin ~ a*Agency
      Positive ~ b*Intrin + Agency

ab := a*b
'

fit94 <- sem(mod94, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping

fit94b <- sem(mod94, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit94b, standardized=TRUE, fit.measures=TRUE)

parameterEstimates(fit94b)

summary(fit92b, fit.measures=TRUE, ci = TRUE)


#### Moderation

##Demonstrate that different types of centering give you the same thing

dat <- genCorrelatedData(1000, stde=5)

m1 <- lm(y ~ x1 * x2, data=dat)
summary(m1)

m1mc <- meanCenter(m1)
summary(m1mc)

m1rc <- residualCenter(m1)
summary(m1rc)

#Orthogonalize "by hand"
dat$x1x2 <- dat$x1*dat$x2
dat$x1x2o <- resid(lm(x1x2 ~ x1 + x2, data=dat))

summary(dat)
round(cor(dat),4)

m2 <- lm(y ~ x1 + x2 + x1x2o, data=dat)
summary(m2)


##Read in data
dat2 <- read.csv('moderation.csv')

##Create data with orthogonalized terms

dat3 <- indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
                c('meUNK1', 'meUNK2', 'meUNK3'), 
                match=FALSE,
                meanC = FALSE, residualC = TRUE,
                namesProd = c('int1', 'int2', 'int3', 'int4', 'int5',
                              'int6', 'int7', 'int8', 'int9'))

summary(dat3)
round(cor(dat3), 3)

################################################################################
## example "Main effect" Model
################################################################################
mod95a <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
    		Positive =~ PosAFF1 + PosAFF2 + PosAFF3
#Latent regression
				Positive ~ Agency + Unknown 
'

fit95a <- sem(mod95a, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit95a, fit.measures=TRUE)

################################################################################
## example Moderation model Orthogonalizing
################################################################################
mod95 <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
				Interact =~ int1 + int2 + int3 + int4 + int5 + int6 + int7 + int8 + int9
				Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
				Agency ~~ Unknown
				Agency ~~ 0*Interact
				Unknown ~~ 0*Interact
## latent regression
				Positive ~ Agency + Unknown + Interact
## correlated residuals
				int2 ~~ T1*int1
				int3 ~~ T1*int1
				int3 ~~ T1*int2
				int5 ~~ T2*int4
				int6 ~~ T2*int4
				int6 ~~ T2*int5
				int8 ~~ T3*int7
				int9 ~~ T3*int7
				int9 ~~ T3*int8
				int4 ~~ T4*int1
				int7 ~~ T4*int4
				int7 ~~ T4*int1
				int5 ~~ T5*int2
				int8 ~~ T5*int5
				int8 ~~ T5*int2
				int6 ~~ T6*int3
				int9 ~~ T6*int6
				int9 ~~ T6*int3
'

fit95 <- sem(mod95, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit95, fit.measures=TRUE)


################################################################################
## example Moderation model Double Mean Centering
################################################################################

dat4 <-indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
               c('meUNK1', 'meUNK2', 'meUNK3'), 
               meanC=FALSE, doubleMC =TRUE, 
               namesProd = c('int1', 'int2', 'int3'))

mod96 <- '
## define latent variables
Agency =~ agATT1 + agATT2 + agATT3
Unknown =~ meUNK1 + meUNK2 + meUNK3
Interact =~ int1 + int2 + int3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
Agency ~~ Unknown
Agency ~~ Interact
Unknown ~~ Interact
## latent regression
Positive ~ Agency + Unknown + Interact
'

fit96 <- sem(mod96, data=dat4, std.lv=TRUE, meanstructure=TRUE)

summary(fit96, fit.measures=TRUE)


##Create data with all possible double mean centered terms

dat5 <- indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
                c('meUNK1', 'meUNK2', 'meUNK3'), 
                match=FALSE,
                meanC = FALSE, doubleMC = TRUE,
                namesProd = c('int1', 'int2', 'int3', 'int4', 'int5',
                              'int6', 'int7', 'int8', 'int9'))

summary(dat5)
round(cor(dat3), 3)

mod97 <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
				Interact =~ int1 + int2 + int3 + int4 + int5 + int6 + int7 + int8 + int9
				Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
				Agency ~~ Unknown
				Agency ~~ Interact
				Unknown ~~ Interact
## latent regression
				Positive ~ Agency + Unknown + Interact
## correlated residuals
				int2 ~~ T1*int1
				int3 ~~ T1*int1
				int3 ~~ T1*int2
				int5 ~~ T2*int4
				int6 ~~ T2*int4
				int6 ~~ T2*int5
				int8 ~~ T3*int7
				int9 ~~ T3*int7
				int9 ~~ T3*int8
				int4 ~~ T4*int1
				int7 ~~ T4*int4
				int7 ~~ T4*int1
				int5 ~~ T5*int2
				int8 ~~ T5*int5
				int8 ~~ T5*int2
				int6 ~~ T6*int3
				int9 ~~ T6*int6
				int9 ~~ T6*int3
'

fit97 <- sem(mod97, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit97, fit.measures=TRUE)


##Probing interactions

probed <-probe2WayRC(fit95, nameX=c('Agency', 'Unknown', 'Interact'), 
                     nameY='Positive', modVar='Unknown', c(-1, 0, 1))
probed

probe2WayMC(fit96, nameX=c('Agency', 'Unknown', 'Interact'), 
            nameY='Positive', modVar='Unknown', c(-1,1))

plotProbe(probed, c(-1,1))


##### USE nlsem? ######

library(nlsem)


## Use : to indicate interaction between latent variables
## ONLY works with nlsem
mod97 <- '
## define latent variables
Agency =~ agATT1 + agATT2 + agATT3
Unknown =~ meUNK1 + meUNK2 + meUNK3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3

Agency ~~ Unknown
Agency ~~ 1*Agency
Unknown ~~ 1*Unknown

## latent regression
Positive ~ Agency + Unknown + Agency:Unknown

'

#Convert to nlsem model
mod97a<-lav2nlsem(mod97)

#Specify starting values, using random starts here, not a great choice
set.seed(110)
start1 <- runif(count_free_parameters(mod97a))
#Fit model, take a long time. Run several times with better start values
fit97 <- em(mod97a, dat2, start1, verbose = TRUE, qml = TRUE)
fit97a <- em(mod97a, dat2, start = fit97$coefficients, verbose = TRUE, qml = TRUE)
fit97b <- em(mod97a, dat2, start = fit97a$coefficients, verbose = TRUE, qml = TRUE)

## Note nlsem defaults to marker variable methods, can't be turned off
summary(fit97b)
plot(fit97)

#### Longitudinal Models

################################################################################
## data preparation
################################################################################

dat<- read.csv('longitudinal.csv')

summary(dat)

################################################################################
## example Longitudinal CFA -- Configural Invariance model (form)
################################################################################
mod91 <- '
## define latent variables
				Pos1 =~ PosAFF11 + PosAFF21 + PosAFF31
				Pos2 =~ PosAFF12 + PosAFF22 + PosAFF32
				Pos3 =~ PosAFF13 + PosAFF23 + PosAFF33
				Neg1 =~ NegAFF11 + NegAFF21 + NegAFF31
				Neg2 =~ NegAFF12 + NegAFF22 + NegAFF32
				Neg3 =~ NegAFF13 + NegAFF23 + NegAFF33
				
## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33

'

fit91 <- cfa(mod91, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit91, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Longitudinal CFA -- Weak Invariance model (Loadings)
################################################################################
mod92 <- '
## define latent variables
				Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
				Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
				Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
				Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
				Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
				Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
				Pos2 ~~ NA*Pos2
				Pos3 ~~ NA*Pos3
				Neg2 ~~ NA*Neg2
				Neg3 ~~ NA*Neg3

## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33
'

fit92 <- cfa(mod92, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit92, standardized=TRUE, fit.measures=TRUE)

##Compare configural and weak model
anova(fit91, fit92)
#check change in CFI, change is .003 so continue testing
fitmeasures(fit91)["cfi"]
fitmeasures(fit92)["cfi"]

summary(compareFit(config = fit91, weak = fit92))

################################################################################
## example Longitudinal CFA -- Strong Invariance (Loadings & Intercepts)
################################################################################
mod93 <- '
## define latent variables
				Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
				Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
				Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
				Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
				Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
				Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
				Pos2 ~~ NA*Pos2
				Pos3 ~~ NA*Pos3
				Neg2 ~~ NA*Neg2
				Neg3 ~~ NA*Neg3

## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33

## constrain intercepts across time
				PosAFF11 ~ t1*1
				PosAFF21 ~ t2*1
				PosAFF31 ~ t3*1
				NegAFF11 ~ t4*1
				NegAFF21 ~ t5*1
				NegAFF31 ~ t6*1
				
				PosAFF12 ~ t1*1
				PosAFF22 ~ t2*1
				PosAFF32 ~ t3*1
				NegAFF12 ~ t4*1
				NegAFF22 ~ t5*1
				NegAFF32 ~ t6*1
				
				PosAFF13 ~ t1*1
				PosAFF23 ~ t2*1
				PosAFF33 ~ t3*1
				NegAFF13 ~ t4*1
				NegAFF23 ~ t5*1
				NegAFF33 ~ t6*1

## free latent means at later times (only set the scale once)
				Pos2 ~ NA*1
				Pos3 ~ NA*1
				Neg2 ~ NA*1
				Neg3 ~ NA*1
'

fit93 <- cfa(mod93, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit93, standardized=TRUE, fit.measures=TRUE)

##Compare strong and weak model
anova(fit92, fit93)
#check change in CFI, change is .002 so continue testing
fitmeasures(fit92)['cfi']-
  fitmeasures(fit93)['cfi']

summary(compareFit(config = fit91, weak = fit92, strong = fit93))


################################################################################
## example Alternate NUll Model
################################################################################

modNULL <- '
## constrain variances across time

PosAFF11 ~~ v1*PosAFF11
PosAFF12 ~~ v1*PosAFF12
PosAFF13 ~~ v1*PosAFF13

PosAFF21 ~~ v2*PosAFF21
PosAFF22 ~~ v2*PosAFF22
PosAFF23 ~~ v2*PosAFF23

PosAFF31 ~~ v3*PosAFF31
PosAFF32 ~~ v3*PosAFF32
PosAFF33 ~~ v3*PosAFF33

NegAFF11 ~~ v4*NegAFF11
NegAFF12 ~~ v4*NegAFF12
NegAFF13 ~~ v4*NegAFF13

NegAFF21 ~~ v5*NegAFF21
NegAFF22 ~~ v5*NegAFF22
NegAFF23 ~~ v5*NegAFF23

NegAFF31 ~~ v6*NegAFF31
NegAFF32 ~~ v6*NegAFF32
NegAFF33 ~~ v6*NegAFF33

## constrain intercepts across time
PosAFF11 ~ t1*1
PosAFF21 ~ t2*1
PosAFF31 ~ t3*1
NegAFF11 ~ t4*1
NegAFF21 ~ t5*1
NegAFF31 ~ t6*1

PosAFF12 ~ t1*1
PosAFF22 ~ t2*1
PosAFF32 ~ t3*1
NegAFF12 ~ t4*1
NegAFF22 ~ t5*1
NegAFF32 ~ t6*1

PosAFF13 ~ t1*1
PosAFF23 ~ t2*1
PosAFF33 ~ t3*1
NegAFF13 ~ t4*1
NegAFF23 ~ t5*1
NegAFF33 ~ t6*1

'

fitNULL <- cfa(modNULL, data=dat, meanstructure=TRUE, std.lv=TRUE)

#without correct null model
fitmeasures(fit93)
#with correct null model
fitmeasures(fit93, baseline.model=fitNULL)

#Use correct null model with compareFit

summary(compareFit(config = fit91, weak = fit92, strong = fit93,
           baseline.model=fitNULL))

## Use score tests indices to look at partial invariance

lavTestScore(fit93)

################################################################################
## example Longitudinal SEM -- Structural Regression
################################################################################
mod94 <- '
## define latent variables
				Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
				Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
				Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
				Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
				Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
				Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
				Pos2 ~~ NA*Pos2
				Pos3 ~~ NA*Pos3
				Neg2 ~~ NA*Neg2
				Neg3 ~~ NA*Neg3

				Pos1 ~~ Neg1
				Pos2 ~~ Neg2
				Pos3 ~~ Neg3

## directional regression paths
				Pos2 ~ Pos1 + Neg1
        Neg2 ~ Pos1 + Neg1
				Pos3 ~ Pos2 + Neg2
        Neg3 ~ Pos2 + Neg2

## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33
'

fit94 <- sem(mod94,data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94, standardized=TRUE, fit.measures=TRUE)

#compare with weak invariance model (because this model only has equal loadings)
anova(fit92, fit94)



################################################################################
## example Longitudinal SEM -- Structural Regression (cross lagged paths pruned)
################################################################################
mod95 <- '
## define latent variables
				Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
				Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
				Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
				Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
				Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
				Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
				Pos2 ~~ NA*Pos2
				Pos3 ~~ NA*Pos3
				Neg2 ~~ NA*Neg2
				Neg3 ~~ NA*Neg3

				Pos1 ~~ Neg1
				Pos2 ~~ Neg2
				Pos3 ~~ Neg3

## directional regression paths
				Pos2 ~ Pos1
				Pos3 ~ Pos2
				Neg2 ~ Neg1
				Neg3 ~ Neg2

## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33
'

fit95 <- sem(mod95, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit95, standardized=TRUE, fit.measures=TRUE)

#Compare to weak invariance model
anova(fit92, fit95)

#Fit still worse than CFA, check mod indices
modificationindices(fit95, minimum.value = 10)

#Add in lag 2 autoregressive paths


################################################################################
## example Longitudinal SEM -- Structural Regression (more within Affect)
################################################################################
mod96 <- '
## define latent variables
				Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
				Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
				Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
				Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
				Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
				Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
				Pos2 ~~ NA*Pos2
				Pos3 ~~ NA*Pos3
				Neg2 ~~ NA*Neg2
				Neg3 ~~ NA*Neg3
				Pos1 ~~ Neg1
				Pos2 ~~ Neg2
				Pos3 ~~ Neg3

## directional regression paths
				Pos2 ~ Pos1
        Pos3 ~ Pos1
				Pos3 ~ Pos2
				Neg3 ~ Neg1
        Neg2 ~ Neg1
				Neg3 ~ Neg2

## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33
'

fit96 <- cfa(mod96, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit96, standardized=TRUE, fit.measures=TRUE)
#Compare to weak invariance model
anova(fit92, fit96)

## RI-CLPM

mod94a <- '
## define latent variables
				Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
				Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
				Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
				Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
				Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
				Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
				Pos2 ~~ NA*Pos2
				Pos3 ~~ NA*Pos3
				Neg2 ~~ NA*Neg2
				Neg3 ~~ NA*Neg3

## correlated residuals across time
				PosAFF11 ~~ PosAFF12 + PosAFF13
				PosAFF12 ~~ PosAFF13
				PosAFF21 ~~ PosAFF22 + PosAFF23
				PosAFF22 ~~ PosAFF23
				PosAFF31 ~~ PosAFF32 + PosAFF33
				PosAFF32 ~~ PosAFF33
				
				NegAFF11 ~~ NegAFF12 + NegAFF13
				NegAFF12 ~~ NegAFF13
				NegAFF21 ~~ NegAFF22 + NegAFF23
				NegAFF22 ~~ NegAFF23
				NegAFF31 ~~ NegAFF32 + NegAFF33
				NegAFF32 ~~ NegAFF33

## constrain intercepts across time
				PosAFF11 ~ t1*1
				PosAFF21 ~ t2*1
				PosAFF31 ~ t3*1
				NegAFF11 ~ t4*1
				NegAFF21 ~ t5*1
				NegAFF31 ~ t6*1
				
				PosAFF12 ~ t1*1
				PosAFF22 ~ t2*1
				PosAFF32 ~ t3*1
				NegAFF12 ~ t4*1
				NegAFF22 ~ t5*1
				NegAFF32 ~ t6*1
				
				PosAFF13 ~ t1*1
				PosAFF23 ~ t2*1
				PosAFF33 ~ t3*1
				NegAFF13 ~ t4*1
				NegAFF23 ~ t5*1
				NegAFF33 ~ t6*1

## Equate latent means across times (so set all to 0)
				Pos1 ~ 0*1
				Pos2 ~ 0*1
				Pos3 ~ 0*1
				Neg1 ~ 0*1
				Neg2 ~ 0*1
				Neg3 ~ 0*1
				

## directional regression paths
				Pos2 ~ Pos1 + Neg1
        Neg2 ~ Pos1 + Neg1
				Pos3 ~ Pos2 + Neg2
        Neg3 ~ Pos2 + Neg2

## Within time covariances
Pos1 ~~ NA*Neg1
Pos2 ~~ NA*Neg2
Pos3 ~~ NA*Neg3


## Random intercepts
Pos =~ 1*Pos1 + 1*Pos2 +1*Pos3
Neg =~ 1*Neg1 + 1*Neg2 +1*Neg3

Pos ~ NA*1
Neg ~ NA*1
Pos ~~ NA*Pos
Neg ~~ NA*Neg

## Remove covariances
Pos ~~ 0*Neg1 + 0*Neg2 + 0*Neg3
Neg ~~ 0*Pos1 + 0*Pos2 + 0*Pos3

'

fit94a <- sem(mod94a,data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94a, standardized=TRUE, fit.measures=TRUE)


################################################################################
## data preparation: growth curves
################################################################################

dat2<- read.csv('growth4wave.csv')

summary(dat2)

##Means of negative affect
negMeans<-colMeans(dat2[,5:8])
negMeans

##plot means of neg
plot(1:4, negMeans, type = "l")


##plot first 50 individual trajectories
plot(1:4, dat2[1,5:8], type = 'n', ylim=c(0,5), ylab = 'Negative Affect', xlab = 'Time')

times <- 1:4

for(i in 1:100){
  mod<-lm(t(dat2[i,5:8])~times)
  abline(reg = mod)
}

mod <- lm(negMeans~times)
abline(reg = mod, col = 'red', lwd = 3)

################################################################################
## example Latent Growth Curve negative affect
################################################################################
mod97 <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + 1*negT2 + 2*negT3 + 3*negT4
'

fit97 <- growth(mod97, data=dat2)

summary(fit97, standardized=TRUE, fit.measures=TRUE)

#Make the last time the intercept
mod97a <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ -3*negT1 + -2*negT2 + -1*negT3 + 0*negT4
'

fit97a <- growth(mod97a, data=dat2)

summary(fit97a, standardized=TRUE, fit.measures=TRUE)

#Predict growth with gender
mod97c <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + 1*negT2 + 2*negT3 + 3*negT4

negInt ~ gender
negSlope ~ gender
'

fit97c <- growth(mod97c, data=dat2)

summary(fit97c, standardized=TRUE, fit.measures=TRUE)

################################################################################
## example Latent Growth Curve negative and positive affect 
################################################################################
mod98 <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + 1*negT2 + 2*negT3 + 3*negT4

posInt =~ 1*posT1 + 1*posT2 + 1*posT3 + 1*posT4
posSlope =~ 0*posT1 + 1*posT2 + 2*posT3 + 3*posT4

#Have to force positive residuals to equality to estimate
posT1 ~~ th*posT1
posT2 ~~ th*posT2
posT3 ~~ th*posT3
posT4 ~~ th*posT4

'

fit98 <- growth(mod98, data=dat2)

summary(fit98, standardized=TRUE, fit.measures=TRUE)



################################################################################
## example Latent Growth Curve negative affec free loadings (not linear change) 
################################################################################
mod99 <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + negT2 + negT3 + 1*negT4
'

fit99 <- growth(mod99, data=dat2)

summary(fit99, standardized=TRUE, fit.measures=TRUE)

#compare to linear model
anova(fit97, fit99)

## Quadratic model
mod97q <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + 1*negT2 + 2*negT3 + 3*negT4
negQuad =~ 0*negT1 + 1*negT2 + 4*negT3 + 9*negT4
'

fit97q <- growth(mod97q, data=dat2)

summary(fit97q, standardized=TRUE, fit.measures=TRUE)

anova(fit97, fit97q)

## Code to set up data for exercise

#Put sai dataset into the enviornment
data(sai)

#Select the "SAM" study
saiSAM <- sai[sai$study == "SAM",]

#use reshape for converting to wide format

saiWide <- reshape(saiSAM, direction = "wide", 
                   idvar = "id", 
                   timevar = "time")
summary(saiWide)
