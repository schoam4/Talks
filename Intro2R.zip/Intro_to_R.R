##############################
####Introduction to R     ####
####Alexander M. Schoemann####
####1/23/2020             ####
##############################

##R can be a calculator
3+4

3*4

3^5

(12+
  5)/13



##Everything is an object

x <-3

x

x+4

#Create a vector

c(1,2,3,4)

y <- c(1,2,3,4)

y

y + 3

y + x

mean(y+x)

#You can overwrite existing objects!
x <- c(1,2)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('C:/Users/schoemanna/Documents/Psyc7505/Intro2R/hsb2.csv')

dat1

head(dat1)

tail(dat1)

summary(dat1)

## Use the menus to import data, name it dat3

#convert to data.frame
dat3 <- as.data.frame(dat3)

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

summary(dat1)

summary(dat1$math)

library(rockchalk)

summarize(dat1)

library(psych)

describe(dat1)

##Plotting!

plot(dat1)

plot(dat1$math)

plot(dat1$prog)

plot(dat1$math, dat1$science)

plot(dat1$prog, dat1$math)

hist(dat1$math)

boxplot(dat1$math)


##Analyses

t.test(write~female, data=dat1)
t.test(dat1$write, dat1$science, paired = TRUE)

#Regression

mod1 <- lm(math ~ schtyp + science, data=dat1)
mod1
summary(mod1)
resid(mod1)
plot(mod1)

#Model with an interaction between school type and science
mod2 <- lm(math ~ schtyp * science, data=dat1)
summary(mod2)
anova(mod1,mod2)

#Model with the categorical variance prog
#note for prog: 1 = general, 2 = academic, 3 = vocational
mod3 <- lm(math ~ schtyp + science +prog, data=dat1)
summary(mod3)
anova(mod1,mod3)

##Packages
#Install the mice package
install.packages('mice')

#load the mice package
library(mice)

