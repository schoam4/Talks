#########################
## SEM with R Day 1    ##
## Alexander Schoemann ##
## June 28, 2016        ##
#########################

##################################
### Introduction to R 
##################################

##R can be a calculator
3+4

3*4

3^5

(12+
  5)/13



##Everything is an object

x <-3

x

x+4

#Create a vector

c(1,2,3,4)

y <- c(1,2,3,4)

y

y + 3

y + x

mean(y+x)

#You can overwrite existing objects!
x <- c(1,2)

x


##################################
### Scale Setting and CFA 
##################################

## Load packages used in code below
## Install any needed packages

library(lavaan)
library(semTools)
library(semPlot)
library(psych)


## data preparation

## read in example data file
dat <- read.csv('Lec3.CFA.csv')

## Look at  data
head(dat)
summary(dat)


## Example -- Fixed-Factor Method

mod41 <- '
Positive =~ great + cheerful + happy
#Fix factor variance to 1
Positive ~~ 1*Positive
#Residual variances
great ~~ great
cheerful ~~ cheerful
happy ~~ happy
'

fit41 <- cfa(mod41, data = dat, std.lv=TRUE)

summary(fit41, standardized=TRUE, fit.measures=TRUE)
semPaths(fit41, 'est', nCharNodes = 0)
semPaths(mod41, nCharNodes = 0)


## Example -- Marker-Variable Method (first variable)

mod42 <- 'Positive =~ 1*great + cheerful + happy
Positive ~~ Positive
great ~~ great
cheerful ~~ cheerful
happy ~~ happy'

fit42 <- lavaan(mod42, data = dat)

summary(fit42, standardized=TRUE, fit.measures=TRUE)



## Example -- Marker-Variable Method (second variable)

mod43 <- 'Positive =~ great + 1*cheerful + happy
Positive ~~ Positive
great ~~ great
cheerful ~~ cheerful
happy ~~ happy'

fit43 <- lavaan(mod43, data = dat)

summary(fit43, standardized=TRUE, fit.measures=TRUE)



## Example -- Effects-Coding Method


mod45 <- 'Positive =~ L1*great + L2*cheerful + L3*happy
L1 == 3 - L2 - L3

Positive ~~ Positive
great ~~ great
cheerful ~~ cheerful
happy ~~ happy
'

fit45 <- lavaan(mod45, data = dat, 
                std.lv=FALSE, auto.fix.first=FALSE)

summary(fit45, standardized=TRUE, fit.measures=TRUE)

#########NOTE: lavaan has some built in shortcuts#######
#By default lavaan assumes you want to estimate residual variances
#and latent variances and covariances.
#The arguments std.lv and auto.fix.first can be used to automatically specify a
#method of scale setting.

#Here's the same model but with the shortcuts

mod46 <- 'Positive =~ great + cheerful + happy'

#Marker variable method is the default
fit46 <- cfa(mod46, data = dat)

summary(fit46, standardized=TRUE, fit.measures=TRUE)

#But it is easy to turn on the fixed factor method
fit47 <- cfa(mod46, data = dat, std.lv=TRUE)

summary(fit47, standardized=TRUE, fit.measures=TRUE)

## CFA examples

##Find reliability (alpha) using the psych package

#positive affect
alpha(dat[,1:3])

#negative affect
alpha(dat[,4:6])


## EFA

##Use the fa function in the psych package.
EFA <- fa(dat, nfactors=2, fm="ml")
EFA

## example CFA (no fixes)

mod51 <- 'Positive =~ great + cheerful + happy
Negative =~ sad + down + unhappy

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'
fit51 <-  cfa(mod51, data=dat, std.lv=TRUE)

summary(fit51, standardized=TRUE, fit.measures=TRUE)

#Create a path diagram with semPlot
semPaths(fit51, 'est')

#same diagram but with standardized estimates
semPaths(fit51, 'std')

#Get observed covariance a model implied covariance matrix
inspect(fit51, 'sampstat')

#Get model implied covariance matrix
fitted.values(fit51)

#Get fitted residuals: Observed covariances - Model implied covariances
inspect(fit51, 'sampstat')$cov-fitted.values(fit51)$cov

#Or use
residuals(fit51)

#We can also get standardized residuals (difference between the correlation matrices)
residuals(fit51, type='cor')

#Get modification indices
modificationIndices(fit51)


## example 5.2 CFA with a dual loading

mod52 <- 'Positive =~ great + cheerful + happy + sad
Negative =~ sad + down + unhappy

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'
fit52 <-  cfa(mod52, data=dat, std.lv=TRUE)

summary(fit52, standardized=TRUE, fit.measures=TRUE)

semPaths(fit52, 'est')

#Compare residuals
residuals(fit51, type='cor')
residuals(fit52, type='cor')


## example 5.3 CFA with a correlated residual (withing the Negative construct)

mod53 <- 'Positive =~ great + cheerful + happy
Negative =~ sad + down + unhappy
down ~~ unhappy

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'

fit53 <-  cfa(mod53, data=dat, std.lv=T)

summary(fit53, standardized=TRUE, fit.measures=TRUE)

semPaths(fit53, 'est')

## example 5.4 CFA with a correlated residual (across constructs)

mod54 <- 'Positive =~ great + cheerful + happy
Negative =~ sad + down + unhappy
great ~~ sad

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'

fit54 <-  cfa(mod54, data=dat, std.lv=T)

summary(fit54, standardized=TRUE, fit.measures=TRUE)

semPaths(fit54, 'est')

##################################
### Model Fit 
##################################

## Fit nested models

## Orthogonal model

mod51a <- 'Positive =~ great + cheerful + happy
Negative =~ sad + down + unhappy

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ 0*Negative
'
fit51a <-  cfa(mod51a, data=dat, std.lv=TRUE)

summary(fit51a, standardized=TRUE, fit.measures=TRUE)
anova(fit51, fit51a)

## Perfectly correlated constructs (single construct) 
mod51b <- 'Positive =~ great + cheerful + happy
Negative =~ sad + down + unhappy

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ 1*Negative
'

fit51b <-  cfa(mod51b, data=dat, std.lv=TRUE)

summary(fit51b, standardized=TRUE, fit.measures=TRUE)
anova(fit51, fit51b)

mod51c <- '
AFF =~ great + cheerful + happy + sad + down + unhappy
'
fit51c <-  cfa(mod51c, data=dat, std.lv=TRUE)

summary(fit51c, standardized=TRUE, fit.measures=TRUE)
anova(fit51, fit51c)

##################################
### Structural Models
##################################


## data preparation

## Data is in a tab delimited file with no names

dat <- read.table("11.Grade7.dat")

# This assigns names to each column in dat
names(dat) <- c("Agency1","Agency2","Agency3","Intrin1","Intrin2","Intrin3","Extrin1","Extrin2","Extrin3","PosAFF1","PosAFF2","PosAFF3","NegAFF1","NegAFF2","NegAFF3","Gender","Ethnic2","Ethnic3","Ethnic4")

## Create scale scores for OLS regression

dat$Agency <- (dat$Agency1 + dat$Agency2 + dat$Agency3)/3
dat$Intrin <- (dat$Intrin1 + dat$Intrin2 + dat$Intrin3)/3
dat$Extrin <- (dat$Extrin1 + dat$Extrin2 + dat$Extrin3)/3
dat$PosAFF <- (dat$PosAFF1 + dat$PosAFF2 + dat$PosAFF3)/3
dat$NegAFF <- (dat$NegAFF1 + dat$NegAFF2 + dat$NegAFF3)/3


## Example 7.1 -- Path model predicting positive affect

mod70 <- lm(PosAFF ~ Agency + Intrin + Extrin, data=dat)

summary(mod70)
standardize(mod70)

mod71 <- '
PosAFF ~ Agency + Intrin + Extrin
'

fit71 <- sem(mod71, data = dat, fixed.x=FALSE)
summary(fit71, fit.measures=TRUE, standardized=TRUE)
#Get r^2
inspect(fit71, 'r2')



## Example 7.2 -- Start with a CFA

mod72 <- 'Agency =~ Agency1 + Agency2 + Agency3
Intrin =~ Intrin1 + Intrin2 + Intrin3
Extrin =~ Extrin1 + Extrin2 + Extrin3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
'

fit72 <- cfa(mod72, data=dat, std.lv=TRUE)

summary(fit72, standardized=TRUE, fit.measures=TRUE)



## Example 7.3 -- Change CFA to Structural (Latent) Regression

mod73 <- 'Agency =~ Agency1 + Agency2 + Agency3
Intrin =~ Intrin1 + Intrin2 + Intrin3
Extrin =~ Extrin1 + Extrin2 + Extrin3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3

Positive ~ Agency + Intrin + Extrin
'

fit73 <- sem(mod73, data=dat, std.lv=TRUE)

summary(fit73, standardized=TRUE, fit.measures=TRUE)

inspect(fit73, 'r2')

semPaths(fit73)


## Example 7.4 -- Add Negative Affect

mod74 <- 'Agency =~ Agency1 + Agency2 + Agency3
Intrin =~ Intrin1 + Intrin2 + Intrin3
Extrin =~ Extrin1 + Extrin2 + Extrin3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
Negative =~ NegAFF1 + NegAFF2 + NegAFF3

Positive ~ Agency + Intrin + Extrin
Negative ~ Agency + Intrin + Extrin
'

fit74 <- sem(mod74, data=dat, std.lv=TRUE)

summary(fit74, standardized=TRUE, fit.measures=TRUE)

inspect(fit74, 'r2')



## Example 7.5 -- Trim Non-Significant Paths

mod75 <- 'Agency =~ Agency1 + Agency2 + Agency3
Intrin =~ Intrin1 + Intrin2 + Intrin3
Extrin =~ Extrin1 + Extrin2 + Extrin3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
Negative =~ NegAFF1 + NegAFF2 + NegAFF3

Positive ~ Agency + Intrin
Negative ~ Extrin
'

fit75 <- sem(mod75, data=dat, std.lv=TRUE)

summary(fit75, standardized=TRUE, fit.measures=TRUE)

#Compare to unpruned model
anova(fit74, fit75)



## Example 7.6 -- Introduce Covariates, regress all constructs on them

mod76 <- 'Agency =~ Agency1 + Agency2 + Agency3
Intrin =~ Intrin1 + Intrin2 + Intrin3
Extrin =~ Extrin1 + Extrin2 + Extrin3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
Negative =~ NegAFF1 + NegAFF2 + NegAFF3

Agency ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
Intrin ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
Extrin ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
Positive ~ Agency + Intrin + Gender + Ethnic2 + Ethnic3 + Ethnic4
Negative ~ Extrin + Gender + Ethnic2 + Ethnic3 + Ethnic4
'

fit76 <- sem(mod76, data=dat, std.lv=TRUE)

summary(fit76, standardized=TRUE, fit.measures=TRUE)

#Ethinic2 = black
#Ethnic3 = Hispanic
#Ethnic4 = Other
#Gender: 1 = Female


## Example 7.7 -- Trim Non-Significant Paths (again)

mod77 <- 'Agency =~ Agency1 + Agency2 + Agency3
Intrin =~ Intrin1 + Intrin2 + Intrin3
Extrin =~ Extrin1 + Extrin2 + Extrin3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
Negative =~ NegAFF1 + NegAFF2 + NegAFF3

Intrin ~ Gender + Ethnic3 
Extrin ~ Gender
Positive ~ Agency + Intrin 
Negative ~ Extrin + Gender + Ethnic2 
'

fit77 <-  sem(mod77, data=dat, std.lv=TRUE)

summary(fit77, standardized=TRUE, fit.measures=TRUE)


##################################
### Mediation
##################################



## data preparation

## read raw data file for mediation model
dat <- read.csv("mediation.csv")

## example 9.1 -- Structural Regression, with Agency as auxilliary covariate
## C PATHWAY

mod91 <- '
## define latent variables
Intrin =~ Intrin1 + Intrin2 + Intrin3
Agency =~ Agency1 + Agency2 + Agency3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## Covariances
Agency ~~ Intrin
Positive ~~ Agency
# Regression
Positive ~ Intrin
'

fit91 <- sem(mod91, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit91, standardized=TRUE, fit.measures=TRUE)


## example 92 -- Mediation model

mod92 <- '
## define latent variables
Intrin =~ Intrin1 + Intrin2 + Intrin3
Agency =~ Agency1 + Agency2 + Agency3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3

## latent regression
Agency ~ a*Intrin
Positive ~ b*Agency + cprime*Intrin

## Define indirect effect
ab := a*b
tot := a*b + cprime
'

fit92 <- sem(mod92, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit92, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping

fit92b <- sem(mod92, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit92b, standardized=TRUE, fit.measures=TRUE)

#Get bootstrapped CI
parameterEstimates(fit92b)

##Monte Carlo CI

#If you provide the function with a lavaan object it 
# finds paramters with given names
monteCarloMed("a*b", object=fit92, plot=TRUE, rep = 1000000)

## example 93 -- Structural Regression, with Intrinsic as auxilliary covariate

mod93 <- '
## define latent variables
Intrin =~ Intrin1 + Intrin2 + Intrin3
Agency =~ Agency1 + Agency2 + Agency3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
Agency ~~ Intrin
Positive ~~ Intrin
## latent regression
Positive ~ Agency
'

fit93 <- sem(mod93, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit93, standardized=TRUE, fit.measures=TRUE)


## example 94 -- Mediation model

mod94 <- '
## define latent variables
Intrin =~ Intrin1 + Intrin2 + Intrin3
Agency =~ Agency1 + Agency2 + Agency3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent regression
Intrin ~ a*Agency
Positive ~ b*Intrin + Agency

ab := a*b
'

fit94 <- sem(mod94, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping

fit94b <- sem(mod94, data=dat, meanstructure=TRUE, std.lv=TRUE, se = "boot")

summary(fit94b, standardized=TRUE, fit.measures=TRUE)

parameterEstimates(fit94b)

