#########################
## SEM with R Day 2    ##
## Alexander Schoemann ##
## June 29, 2016        ##
#########################

## Load packages used in code below
## Install any needed packages


library(lavaan)
library(semTools)
library(semPlot)
library(Amelia)
library(mice)
library(simsem)
library(psych)

##################################
### Missing Data
##################################

## data preparation

#Read data in 
dat2 <- read.csv('Missing_Full.csv')

missmap(dat3)
missmap(dat4)


## look at data
summary(dat2)
cov(dat2)


## Model 8.1 fit CFA 

mod81 <- 'Positive =~ great + cheerful + happy + good + glad + super
Negative =~ sad + down + unhappy + blue + bad + terrible 

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'

fit81 <-  cfa(mod81, data=dat2, std.lv=T)

summary(fit81, standardized=TRUE, fit.measures=TRUE)

semPaths(fit81, 'est')



## Model 8.2 fit CFA  - 20% missing MCAR

#Read data in 
dat3 <- read.csv('Missing_MCAR.csv')

## look at data
summary(dat3)
cov(dat3)
?cov
cov(dat3, use="complete.obs")

#Fit with listwise deletion (lavaan default)
mod82 <- 'Positive =~ great + cheerful + happy + good + glad + super
Negative =~ sad + down + unhappy + blue + bad + terrible 

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'

fit82 <-  cfa(mod82, data=dat3, std.lv=TRUE)

summary(fit82, standardized=TRUE, fit.measures=TRUE)

#Fit with FIML
fit83 <-  cfa(mod82, data=dat3, std.lv=TRUE, missing='fiml')

summary(fit83, standardized=TRUE, fit.measures=TRUE)
summary(fit81, standardized=TRUE, fit.measures=TRUE)

parameterEstimates(fit81)
parameterEstimates(fit83)


## Model 8.2 fit CFA  - 20% missing MAR (based on great)

#Read data in 
dat4 <- read.csv('Missing_MAR.csv')

## look at data
summary(dat4)
cov(dat4, use="complete.obs")

#Fit with listwise deletion (lavaan default)
mod84 <- 'Positive =~ great + cheerful + happy + good + glad + super
Negative =~ sad + down + unhappy + blue + bad + terrible 

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'

fit84 <-  cfa(mod84, data=dat4, std.lv=TRUE)

summary(fit84, standardized=TRUE, fit.measures=TRUE)

#Fit with FIML
fit85 <-  cfa(mod84, data=dat4, std.lv=TRUE, missing='fiml')

summary(fit85, standardized=TRUE, fit.measures=TRUE)
summary(fit81, standardized=TRUE, fit.measures=TRUE)

##impute data using Amelia
#Only using 3 imputations to save time!
imps <- amelia(dat4, m=3)

#Fit model with runMI (or in this case cfa.mi)

fit86 <- cfa.mi(mod84, data=imps$imputations, 
                std.lv=TRUE)
summary(fit86, standardized=TRUE, fit.measures=TRUE)
inspect(fit86, 'fit')
fitmeasures(fit86)
inspect(fit86, "impute")

##################################
### Power
##################################

## Satorra, & Saris Method

## Population Model
PopMod <- 'F1 =~ .7*v1 + .7*v2 + .7*v3 + .7*v4 + .7*v5
F2 =~ .7*v6 + .7*v7 + .7*v8 + .7*v9 + .7*v10
F1 ~~ 1*F1
F2 ~~ 1*F2
F1 ~~ .235*F2

v1 ~~ .51*v1
v2 ~~ .51*v2
v3 ~~ .51*v3
v4 ~~ .51*v4
v5 ~~ .51*v5
v6 ~~ .51*v6
v7 ~~ .51*v7
v8 ~~ .51*v8
v9 ~~ .51*v9
v10 ~~ .51*v10
'
##Analysis Model
SSMod <- '
f1 =~ v1 + v2 + v3 + v4 + v5
f2 =~ v6 + v7 + v8 + v9 + v10
f1 ~~ 0*f2
'

SSpower(PopMod, 120, SSMod, std.lv=TRUE)

## Monte Carlo Method

##Specify analysis model. The model we want to fit
AnMod <- 'F1 =~ v1 + v2 + v3 + v4 + v5
F2 =~ v6 + v7 + v8 + v9 + v10
F1 ~~ 1*F1
F2 ~~ 1*F2
F1 ~~ F2

v1 ~~ v1
v2 ~~ v2
v3 ~~ v3
v4 ~~ v4
v5 ~~ v5
v6 ~~ v6
v7 ~~ v7
v8 ~~ v8
v9 ~~ v9
v10 ~~ v10
'

##Run simulation with 50 reps for example. Normally you want more (1000+)!
out <- sim(nRep=50, model=AnMod, n = 200, generate = PopMod)

summary(out)

##################################
### Multiple Group Models
##################################


## data preparation

#Read data in 
dat <- read.csv('Lecture6_MG.csv')

summary(dat)
describe(dat)
describeBy(dat, dat$Grade)


## Examples  -- Separate single-Group Models (not usually needed)

mod1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

Positive ~~ 1*Positive
Negative ~~ 1*Negative

Positive ~~ Negative
'

## Fit model to 7th Grade

fitg1 <- cfa(mod1, data=dat[dat$Grade == '7th',],
             std.lv=TRUE)

summary(fitg1, standardized=TRUE, fit.measures=TRUE)

## Same model to 8th Grade

fitg2 <- cfa(mod1, data=dat[dat$Grade == '8th',], std.lv=TRUE)

summary(fitg2, standardized=TRUE, fit.measures=TRUE)


## Example -- Configural Invariance Model (Form)

## note, Both groups fit simultaneously, and there are 2 sets of parameter 
## estimates (identical to above), but there is a single set of fit measures

fit1 <- cfa(mod1, data=dat, std.lv=TRUE, group = "Grade")

summary(fit1, standardized=TRUE, fit.measures=TRUE)

semPaths(fit1,'est',panelGroups=TRUE)

## Chi-square for the configural model is the sum of the individual models

fitmeasures(fitg1)["chisq"] + fitmeasures(fitg2)["chisq"]

fitmeasures(fit1)["chisq"]

modindices(fit1)


## Examples -- Weak Invariance Models (Loadings)

## Fixed-Factor method of identification

modWeak1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

Positive ~~ c(1, NA)*Positive
Negative ~~ c(1, NA)*Negative

Positive ~~ Negative'

fitWeak1 <- cfa(modWeak1, data=dat, std.lv=TRUE, 
                group = "Grade", group.equal="loadings")

summary(fitWeak1, standardized=TRUE, fit.measures=TRUE)

#Compare configural and weak invariance models
#Non signficanct nested model test means weak invariance holds
anova(fit1, fitWeak1)

## Examples -- Strong Invariance Models (Intercepts)

## Fixed-Factor method of identification

modStrong1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

Positive ~~ c(1, NA)*Positive
Negative ~~ c(1, NA)*Negative

Positive ~~ Negative

Positive ~ c(0, NA)*1
Negative ~ c(0, NA)*1
'

fitStrong1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                  group = "Grade", group.equal=c("loadings","intercepts"))

summary(fitStrong1, standardized=TRUE, fit.measures=TRUE)

#Compare weak and Strong invariance models
#Non signficanct nested model test means strong invariance holds
anova(fitWeak1, fitStrong1)

# If invariance is not found, use Score tests to search for items
# which are not invariant
lavTestScore(fitStrong1, cumulative = TRUE)

## Examples -- Mean Invariance Models (Intercepts)

fitMean1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                group = "Grade", group.equal=c("loadings","intercepts", "means"))

summary(fitMean1)
anova(fitStrong1, fitMean1)


## Example -- measurementInvariance function

#Here's something cool

mod <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 
'

measurementInvariance(mod, data=dat, group = "Grade")

## Examples -- Variance/Covariance Invariance Models 

fitVCOV1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                group = "Grade",group.equal=c("loadings","intercepts", 
                              "lv.variances", "lv.covariances"))

summary(fitVCOV1)
anova(fitStrong1, fitVCOV1)

## Examples -- Variance Invariance Models 

fitVar1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                group = "Grade",group.equal=c("loadings","intercepts", 
                                              "lv.variances"))

summary(fitVar1)
anova(fitStrong1, fitVar1)

## Examples -- Phantom Variable  Models 


modPh1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

PhPos =~ Positive
PhNeg =~ Negative

Positive ~~ c(0, 0)*Positive
Negative ~~ c(0, 0)*Negative
PhPos ~~ c(1, 1)*PhPos
PhNeg ~~ c(1, 1)*PhNeg

Positive ~~ c(0, 0)*Negative
PhPos ~~ PhNeg
PhPos ~~ c(0, 0)*Negative
PhNeg ~~ c(0, 0)*Positive

PhPos ~ 0*1
PhNeg ~ 0*1
'

fitPh1 <- cfa(modPh1, data=dat, std.lv=TRUE, 
              group = "Grade",group.equal=c("loadings","intercepts"),
              group.partial = c('PhPos =~ Positive','PhNeg =~ Negative'))



summary(fitPh1, standardized=TRUE, fit.measures=TRUE)

#Fit is the same as the strong invariance model
anova(fitStrong1, fitPh1)

## Invariance of correlation

fitCor1 <- cfa(modPh1, data=dat, std.lv=TRUE, 
              group = "Grade",group.equal=c("loadings","intercepts", "lv.covariances"),
              group.partial = c('PhPos =~ Positive','PhNeg =~ Negative'))

anova(fitPh1, fitCor1)

##################################
### Moderation
##################################

##Read in data
dat2 <- read.csv('moderation.csv')

##Create data with orthogonalized terms

dat3 <- orthogonalize(dat2, c('agATT1', 'agATT2', 'agATT3'), 
                      c('meUNK1', 'meUNK2', 'meUNK3'), match=FALSE, 
                      namesProd = c('int1', 'int2', 'int3', 'int4', 'int5',
                                    'int6', 'int7', 'int8', 'int9'))



## example 95 -- Moderation model Orthogonalizing

mod95 <- '
## define latent variables
Agency =~ agATT1 + agATT2 + agATT3
Unknown =~ meUNK1 + meUNK2 + meUNK3
Interact =~ int1 + int2 + int3 + int4 + int5 + int6 + int7 + int8 + int9
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
Agency ~~ Unknown
Agency ~~ 0*Interact
Unknown ~~ 0*Interact
## latent regression
Positive ~ Agency + Unknown + Interact
## correlated residuals
int2 ~~ T1*int1
int3 ~~ T1*int1
int3 ~~ T1*int2
int5 ~~ T2*int4
int6 ~~ T2*int4
int6 ~~ T2*int5
int8 ~~ T3*int7
int9 ~~ T3*int7
int9 ~~ T3*int8
int4 ~~ T4*int1
int7 ~~ T4*int4
int7 ~~ T4*int1
int5 ~~ T5*int2
int8 ~~ T5*int5
int8 ~~ T5*int2
int6 ~~ T6*int3
int9 ~~ T6*int6
int9 ~~ T6*int3
'

fit95 <- sem(mod95, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit95, fit.measures=TRUE)



## example 96 -- Moderation model Double Mean Centering

dat4 <-indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
               c('meUNK1', 'meUNK2', 'meUNK3'), meanC=FALSE, doubleMC =TRUE, 
               namesProd = c('int1', 'int2', 'int3'))

mod96 <- '
## define latent variables
Agency =~ agATT1 + agATT2 + agATT3
Unknown =~ meUNK1 + meUNK2 + meUNK3
Interact =~ int1 + int2 + int3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
Agency ~~ Unknown
Agency ~~ Interact
Unknown ~~ Interact
## latent regression
Positive ~ Agency + Unknown + Interact
'

fit96 <- sem(mod96, data=dat4, std.lv=TRUE, meanstructure=TRUE)

summary(fit96, fit.measures=TRUE)

##Probing interactions

probed <-probe2WayRC(fit95, nameX=c('Agency', 'Unknown', 'Interact'), 
                     nameY='Positive', modVar='Unknown', c(-1,1))

probe2WayMC(fit96, nameX=c('Agency', 'Unknown', 'Interact'), 
            nameY='Positive', modVar='Unknown', c(-1,1))

plotProbe(probed, c(-1,1))

##################################
### Longitudinal Models
##################################


## data preparation

dat<- read.csv('longitudinal.csv')

summary(dat)


## example 9.1 Longitudinal CFA -- Configural Invariance model (form)

mod91 <- '
## define latent variables
Pos1 =~ PosAFF11 + PosAFF21 + PosAFF31
Pos2 =~ PosAFF12 + PosAFF22 + PosAFF32
Pos3 =~ PosAFF13 + PosAFF23 + PosAFF33
Neg1 =~ NegAFF11 + NegAFF21 + NegAFF31
Neg2 =~ NegAFF12 + NegAFF22 + NegAFF32
Neg3 =~ NegAFF13 + NegAFF23 + NegAFF33

## correlated residuals across time
PosAFF11 ~~ PosAFF12 + PosAFF13
PosAFF12 ~~ PosAFF13
PosAFF21 ~~ PosAFF22 + PosAFF23
PosAFF22 ~~ PosAFF23
PosAFF31 ~~ PosAFF32 + PosAFF33
PosAFF32 ~~ PosAFF33

NegAFF11 ~~ NegAFF12 + NegAFF13
NegAFF12 ~~ NegAFF13
NegAFF21 ~~ NegAFF22 + NegAFF23
NegAFF22 ~~ NegAFF23
NegAFF31 ~~ NegAFF32 + NegAFF33
NegAFF32 ~~ NegAFF33

'

fit91 <- cfa(mod91, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit91, standardized=TRUE, fit.measures=TRUE)



## example 9.2 Longitudinal CFA -- Weak Invariance model (Loadings)

mod92 <- '
## define latent variables
Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
Pos2 ~~ NA*Pos2
Pos3 ~~ NA*Pos3
Neg2 ~~ NA*Neg2
Neg3 ~~ NA*Neg3

## correlated residuals across time
PosAFF11 ~~ PosAFF12 + PosAFF13
PosAFF12 ~~ PosAFF13
PosAFF21 ~~ PosAFF22 + PosAFF23
PosAFF22 ~~ PosAFF23
PosAFF31 ~~ PosAFF32 + PosAFF33
PosAFF32 ~~ PosAFF33

NegAFF11 ~~ NegAFF12 + NegAFF13
NegAFF12 ~~ NegAFF13
NegAFF21 ~~ NegAFF22 + NegAFF23
NegAFF22 ~~ NegAFF23
NegAFF31 ~~ NegAFF32 + NegAFF33
NegAFF32 ~~ NegAFF33
'

fit92 <- cfa(mod92, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit92, standardized=TRUE, fit.measures=TRUE)

##Compare configural and weak model
anova(fit91, fit92)
#check change in CFI, change is .003 so continue testing
fitmeasures(fit91)["cfi"]
fitmeasures(fit92)["cfi"]



## example 9.3 Longitudinal CFA -- Strong Invariance (Loadings & Intercepts)

mod93 <- '
## define latent variables
Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
Pos2 ~~ NA*Pos2
Pos3 ~~ NA*Pos3
Neg2 ~~ NA*Neg2
Neg3 ~~ NA*Neg3

## correlated residuals across time
PosAFF11 ~~ PosAFF12 + PosAFF13
PosAFF12 ~~ PosAFF13
PosAFF21 ~~ PosAFF22 + PosAFF23
PosAFF22 ~~ PosAFF23
PosAFF31 ~~ PosAFF32 + PosAFF33
PosAFF32 ~~ PosAFF33

NegAFF11 ~~ NegAFF12 + NegAFF13
NegAFF12 ~~ NegAFF13
NegAFF21 ~~ NegAFF22 + NegAFF23
NegAFF22 ~~ NegAFF23
NegAFF31 ~~ NegAFF32 + NegAFF33
NegAFF32 ~~ NegAFF33

## constrain intercepts across time
PosAFF11 ~ t1*1
PosAFF21 ~ t2*1
PosAFF31 ~ t3*1
NegAFF11 ~ t4*1
NegAFF21 ~ t5*1
NegAFF31 ~ t6*1

PosAFF12 ~ t1*1
PosAFF22 ~ t2*1
PosAFF32 ~ t3*1
NegAFF12 ~ t4*1
NegAFF22 ~ t5*1
NegAFF32 ~ t6*1

PosAFF13 ~ t1*1
PosAFF23 ~ t2*1
PosAFF33 ~ t3*1
NegAFF13 ~ t4*1
NegAFF23 ~ t5*1
NegAFF33 ~ t6*1

## free latent means at later times (only set the scale once)
Pos2 ~ NA*1
Pos3 ~ NA*1
Neg2 ~ NA*1
Neg3 ~ NA*1
'

fit93 <- cfa(mod93, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit93, standardized=TRUE, fit.measures=TRUE)

##Compare configural and weak model
anova(fit92, fit93)
#check change in CFI, change is .002 so continue testing
fitmeasures(fit92)['cfi']
fitmeasures(fit93)['cfi']



## example Alternate NUll Model

modNULL <- '
## constrain variances across time

PosAFF11 ~~ v1*PosAFF11
PosAFF12 ~~ v1*PosAFF12
PosAFF13 ~~ v1*PosAFF13

PosAFF21 ~~ v2*PosAFF21
PosAFF22 ~~ v2*PosAFF22
PosAFF23 ~~ v2*PosAFF23

PosAFF31 ~~ v3*PosAFF31
PosAFF32 ~~ v3*PosAFF32
PosAFF33 ~~ v3*PosAFF33

NegAFF11 ~~ v4*NegAFF11
NegAFF12 ~~ v4*NegAFF12
NegAFF13 ~~ v4*NegAFF13

NegAFF21 ~~ v5*NegAFF21
NegAFF22 ~~ v5*NegAFF22
NegAFF23 ~~ v5*NegAFF23

NegAFF31 ~~ v6*NegAFF31
NegAFF32 ~~ v6*NegAFF32
NegAFF33 ~~ v6*NegAFF33

## constrain intercepts across time
PosAFF11 ~ t1*1
PosAFF21 ~ t2*1
PosAFF31 ~ t3*1
NegAFF11 ~ t4*1
NegAFF21 ~ t5*1
NegAFF31 ~ t6*1

PosAFF12 ~ t1*1
PosAFF22 ~ t2*1
PosAFF32 ~ t3*1
NegAFF12 ~ t4*1
NegAFF22 ~ t5*1
NegAFF32 ~ t6*1

PosAFF13 ~ t1*1
PosAFF23 ~ t2*1
PosAFF33 ~ t3*1
NegAFF13 ~ t4*1
NegAFF23 ~ t5*1
NegAFF33 ~ t6*1
'

fitNULL <- cfa(modNULL, data=dat, meanstructure=TRUE, std.lv=TRUE)

#without correct null model
fitmeasures(fit93)
#with correct null model
fitmeasures(fit93, baseline.model=fitNULL)



## example 9.4 Longitudinal SEM -- Structural Regression

mod94 <- '
## define latent variables
Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
Pos2 ~~ NA*Pos2
Pos3 ~~ NA*Pos3
Neg2 ~~ NA*Neg2
Neg3 ~~ NA*Neg3

Pos1 ~~ Neg1
Pos2 ~~ Neg2
Pos3 ~~ Neg3

## directional regression paths
Pos2 ~ Pos1 + Neg1
Neg2 ~ Pos1 + Neg1
Pos3 ~ Pos2 + Neg2
Neg3 ~ Pos2 + Neg2

## correlated residuals across time
PosAFF11 ~~ PosAFF12 + PosAFF13
PosAFF12 ~~ PosAFF13
PosAFF21 ~~ PosAFF22 + PosAFF23
PosAFF22 ~~ PosAFF23
PosAFF31 ~~ PosAFF32 + PosAFF33
PosAFF32 ~~ PosAFF33

NegAFF11 ~~ NegAFF12 + NegAFF13
NegAFF12 ~~ NegAFF13
NegAFF21 ~~ NegAFF22 + NegAFF23
NegAFF22 ~~ NegAFF23
NegAFF31 ~~ NegAFF32 + NegAFF33
NegAFF32 ~~ NegAFF33
'

fit94 <- sem(mod94,data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94, standardized=TRUE, fit.measures=TRUE)

#compare with weak invariance model (because this model only has equal loadings)
anova(fit92, fit94)


## example 9.5 Longitudinal SEM -- Structural Regression (cross lagged paths pruned)

mod95 <- '
## define latent variables
Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
Pos2 ~~ NA*Pos2
Pos3 ~~ NA*Pos3
Neg2 ~~ NA*Neg2
Neg3 ~~ NA*Neg3
Pos1 ~~ Neg1
Pos2 ~~ Neg2
Pos3 ~~ Neg3

## directional regression paths
Pos2 ~ Pos1
Pos3 ~ Pos2
Neg2 ~ Neg1
Neg3 ~ Neg2

## correlated residuals across time
PosAFF11 ~~ PosAFF12 + PosAFF13
PosAFF12 ~~ PosAFF13
PosAFF21 ~~ PosAFF22 + PosAFF23
PosAFF22 ~~ PosAFF23
PosAFF31 ~~ PosAFF32 + PosAFF33
PosAFF32 ~~ PosAFF33

NegAFF11 ~~ NegAFF12 + NegAFF13
NegAFF12 ~~ NegAFF13
NegAFF21 ~~ NegAFF22 + NegAFF23
NegAFF22 ~~ NegAFF23
NegAFF31 ~~ NegAFF32 + NegAFF33
NegAFF32 ~~ NegAFF33
'

fit95 <- sem(mod95, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit95, standardized=TRUE, fit.measures=TRUE)

#Compare to weak invariance model
anova(fit92, fit95)

#Fit still worse than CFA, check mod indices
modificationindices(fit95)

#Add in lag 2 autoregressive paths



## example 9.6 Longitudinal SEM -- Structural Regression (more within Affect)

mod96 <- '
## define latent variables
Pos1 =~ L1*PosAFF11 + L2*PosAFF21 + L3*PosAFF31
Pos2 =~ L1*PosAFF12 + L2*PosAFF22 + L3*PosAFF32
Pos3 =~ L1*PosAFF13 + L2*PosAFF23 + L3*PosAFF33
Neg1 =~ L4*NegAFF11 + L5*NegAFF21 + L6*NegAFF31
Neg2 =~ L4*NegAFF12 + L5*NegAFF22 + L6*NegAFF32
Neg3 =~ L4*NegAFF13 + L5*NegAFF23 + L6*NegAFF33

## free latent variances at later times (only set the scale once)
Pos2 ~~ NA*Pos2
Pos3 ~~ NA*Pos3
Neg2 ~~ NA*Neg2
Neg3 ~~ NA*Neg3
Pos1 ~~ Neg1
Pos2 ~~ Neg2
Pos3 ~~ Neg3

## directional regression paths
Pos2 ~ Pos1
Pos3 ~ Pos1
Pos3 ~ Pos2
Neg3 ~ Neg1
Neg2 ~ Neg1
Neg3 ~ Neg2

## correlated residuals across time
PosAFF11 ~~ PosAFF12 + PosAFF13
PosAFF12 ~~ PosAFF13
PosAFF21 ~~ PosAFF22 + PosAFF23
PosAFF22 ~~ PosAFF23
PosAFF31 ~~ PosAFF32 + PosAFF33
PosAFF32 ~~ PosAFF33

NegAFF11 ~~ NegAFF12 + NegAFF13
NegAFF12 ~~ NegAFF13
NegAFF21 ~~ NegAFF22 + NegAFF23
NegAFF22 ~~ NegAFF23
NegAFF31 ~~ NegAFF32 + NegAFF33
NegAFF32 ~~ NegAFF33
'

fit96 <- cfa(mod96, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit96, standardized=TRUE, fit.measures=TRUE)

#Compare to weak invariance model
anova(fit92, fit96)



## data preparation: growth curves

dat2<- read.csv('growth4wave.csv')

summary(dat2)

##Means of negative affect
negMeans<-colMeans(dat2[,5:8])
negMeans

##plot means of neg
plot(1:4, negMeans, type = "l")


##plot first 50 individual trajectories
plot(1:4, dat2[1,5:8], type = 'n', ylim=c(0,5), ylab = 'Negative Affect', xlab = 'Time')

times <- 1:4

for(i in 1:100){
  mod<-lm(t(dat2[i,5:8])~times)
  abline(reg = mod)
}

mod <- lm(negMeans~times)
abline(reg = mod, col = 'red', lwd = 3)


## example 9.7 Latent Growth Curve negative affect

mod97 <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + 1*negT2 + 2*negT3 + 3*negT4
'

fit97 <- growth(mod97, data=dat2)

summary(fit97, standardized=TRUE, fit.measures=TRUE)

# Latent Basis Curve
mod97b <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + negT2 + negT3 + 1*negT4
'

fit97b <- growth(mod97b, data=dat2)

summary(fit97b, standardized=TRUE, fit.measures=TRUE)

anova(fit97, fit97b)


## example 9.8 Latent Growth Curve negative and positive affect 

mod98 <- '
negInt =~ 1*negT1 + 1*negT2 + 1*negT3 + 1*negT4
negSlope =~ 0*negT1 + 1*negT2 + 2*negT3 + 3*negT4

posInt =~ 1*posT1 + 1*posT2 + 1*posT3 + 1*posT4
posSlope =~ 0*posT1 + 1*posT2 + 2*posT3 + 3*posT4

#Have to force positive residuals to equality to estimate
posT1 ~~ th*posT1
posT2 ~~ th*posT2
posT3 ~~ th*posT3
posT4 ~~ th*posT4

'



