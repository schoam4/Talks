#############################
### MLM with R            ###
### Fall Stats Camp 2020  ###
### Alexander Schoemann   ###
#############################

### Three level models ###

library(lme4)
library(lmerTest)
library(foreign)

#Read in loneliness data

#ID1=BEEPNUM;
#ID2=STUDYDAY;
#ID3=SUBNUM;

lonely <- read.csv('loneliness.csv', na.string = '-999')
summary(lonely)
head(lonely)
tail(lonely)

#need to set identifiers as factors
lonely$SUBNUM <- as.factor(lonely$SUBNUM)
lonely$STUDYDAY <- as.factor(lonely$STUDYDAY)
#Create overall identifier
lonely$BEEPNUM <- as.factor(lonely$BEEPNUM)

## How many subjects?
length(levels(lonely$SUBNUM))

# Level identifiers are L3/L2
m0 <- lmer(POSAFF ~ 1 + (1 | SUBNUM/STUDYDAY), 
           data = lonely, REML = FALSE)

summary(m0)

#ICC for proportion of variance
#Level 3
32.522/(43.829+7.581+32.522)
#Level 2
7.581/(43.829+7.581+32.522)

## ICC for expected correlation
#Level 3
32.522/(43.829+7.581+32.522)
#Level 2
(32.522+7.581)/(43.829+7.581+32.522)

#Remove L2
m0a <- lmer(POSAFF ~ 1 + (1|SUBNUM), 
           data = lonely, REML = FALSE)

summary(m0a)

#Remove L3
m0b <- lmer(POSAFF ~ 1 + (1|STUDYDAY:SUBNUM), 
            data = lonely, REML = FALSE)

summary(m0b)

#Fixed L1 predictor
m1 <- lmer(POSAFF ~ 1 + POSINT_1 + (1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1)
#Show fixed effects without scientific notation
fixef(m1)

library(performance)
r2(m1)
r2(m1, by_group = TRUE)


#Random L1 predictor
m1r <- lmer(POSAFF ~ 1 + POSINT_1 + 
            (1 + POSINT_1|SUBNUM/STUDYDAY), 
            data = lonely, REML = FALSE)

summary(m1r)

anova(m1, m1r)

#L2 fixed predictor
m12 <- lmer(POSAFF ~ 1 + WEEKEND + 
            (1 |SUBNUM/STUDYDAY), 
            data = lonely, REML = FALSE)

summary(m12)

#L2 random predictor

#Create variable that is combination of subject and day
lonely$sample <- lonely$STUDYDAY:lonely$SUBNUM

m12r <- lmer(POSAFF ~ 1 + WEEKEND + 
               (1|sample) + (1 + WEEKEND|SUBNUM), 
             data = lonely, REML = FALSE)

summary(m12r)
anova(m12,m12r)

m1ra <- lmer(POSAFF ~ 1 + POSINT_1 + 
          (1 + POSINT_1|sample) + (1 + POSINT_1|SUBNUM), 
          data = lonely, REML = FALSE)

summary(m1ra)

#Only random slope at L2
m1r2 <- lmer(POSAFF ~ 1 + POSINT_1 + 
              (1+ POSINT_1|sample) + (1|SUBNUM),
             data = lonely, REML = FALSE)

summary(m1r2)

#Compare to fixed effect only
anova(m1, m1r2)
#Compare to all random effects
anova(m1r2, m1r)


m2r2 <- lmer(POSAFF ~ 1 + POSINT_1*WEEKEND + 
               (1+ POSINT_1|sample) + (1|SUBNUM),
             data = lonely, REML = FALSE)

summary(m2r2)

m2r3 <- lmer(POSAFF ~ 1 + POSINT_1*UCLASRV + 
                     (1+ POSINT_1|sample) + (1|SUBNUM),
             data = lonely, REML = FALSE)

summary(m2r3)

library(interactions)
sim_slopes(m2r2, pred = POSINT_1, 
           modx = WEEKEND)
# Simple slopes plot
interact_plot(m2r2, pred = POSINT_1, modx = WEEKEND)


#Interaction looking at an interaction between 
# L2 and L3 interaction
m12r2 <- lmer(POSAFF ~ 1 + WEEKEND*UCLASRV + 
                     (1|sample) + (1 + WEEKEND|SUBNUM), 
             data = lonely, REML = FALSE)

summary(m12r2)

sim_slopes(m12r2, pred = WEEKEND, 
           modx = UCLASRV, jnplot = TRUE)

### Cross Classified Models ###

#Data from Hox (2002)

pupcross<-read.dta("https://stats.idre.ucla.edu/stat/stata/examples/mlm_ma_hox/pupcross.dta")

pupcross$pschool <- as.factor(pupcross$pschool)
pupcross$sschool <- as.factor(pupcross$sschool)
pupcross$pXsschool <- pupcross$sschool:pupcross$pschool

m0<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m0)

m1<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + 
           (1|pXsschool), data = pupcross, REML=FALSE)
summary(m1)

#ICCs
#Secondary School
.06447/(.03362+.16817 + .06447 + .48201)
#Primary School
.16817/(.03362+.16817 + .06447 + .48201)
#PrimaryXSecondary School
.03362/(.03362+.16817 + .06447 + .48201)

anova(m0,m1)

m1a<-lmer(achiev ~ pupsex + pupses +
                  (1|sschool) + (1|pschool),
          pupcross, REML=FALSE)
summary(m1a)

m2<-lmer(achiev ~ pupsex + pupses +
                  (1|sschool) + (pupsex|pschool), 
         pupcross, REML=FALSE)
summary(m2)

anova(m1a,m2)

m3<-lmer(achiev ~ pupsex  + pupses +
          (pupses|sschool) + (pupses|pschool), 
         data = pupcross, REML=FALSE)
summary(m3)

anova(m1a,m3)

m4<-lmer(achiev ~ pupsex  + pupses + 
                 pdenom + sdenom +
           (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m4)

m5<-lmer(achiev ~ pupsex  + pupses + 
                 pdenom + sdenom +
           (1|sschool) + (sdenom|pschool), 
         data = pupcross, REML=FALSE)
summary(m5)

anova(m4, m5)



### Binary outcomes ###


#Read in loop data for categorical outcome
#13,007 students in 369 schools
# interested in predicting if students took a science course

loop <- read.csv('loop.csv')
summary(loop)

#null model

mc0 <- glmer(scisub ~ 1 + (1|school), 
             data = loop, family = binomial)
summary(mc0)

#odds of taking a science class
exp(fixef(mc0))
#probability of taking a science class
exp(fixef(mc0)) / (1 + exp(fixef(mc0)))

#ICC
0.4232 / (0.4232 + (pi/3))

#gender (0=boys, 1= girls) and minority (0=no, 1=yes) status as predictors

mc1 <- glmer(scisub ~ 1 + gender + minority + 
               (1|school), data = loop, 
             family = binomial)
summary(mc1)

#odds ratios for fixed predictors
exp(fixef(mc1))

#Random effect
mc2 <- glmer(scisub ~ 1 + gender +
               minority + (gender|school), 
             data = loop, family = binomial)
summary(mc2)

#odds ratios for fixed predictors
exp(fixef(mc2))

#Test random effect
anova(mc1, mc2)

##Example with probit link instead of logit
mc1 <- glmer(scisub ~ 1 + gender +
                minority + (gender|school), 
              data = loop, 
              family = binomial(link = "probit"))
 summary(mc1)

 
 ### Missing Data ###
 
 # Use simchild data
 simchild <- read.csv('simchild.csv', 
                      na.string = '-999999')
 summary(simchild)
 
 
 #lots of missing on CONFLDAD! 1444/5144 = .2807 proportion missing
 
 simchildMISS <- simchild[,c('id', 'SEX', 'GRADE_C', 
                             'CONFLMOM', 'CONFLDAD', 
                             'CLOSEMOM', 'CLOSEDAD')]
 
 
 m1LW <- lmer(CONFLDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
              data = simchildMISS, REML = FALSE)
 summary(m1LW)
 ## Uses 3700 observations, so uses 3700/5144 = 72% of available data
 
 ##impute missing data in simchild
 
 library(mice)
 
 # mice won't pool with lmerTest
 detach(package:lmerTest)
 
 #set up imputation template
 template<- mice(simchildMISS, maxit = 0)
 pred <- template$pred
 meth <- template$method
 
 #set id as the L2 identifier
 pred[4:7,1] <- -2
 pred
 
 #set variable with random slopes (GRADE_C)
 pred[4:7,3] <- 2
 pred
 
 #now set imputation methods (in this case use 2l.pan for speed)
 # In reality I'd use 2l.norm 
 meth
 meth[4:7] <- '2l.pan'
 meth
 
 #Start MI
 # Use only 5 imputation with 10 iterations for speed
 imp <- mice(simchildMISS, m = 5, maxit = 10, 
             meth = meth, pred = pred)
 
 #Imputation diagnostics
 
 #Plot of MCMC chains
 plot(imp)
 
 #Plot observed and imputed data with box plots
 bwplot(imp)
 
 #Run model on all 5 imputed data sets using with and lmer
 
 m1imp <- with(imp, lmer(CONFLDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
                         REML = FALSE), 
               control = lmerControl(optimizer="Nelder_Mead"))
 m2imp <- with(imp, lmer(CONFLDAD ~ 1 + GRADE_C + (1 |id), 
                         REML = FALSE), 
               control = lmerControl(optimizer="Nelder_Mead"))
 
 #pool fixed effects with pool
 m1pool <- pool(m1imp)
 summary(m1pool)
 
 
#Use the mitml package to pool fixed and random effects
library(mitml)
 
#Convert results to mitml objects
m1impa <-  as.mitml.result(m1imp)
m2impa <-  as.mitml.result(m2imp)
 
testEstimates(m1impa, var.comp = T)
 
#Compare nested models
testModels(m1impa, m2impa, method = "D3")
 