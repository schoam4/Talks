#############################
### MLM with R            ###
### Fall Stats Camp 2020  ###
### Alexander Schoemann   ###
#############################


### Introduction to R ###


##R can be a calculator
3+4

3*4

3   ^    5

(12+
    5)/13



##Everything is an object

x <- 3

x

x+4

#You can overwrite existing objects!
x <- c(1,2,3,4,5,6)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('hsb2.csv')

dat1

head(dat1)

tail(dat1)

summary(dat1)


dat2 <- as.data.frame(dat2)

dat2

head(dat2)

tail(dat2)

summary(dat2)

dat1$prog

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

summary(dat1)

summary(dat1$math)

library(psych)

describe(dat1)


##Packages
#Install the mice package
install.packages('mice')

#load the mice package
library(mice)


### Handling Nested Data ###

## Load packages needed
library(lme4)
library(lmerTest)
library(rms)
library(nlme)

##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)

##Disaggregated regression

m1 <- lm(langpost ~ iq_verb, data=SB)
summary(m1)

##Aggregated regression

#use aggregate function to compute group means

langpost<-aggregate(SB$langpost, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)
iq_verb<-aggregate(SB$iq_verb, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)

grpmeans <- data.frame(cbind(langpost$x, iq_verb$x))
names(grpmeans) <- c('langpost', 'iq_verb')

summary(grpmeans)

m2 <- lm(langpost~iq_verb, data=grpmeans)
summary(m2)

##Adjusting standard errors
# use ols function from rms package

m3 <- ols(langpost~iq_verb, data=SB, x=TRUE, y=TRUE)
robcov(m3, cluster=SB$schoolnr)

## Or use clubSandwich package
# Uses the lm() results

library(clubSandwich)
coef_test(m1, vcov = "CR2", 
          cluster = SB$schoolnr, test = "Satterthwaite")

##Fixed effects approach
m4 <- lm(langpost ~ iq_verb + factor(schoolnr), 
         data=SB)
summary(m4)

##ANCOVA (same as fixed effects approach)
m5 <- aov(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m5)


##Seperate regressions

mL <- lmList(langpost~iq_verb|schoolnr, data=SB, 
             pool=FALSE, na.action=na.omit)
summary(mL)

#Get mean intercept and across schools
colMeans(coef(mL))

#Plot seperate regression lines for all schools
plot(SB$iq_verb, SB$langpost, xlab = "iq_verb", ylab = "langpost", type = 'n')

for(i in 1:dim(coef(mL))[[1]]){
  abline(coef=coef(mL)[i,])
  
}

abline(coef = colMeans(coef(mL)), col = "red",
       lwd = 2)

##Multilevel models

m6 <- lmer(langpost~1 + (1 |schoolnr), data = SB, 
           REML = FALSE)
summary(m6)

#compute ICC
19.43/(64.57+19.43)

### Adding Predictors ###

#fixed L1 predictor
m7 <- lmer(langpost~1 + iq_verb + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor

m8 <- lmer(langpost~1 + iq_verb + (1+iq_verb|schoolnr), 
           data = SB, REML = FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m8)

#Compare model with fixed and random slopes

anova(m7, m8)

#confidence interval for all effects
confint(m8)

confint(m8, level = .90)

anova(m6, m7)

#fixed L2 predictor
m9 <- lmer(langpost~1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)

m10 <- lmer(langpost ~ 1 +percmino + iq_verb + 
              (1 + iq_verb|schoolnr), 
           data = SB, REML = FALSE)
summary(m10)


## Effect sizes

(64.57- 42.227)/64.57
(19.43-9.497)/19.43

(64.57- 41.48)/64.57
(19.43 - 65.88)/19.43

# For R2 measures use the performance package
library(performance)

# Overall R2 conditional and marginal
r2(m7)
r2(m8)
r2(m9)

# Level specific R2
r2(m7, by_group = TRUE)
r2(m8, by_group = TRUE) #Doesn't make sense with random slopes!
r2(m9, by_group = TRUE)

#standardized mean difference
m10 <- lmer(langpost~1 + sex + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m10)

sd(SB$langpost)

#Divide by total variance in y
2.5679/9.003676

#Divide by L1 variance in y
2.5679/8.035

# Standardized slopes

# Standardize outcomes and predictors

SB$langpostS <- scale(SB$langpost)
SB$iq_verbS <- scale(SB$iq_verb)
SB$percminoS <- scale(SB$percmino)

# Fit models with L1 and L2 predictors
# DO NOT USE THESE FOR HYPOTHESIS TESTING!
m7S <- lmer(langpostS~1 + iq_verbS + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m7S)

m9S <- lmer(langpostS~1 + percminoS + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m9S)

# Use Hox (2010) computations from raw models

#Slope of verbal IQ
fixef(m7)

#SD verbal IQ
sd(SB$iq_verb)

#SD langpost
sd(SB$langpost)

#Standardized slope
(2.488094*2.06889)/9.003676

### Centering ###

library(dplyr)

SB <- read.csv("SB.csv")

mean(SB$iq_verb)

# Grand mean centering
SB <- mutate(SB, IQV_CGM = iq_verb - 11.83406) 

SB <- mutate(SB, IQV_CGM2 = iq_verb - mean(SB$iq_verb))
# Group mean centering
#Use aggregate command to compute group means
grpmeans<-aggregate(SB$iq_verb, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)
grpmeans
##Rename columns for merging
names(grpmeans)<-c("schoolnr","IQ_GM")
##Merge group means back to data set by school (L2 unit)
SB<-merge(SB,grpmeans,by="schoolnr")
head(SB)
summary(SB)
# Group mean center
SB<- mutate(SB, IQV_CWC = (iq_verb - IQ_GM))
head(SB)
summary(SB)

#Uncentered
m1 <- lmer(langpost ~ 1 + iq_verb + (1 + iq_verb|schoolnr), 
           data=SB, REML=FALSE)
summary(m1)

#Grand mean centered
m1Grand <- lmer(langpost ~ 1 + IQV_CGM + (1 + IQV_CGM|schoolnr),
                data=SB, REML=FALSE)
summary(m1Grand)

#Group mean centered
m1Group <- lmer(langpost ~ 1 + IQV_CWC + (1 + IQV_CWC|schoolnr), 
                data=SB, REML=FALSE)
summary(m1Group)

#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1 + IQV_CWC|schoolnr), data=SB, 
                   REML=FALSE)
summary(m1AddMeans)

##Compare fixed effects...
fixEFF <-rbind(c(fixef(m1),NA),c(fixef(m1Grand),NA),c(fixef(m1Group),NA),fixef(m1AddMeans))
rownames(fixEFF) <- c("uncentered", "Grand Mean Centered", "Group Mean Centered", "Group Mean Centered with means")
colnames(fixEFF)[3] <- "Grp Mean iq_verb"
fixEFF

# Center the group means
SB <- mutate(SB, IQV_GMC = IQ_GM - mean(SB$IQ_GM))
#Group mean centered with means added back in Group means centered
m1AddMeans2 <- lmer(langpost ~ 1 + IQV_CWC + IQV_GMC + 
                      (1 + IQV_CWC|schoolnr), data=SB, REML=FALSE)
summary(m1AddMeans2)

# Center the group means
SB <- mutate(SB, IQV_CONDV = iq_verb - 8)
#Conditional Value centered
m1Cond <- lmer(langpost ~ 1 + IQV_CONDV + 
                 (1 + IQV_CONDV|schoolnr), data=SB, REML=FALSE)
summary(m1Cond)

r2(m1)
r2(m1Grand)
r2(m1Group)
r2(m1AddMeans)

#Refit without random slopes
#Uncentered
m1 <- lmer(langpost ~ 1 + iq_verb + (1 |schoolnr), 
           data=SB, REML=FALSE)
summary(m1)

#Grand mean centered
m1Grand <- lmer(langpost ~ 1 + IQV_CGM + (1 |schoolnr),
                data=SB, REML=FALSE)
summary(m1Grand)

#Group mean centered
m1Group <- lmer(langpost ~ 1 + IQV_CWC + (1 |schoolnr), 
                data=SB, REML=FALSE)
summary(m1Group)

#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1|schoolnr), data=SB, REML=FALSE)
summary(m1AddMeans)
r2(m1, by_group = TRUE)
r2(m1Grand, by_group = TRUE)
r2(m1Group, by_group = TRUE)
r2(m1AddMeans, by_group = TRUE)

# Rescale verbal IQ
SB <- mutate(SB, IQV_RS = iq_verb/5)
#Group mean centered with means added back in Group means centered
m1RS <- lmer(langpost ~ 1 + IQV_RS +  
                      (1 + IQV_RS|schoolnr), data=SB, REML=FALSE)
summary(m1RS)

