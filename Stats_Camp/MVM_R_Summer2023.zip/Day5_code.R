##############################
### MVM with R             ###
### Summer Stats Camp 2023 ###
### Alexander Schoemann    ###
##############################


####Load packages for today
library(lavaan)
library(semPlot)
library(semTools)
library(psych)
library(rockchalk)

### Structural Models

## Data is in a tab delimited file with no names

dat <- read.table("11.Grade7.dat")

# This assigns names to each column in dat
names(dat) <- c("Agency1","Agency2","Agency3",
                "Intrin1","Intrin2","Intrin3",
                "Extrin1","Extrin2","Extrin3",
                "PosAFF1","PosAFF2","PosAFF3",
                "NegAFF1","NegAFF2","NegAFF3",
                "Gender","School2","School3","School4")

## Create scale scores for OLS regression

dat$Agency <- (dat$Agency1 + dat$Agency2 + dat$Agency3)/3
dat$Intrin <- (dat$Intrin1 + dat$Intrin2 + dat$Intrin3)/3
dat$Extrin <- (dat$Extrin1 + dat$Extrin2 + dat$Extrin3)/3
dat$PosAFF <- (dat$PosAFF1 + dat$PosAFF2 + dat$PosAFF3)/3
dat$NegAFF <- (dat$NegAFF1 + dat$NegAFF2 + dat$NegAFF3)/3

################################################################################
## Example 7.1 -- Path model predicting positive affect
################################################################################

mod70 <- lm(PosAFF ~ Agency + Intrin + Extrin, 
            data=dat)
summary(mod70)
standardize(mod70)

mod71 <- '
PosAFF ~ Agency + Intrin + Extrin
'

fit71 <- sem(mod71, data = dat, 
             fixed.x=FALSE)
summary(fit71, fit.measures=TRUE, standardized=TRUE)
#Get r^2
lavInspect(fit71, 'r2')


################################################################################
## Example 7.2 -- Always start with a CFA
################################################################################
mod72 <- ' AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
            ExtrinL =~ Extrin1 + Extrin2 + Extrin3
            PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
            '

fit72 <- cfa(mod72, data=dat, std.lv=TRUE)

summary(fit72, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example 7.3 -- Change CFA to Structural (Latent) Regression
################################################################################
mod73 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3

            PositiveL ~ AgencyL + IntrinL + ExtrinL
'

fit73 <- sem(mod73, data=dat, std.lv=TRUE)

summary(fit73, standardized=TRUE, fit.measures=TRUE)

lavInspect(fit73, 'r2')

semPaths(fit73)

#Use nCharNodes = 0 to print full variable names
semPaths(fit73, "std", nCharNodes = 0)

################################################################################
## Example 7.4 -- Add Negative Affect
################################################################################
mod74 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ AgencyL + IntrinL + ExtrinL
						'

fit74 <- sem(mod74, data=dat, std.lv=TRUE)

summary(fit74, standardized=TRUE, fit.measures=TRUE)

inspect(fit74, 'r2')

## Are slopes different between positive and negative affect?
mod74e <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ b1*AgencyL + b2*IntrinL + b3*ExtrinL
            NegativeL ~ b4*AgencyL + b5*IntrinL + b6*ExtrinL
            
            diffA := b1 - b4
            diffI := b2 - b5
            diffE := b3 - b6
'

fit74e <- sem(mod74e, data=dat, std.lv=TRUE)

summary(fit74e, standardized=TRUE, fit.measures=TRUE)

# Positive predict negative
mod74p <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ PositiveL
						'

fit74p <- sem(mod74p, data=dat, std.lv=TRUE)
summary(fit74p, standardized=TRUE, fit.measures=TRUE)

# Negative predict positive
mod74n <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

            PositiveL ~ AgencyL + IntrinL + ExtrinL
            NegativeL ~ AgencyL + IntrinL + ExtrinL
            PositiveL ~ NegativeL
						'

fit74n <- sem(mod74n, data=dat, std.lv=TRUE)
summary(fit74n, standardized=TRUE, fit.measures=TRUE)

anova(fit74, fit74p, fit74n)

################################################################################
## Example 7.5 -- Trim Non-Significant Paths
################################################################################
mod75 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						PositiveL ~ AgencyL + IntrinL
						NegativeL ~ ExtrinL
						'

fit75 <- sem(mod75, data=dat, std.lv=TRUE)

summary(fit75, standardized=TRUE, fit.measures=TRUE)

#Compare to unpruned model
anova(fit74, fit75)


################################################################################
## Example 7.6 -- Introduce Covariates, regress all constructs on them
################################################################################
mod76 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
						ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						AgencyL ~ Gender + School2 + School3 + School4
						IntrinL ~ Gender + School2 + School3 + School4
						ExtrinL ~ Gender + School2 + School3 + School4
						PositiveL ~ AgencyL + IntrinL + Gender + School2 + School3 + School4
						NegativeL ~ ExtrinL + Gender + School2 + School3 + School4
						'

fit76 <- sem(mod76, data=dat, std.lv=TRUE, fixed.x=TRUE)

summary(fit76, standardized=TRUE, fit.measures=TRUE)


#Gender: 1 = Girl

################################################################################
## Example 7.7 -- Trim Non-Significant Paths (again)
################################################################################
mod77 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
  					ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						IntrinL ~ Gender + School3 
						ExtrinL ~ Gender
						PositiveL ~ AgencyL + IntrinL 
						NegativeL ~ ExtrinL + Gender + School2 
           '

fit77 <-  sem(mod77, data=dat, std.lv=TRUE, fixed.x=FALSE)

summary(fit77, standardized=TRUE, fit.measures=TRUE)

anova(fit76, fit77)#Don't do this different variables!


################################################################################
## Example 7.8 -- Covariate Controls as Semi-Partial Effects
################################################################################
mod78 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
  					ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						PositiveL ~ AgencyL + IntrinL + Gender + School2 + School3 + School4
						NegativeL ~ ExtrinL + Gender + School2 + School3 + School4
						'

fit78 <- sem(mod78, data=dat, std.lv=TRUE)

summary(fit78, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example 7.9 -- Covariate Controls as indirect Effects
################################################################################
mod79 <- 'AgencyL =~ Agency1 + Agency2 + Agency3
            IntrinL =~ Intrin1 + Intrin2 + Intrin3
  					ExtrinL =~ Extrin1 + Extrin2 + Extrin3
						PositiveL =~ PosAFF1 + PosAFF2 + PosAFF3
						NegativeL =~ NegAFF1 + NegAFF2 + NegAFF3

						AgencyL ~ Gender + School2 + School3 + School4
						IntrinL ~ Gender + School2 + School3 + School4
						ExtrinL ~ Gender + School2 + School3 + School4
						PositiveL ~ AgencyL + IntrinL
						NegativeL ~ ExtrinL
						'

fit79 <- sem(mod79, data=dat, std.lv=TRUE)

summary(fit79, standardized=TRUE, fit.measures=TRUE)



#### Mediation

################################################################################
## data preparation
################################################################################

## read raw data file for mediation model
dat <- read.csv("SEMmediation.csv")



################################################################################
## example Structural Regression, with Agency as auxilliary covariate
## C PATHWAY
################################################################################
mod91 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## Covariances
      Agency ~~ Intrin
      Positive ~~ Agency
# Regression
      Positive ~ Intrin
'

fit91 <- sem(mod91, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit91, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Mediation model
################################################################################
mod92 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3

## latent regression
      Agency ~ a*Intrin
      Positive ~ b*Agency + cprime*Intrin
      
## Define indirect effect
ab := a*b
tot := a*b + cprime
'

fit92 <- sem(mod92, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit92, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping
#Only  500 bootstraps to save time. Usually use 1000+
fit92b <- sem(mod92, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit92b, standardized=TRUE, fit.measures=TRUE)


#Get bootstrapped CI
parameterEstimates(fit92b)

##Monte Carlo CI

monteCarloCI(object=fit92,
              rep = 50000, plot=FALSE)


################################################################################
## example Structural Regression, with Intrinsic as auxiliary covariate
################################################################################
mod93 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
      Agency ~~ Intrin
      Positive ~~ Intrin
## latent regression
      Positive ~ Agency
'

fit93 <- sem(mod93, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit93, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Mediation model with Intrisic as the mediator
################################################################################
mod94 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent regression
      Intrin ~ a*Agency
      Positive ~ b*Intrin + Agency

ab := a*b
'

fit94 <- sem(mod94, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping

fit94b <- sem(mod94, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit94b, standardized=TRUE, fit.measures=TRUE)

parameterEstimates(fit94b)

monteCarloCI( object=fit94, plot=FALSE,
              rep = 50000)


### Moderation ###


##Read in data
dat2 <- read.csv('SEMmoderation.csv')

##Create data with orthogonalized terms

dat3 <- indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
                c('meUNK1', 'meUNK2', 'meUNK3'), 
                match=FALSE,
                meanC = FALSE, residualC = TRUE,
                namesProd = c('int1', 'int2', 'int3', 'int4', 'int5',
                              'int6', 'int7', 'int8', 'int9'))

summary(dat3)
round(cor(dat3), 3)

################################################################################
## example "Main effect" Model
################################################################################
mod95a <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
    		Positive =~ PosAFF1 + PosAFF2 + PosAFF3
#Latent regression
				Positive ~ Agency + Unknown 
'

fit95a <- sem(mod95a, data=dat3, std.lv=TRUE, 
              meanstructure=TRUE)

summary(fit95a, fit.measures=TRUE)

################################################################################
## example Moderation model Orthogonalizing
################################################################################
mod95 <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
				Interact =~ int1 + int2 + int3 + int4 + int5 + int6 + int7 + int8 + int9
				Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
				Agency ~~ Unknown
				Agency ~~ 0*Interact
				Unknown ~~ 0*Interact
## latent regression
				Positive ~ Agency + Unknown + Interact
## correlated residuals
				int2 ~~ T1*int1
				int3 ~~ T1*int1
				int3 ~~ T1*int2
				int5 ~~ T2*int4
				int6 ~~ T2*int4
				int6 ~~ T2*int5
				int8 ~~ T3*int7
				int9 ~~ T3*int7
				int9 ~~ T3*int8
				int4 ~~ T4*int1
				int7 ~~ T4*int4
				int7 ~~ T4*int1
				int5 ~~ T5*int2
				int8 ~~ T5*int5
				int8 ~~ T5*int2
				int6 ~~ T6*int3
				int9 ~~ T6*int6
				int9 ~~ T6*int3
'

fit95 <- sem(mod95, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit95, fit.measures=TRUE)


################################################################################
## example Moderation model Double Mean Centering
################################################################################

dat4 <-indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
               c('meUNK1', 'meUNK2', 'meUNK3'), 
               meanC=FALSE, doubleMC =TRUE, 
               namesProd = c('int1', 'int2', 'int3'))

summary(dat4)
round(cor(dat4),3)


mod96 <- '
## define latent variables
Agency =~ agATT1 + agATT2 + agATT3
Unknown =~ meUNK1 + meUNK2 + meUNK3
Interact =~ int1 + int2 + int3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
Agency ~~ Unknown
Agency ~~ Interact
Unknown ~~ Interact
## latent regression
Positive ~ Agency + Unknown + Interact
'

fit96 <- sem(mod96, data=dat4, std.lv=TRUE, meanstructure=TRUE)

summary(fit96, fit.measures=TRUE)

##Create data with double mean centered terms

dat5 <- indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
                c('meUNK1', 'meUNK2', 'meUNK3'), 
                match=FALSE,
                meanC = FALSE, doubleMC = TRUE,
                namesProd = c('int1', 'int2', 'int3', 'int4', 'int5',
                              'int6', 'int7', 'int8', 'int9'))

summary(dat5)
round(cor(dat3), 3)

mod97 <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
				Interact =~ int1 + int2 + int3 + int4 + int5 + int6 + int7 + int8 + int9
				Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
				Agency ~~ Unknown
				Agency ~~ Interact
				Unknown ~~ Interact
## latent regression
				Positive ~ Agency + Unknown + Interact
## correlated residuals
				int2 ~~ T1*int1
				int3 ~~ T1*int1
				int3 ~~ T1*int2
				int5 ~~ T2*int4
				int6 ~~ T2*int4
				int6 ~~ T2*int5
				int8 ~~ T3*int7
				int9 ~~ T3*int7
				int9 ~~ T3*int8
				int4 ~~ T4*int1
				int7 ~~ T4*int4
				int7 ~~ T4*int1
				int5 ~~ T5*int2
				int8 ~~ T5*int5
				int8 ~~ T5*int2
				int6 ~~ T6*int3
				int9 ~~ T6*int6
				int9 ~~ T6*int3
'

fit97 <- sem(mod97, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit97, fit.measures=TRUE)

##Probing interactions

probed <-probe2WayRC(fit95, nameX=c('Agency', 'Unknown', 'Interact'), 
                     nameY='Positive', modVar='Unknown', c(-1, 0, 1))
probed

probe2WayMC(fit97, nameX=c('Agency', 'Unknown', 'Interact'), 
            nameY='Positive', modVar='Unknown', c(-1,1))

plotProbe(probed, c(-1,1))

#########################################
## Extra Examples (if we have time)   ###
#########################################

#### Categorical Indicators

##Example of robust/categorical indicators
##From Brown, chapter 9
##Single factor of alcohol dependence

##Read in data from website
Data <- read.fwf("http://people.bu.edu/tabrown/Ch9/BINARY.DAT", 
                 width = c(1,1,1,1,1,1), n = 750)
names(Data) <- c(paste("y", 1:6, sep = ""))

mod2 <- '
  etoh =~ y1 + y2 + y3 + y4 + y5 + y6
'

#Fit (incorrectly) without specifying categorical data
fit2 <- cfa(mod2, data = Data, std.lv=TRUE)
summary(fit2, fit.measures = TRUE, standardized = TRUE)


#Fit (incorrectly) with robust ML (ignore categorical)
fit3 <- cfa(mod2, data = Data, 
            std.lv=TRUE, estimator = 'mlr')
summary(fit3, fit.measures = TRUE, standardized = TRUE)

#Fit with WLS categorical specification
fit4 <- cfa(mod2, data = Data, ordered = names(Data), 
            std.lv=TRUE)
summary(fit4, fit.measures = TRUE, standardized = TRUE)

fit4 <- cfa(mod2, data = Data, ordered = c("y1", "y2",
                                           "y3", "y4", 
                                           "y5","y6"), 
            std.lv=TRUE)
summary(fit4, fit.measures = TRUE, standardized = TRUE)

fit4d <- cfa(mod2, data = Data, ordered = names(Data), 
             std.lv=TRUE, parameterization = "delta")
summary(fit4d, fit.measures = TRUE, standardized = TRUE)

fit4t <- cfa(mod2, data = Data, ordered = names(Data), 
             std.lv=TRUE, parameterization = "theta")
summary(fit4t, fit.measures = TRUE, standardized = TRUE)



#Fit with ML (experimental) specification
fit5 <- cfa(mod2, data = Data, ordered = names(Data), 
            std.lv=TRUE,
            estimator = 'pml')
summary(fit5, fit.measures = TRUE, standardized = TRUE)

#Nested model with categorical data

mod3 <- '
  etoh =~ l1*y1 + l1*y2 + l1*y3 + l1*y4 + l1*y5 + l1*y6
'

#Fit with WLS categorical specification
fit6 <- cfa(mod3, data = Data, ordered = names(Data), std.lv=TRUE)
summary(fit6, fit.measures = TRUE, standardized = TRUE)

#Compare models
anova(fit4,fit6)

fit7 <- cfa(mod3, data = Data, ordered = names(Data), std.lv=TRUE,
            estimator = 'pml')
summary(fit7, fit.measures = TRUE, standardized = TRUE)

anova(fit5, fit7)

#### Multilevel SEM

#Read in data
datM <- read.csv("msem.csv", na.strings = "-999")

# (incorrect) single level model
mod4 <- '
peer =~ peers1 + peers2 + peers3
bully =~ bully1 + bully2 + bully3
'

fit8 <- cfa(mod4, data = datM, 
            std.lv = TRUE, missing = "ml")
summary(fit8, fit.measures = TRUE, standardized = TRUE)

# Correct standard errors for clustering

fit9 <- cfa(mod4, data = datM, 
            std.lv = TRUE, missing = "ml", 
            cluster = "class")
summary(fit9, fit.measures = TRUE, standardized = TRUE)

#Fit MSEM CFA
mod5 <- '
level: 1
peerW =~ peers1 + peers2 + peers3
bullyW =~ bully1 + bully2 + bully3

level:2
peerB =~ peers1 + peers2 + peers3
bullyB =~ bully1 + bully2 + bully3

'
fit10 <- cfa(mod5, data = datM, std.lv = TRUE, 
              cluster = "class")
summary(fit10, fit.measures = TRUE, standardized = TRUE)


#Add level 2 predictor (class size)

mod6 <- '
level: 1
peerW =~ peers1 + peers2 + peers3
bullyW =~ bully1 + bully2 + bully3

level:2
peerB =~ peers1 + peers2 + peers3
bullyB =~ bully1 + bully2 + bully3

peerB + bullyB ~ class_sz
'
fit11 <- cfa(mod6, data = datM, std.lv = TRUE, cluster = "class")
summary(fit11, fit.measures = TRUE, standardized = TRUE)


#Fit MSEM CFA: test for invariance
mod7 <- '
level: 1
peerW =~ L1*peers1 + L2*peers2 + L3*peers3
bullyW =~ L4*bully1 + L4*bully2 + L5*bully3

level:2
peerB =~ L1*peers1 + L2*peers2 + L3*peers3
bullyB =~ L4*bully1 + L4*bully2 + L5*bully3

'
fit12 <- cfa(mod7, data = datM, std.lv = TRUE, 
              cluster = "class")
summary(fit12, fit.measures = TRUE, standardized = TRUE)
anova(fit10,fit12)


