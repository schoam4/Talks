#############################
### MLM with R            ###
### Spring Stats Camp 2019###
### Alexander Schoemannn  ###
#############################


### Introduction to R ###


##R can be a calculator
3+4

3*4

3   ^    5

(12+
    5)/13



##Everything is an object

x <-3

x

x+4

#You can overwrite existing objects!
x <- c(1,2)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('C:/Users/schoemanna/Documents/Workshops/Stats Camp/MLM_R_Spring2020/hsb2.csv')

dat1

head(dat1)

tail(dat1)

summary(dat1)


dat2 <- as.data.frame(dat2)

dat2

head(dat2)

tail(dat2)

summary(dat2)

dat1$prog

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

summary(dat1)

summary(dat1$math)

library(psych)

describe(dat1)


##Packages
#Install the mice package
install.packages('mice')

#load the mice package
library(mice)


### Handling Nested Data ###

## Load packages needed
library(lme4)
library(lmerTest)
library(rms)
library(nlme)

##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)

##Disaggregated regression

m1 <- lm(langpost~iq_verb, data=SB)
summary(m1)

##Aggregated regression

#use aggregate function to compute group means

langpost<-aggregate(SB$langpost, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)
iq_verb<-aggregate(SB$iq_verb, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)

grpmeans <- data.frame(cbind(langpost$x, iq_verb$x))
names(grpmeans) <- c('langpost', 'iq_verb')

summary(grpmeans)

m2 <- lm(langpost~iq_verb, data=grpmeans)
summary(m2)

##Adjusting standard errors
# use ols function from rms package

m3 <- ols(langpost~iq_verb, data=SB, x=TRUE, y=TRUE)
robcov(m3, cluster=SB$schoolnr)

## Or use clubSandwich package
# Uses the lm() results

library(clubSandwich)
coef_test(m1, vcov = "CR2", 
          cluster = SB$schoolnr, test = "Satterthwaite")

##Fixed effects approach
m4 <- lm(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m4)

##ANCOVA (same as fixed effects approach)
m5 <- aov(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m5)


##Seperate regressions

mL <- lmList(langpost~iq_verb|schoolnr, data=SB, pool=FALSE, na.action=na.omit)
summary(mL)

#Get mean intercept and across schools
colMeans(coef(mL))

#Plot seperate regression lines for all schools
plot(SB$iq_verb, SB$langpost, xlab = "iq_verb", ylab = "langpost", type = 'n')

for(i in 1:dim(coef(mL))[[1]]){
  abline(coef=coef(mL)[i,])
  
}

##Multilevel models

m6 <- lmer(langpost~1 + (1 |schoolnr), data = SB, 
           REML = FALSE)
summary(m6)

#compute ICC
19.43/(64.57+19.43)

### Adding Predictors ###

#fixed L1 predictor
m7 <- lmer(langpost~1 + iq_verb + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor

m8 <- lmer(langpost~1 + iq_verb + (1+iq_verb|schoolnr), 
           data = SB, REML = FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m8)

#Compare model with fixed and random slopes

anova(m7, m8)

#confidence interval for all effects
confint(m8)

#fixed L2 predictor
m9 <- lmer(langpost~1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)

### Interactions ###

##Disaggregated regression with interaction
m1a <- lm(langpost~ iq_verb + groupsiz, 
         data=SB)
summary(m1a)
m1 <- lm(langpost~ iq_verb * groupsiz, 
         data=SB)
summary(m1)

#compute intercept when grpsiz=23
(-.22+.44*23)
#compute slope when grpsiz=23
(3.35+-0.03*23)


#use interactions package to probe
library(interactions)

# Simple slopes and j-n intervals/plot
sim_slopes(m1, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE)
# Simple slopes plot
interact_plot(m1, pred = iq_verb, modx = groupsiz)


##MLM with interaction
m2a <- lmer(langpost~ iq_verb+groupsiz +(1|schoolnr),
            data=SB, REML=FALSE)
summary(m2a)

m2 <- lmer(langpost~ iq_verb*groupsiz +(1|schoolnr),
           data=SB, REML=FALSE)
summary(m2)

# Simple slopes and j-n intervals/plot
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, jnplot = TRUE)
# Simple slopes plot
interact_plot(m2, pred = iq_verb, modx = groupsiz)

# Simple slopes with specified values for the moderator
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, modx.values = c(5,37))

m3a <- lmer(langpost~ iq_verb+percmino +(iq_verb|schoolnr),
data=SB, REML=FALSE)
summary(m3a)

m3 <- lmer(langpost~ iq_verb*percmino +(1 + iq_verb|schoolnr),
            data=SB, REML=FALSE)
summary(m3)

##dichotomous predictor example with Hox data
pop <- read.csv('popular.csv')
summary(pop)
#For variable SEX: boy=0 girl=1
m3a <- lmer(POPULAR ~ SEX + TEXP + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)
summary(m3a)

m3 <- lmer(POPULAR ~ SEX*TEXP + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)
summary(m3)

sim_slopes(m3, pred = TEXP, modx = SEX)
interact_plot(m3, pred = TEXP, modx = SEX)


