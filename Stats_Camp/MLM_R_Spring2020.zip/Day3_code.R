#############################
### MLM with R            ###
### Spring Stats Camp 2020###
### Alexander Schoemannn  ###
#############################

### Three level models ###

library(lme4)
library(lmerTest)
library(foreign)

#Read in loneliness data

#ID1=BEEPNUM;
#ID2=STUDYDAY;
#ID3=SUBNUM;

lonely <- read.csv('loneliness.csv', na.string = '-999')
summary(lonely)
head(lonely)
tail(lonely)

#need to set identifiers as factors
lonely$SUBNUM <- as.factor(lonely$SUBNUM)
lonely$STUDYDAY <- as.factor(lonely$STUDYDAY)
#Create overall identifier
lonely$BEEPNUM <- as.factor(lonely$BEEPNUM)

## How many subjects?
length(levels(lonely$SUBNUM))

m0 <- lmer(POSAFF ~ 1 + (1|SUBNUM/STUDYDAY), 
           data = lonely, REML = FALSE)

summary(m0)

#ICC for proportion of variance
#Level 3
32.522/(43.829+7.581+32.522)
#Level 2
7.581/(43.829+7.581+32.522)

## ICC for expected correlation
#Level 3
32.522/(43.829+7.581+32.522)
#Level 2
(32.522+7.581)/(43.829+7.581+32.522)

#Remove L2
m0a <- lmer(POSAFF ~ 1 + (1|SUBNUM), 
           data = lonely, REML = FALSE)

summary(m0a)

#Remove L3
m0b <- lmer(POSAFF ~ 1 + (1|STUDYDAY:SUBNUM), 
            data = lonely, REML = FALSE)

summary(m0b)

#Fixed L1 predictor
m1 <- lmer(POSAFF ~ 1 + POSINT_1 + (1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1)
#Show fixed effects without scientic notation
fixef(m1)

#Random L1 predictor
m1r <- lmer(POSAFF ~ 1 + POSINT_1 + 
            (1 + POSINT_1|SUBNUM/STUDYDAY), data = lonely, REML = FALSE)

summary(m1r)

anova(m1, m1r)

#L2 fixed predictor
m12 <- lmer(POSAFF ~ 1 + WEEKEND + 
            (1 |SUBNUM/STUDYDAY), data = lonely, REML = FALSE)

summary(m12)

#L2 random predictor

#Create variable that is combination of subject and day
lonely$sample <- lonely$STUDYDAY:lonely$SUBNUM

m12r <- lmer(POSAFF ~ 1 + WEEKEND + 
               (1|sample) + (1 + WEEKEND|SUBNUM), 
             data = lonely, REML = FALSE)

summary(m12r)
anova(m12,m12r)

m1ra <- lmer(POSAFF ~ 1 + POSINT_1 + 
          (1 + POSINT_1|sample) + (1 + POSINT_1|SUBNUM), data = lonely, REML = FALSE)

summary(m1ra)

#Only random slope at L2
m1r2 <- lmer(POSAFF ~ 1 + POSINT_1 + 
              (1+ POSINT_1|sample) + (1|SUBNUM),
             data = lonely, REML = FALSE)

summary(m1r2)

#Compare to fixed effect only
anova(m1, m1r2)
#Compare to all random effects
anova(m1r2, m1r)


m2r2 <- lmer(POSAFF ~ 1 + POSINT_1*WEEKEND + 
               (1+ POSINT_1|sample) + (1|SUBNUM),
             data = lonely, REML = FALSE)

summary(m2r2)

library(interactions)
sim_slopes(m2r2, pred = POSINT_1, 
           modx = WEEKEND)
# Simple slopes plot
interact_plot(m2r2, pred = POSINT_1, modx = WEEKEND)

### Cross Classified Models ###

#Data from Hox (2002)

pupcross<-read.dta("https://stats.idre.ucla.edu/stat/stata/examples/mlm_ma_hox/pupcross.dta")

pupcross$pschool <- as.factor(pupcross$pschool)
pupcross$sschool <- as.factor(pupcross$sschool)
pupcross$pXsschool <- pupcross$sschool:pupcross$pschool

m0<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m0)

m1<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + 
           (1|pXsschool), data = pupcross, REML=FALSE)
summary(m1)

#ICCs
#Secondary School
.06447/(.03362+.16817 + .06447 + .48201)
#Primary School
.16817/(.03362+.16817 + .06447 + .48201)
#PrimaryXSecondary School
.03362/(.03362+.16817 + .06447 + .48201)

anova(m0,m1)

m1a<-lmer(achiev ~ pupsex + pupses +(1|sschool) + (1|pschool),
          pupcross, REML=FALSE)
summary(m1a)

m2<-lmer(achiev ~ pupsex + pupses +
                  (1|sschool) + (pupsex|pschool), 
         pupcross, REML=FALSE)
summary(m2)

anova(m1a,m2)

m3<-lmer(achiev ~ pupsex  + pupses +
           (pupses|sschool) + (pupses|pschool), 
         data = pupcross, REML=FALSE)
summary(m3)

anova(m1a,m3)

m4<-lmer(achiev ~ pupsex  + pupses + pdenom + sdenom +
           (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m4)

m5<-lmer(achiev ~ pupsex  + pupses + pdenom + sdenom +
           (1|sschool) + (sdenom|pschool), 
         data = pupcross, REML=FALSE)
summary(m5)

anova(m4, m5)

### Binary outcomes ###


#Read in loop data for categorical outcome
#13,007 students in 369 schools
# interested in predicting if students took a science course

loop <- read.csv('loop.csv')
summary(loop)

#null model

mc0 <- glmer(scisub ~ 1 + (1|school), 
             data = loop, family = binomial)
summary(mc0)

#odds of taking a science class
exp(fixef(mc0))
#probability of taking a science class
exp(fixef(mc0)) / (1 + exp(fixef(mc0)))

#ICC
0.4232 / (0.4232 + (pi/3))

#gender (0=boys, 1= girls) and minority (0=no, 1=yes) status as predictors

mc1 <- glmer(scisub ~ 1 + gender + minority + 
               (1|school), data = loop, 
             family = binomial)
summary(mc1)

#odds ratios for fixed predictors
exp(fixef(mc1))

#Random effect
mc2 <- glmer(scisub ~ 1 + gender +
               minority + (gender|school), 
             data = loop, family = binomial)
summary(mc2)

#odds ratios for fixed predictors
exp(fixef(mc2))

#Test random effect
anova(mc1, mc2)

##Example with probit link instead of logit
mc1 <- glmer(scisub ~ 1 + gender +
                minority + (gender|school), 
              data = loop, 
              family = binomial(link = "probit"))
 summary(mc1)



