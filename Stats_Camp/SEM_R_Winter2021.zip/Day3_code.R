###############################
### SEM with R              ###
### Winter Stats Camp 2021  ###
### Alexander Schoemann     ###
###############################

####Load packages for today
library(lavaan)
library(semPlot)
library(semTools)
library(psych)


#### Categorical Indicators

##Example of robust/categorical indicators
##From Brown, chapter 9
##Single factor of alcohol dependence

##Read in data from website
Data <- read.fwf("http://people.bu.edu/tabrown/Ch9/BINARY.DAT", 
                 width = c(1,1,1,1,1,1), n = 750)
names(Data) <- c(paste("y", 1:6, sep = ""))

mod2 <- '
  etoh =~ y1 + y2 + y3 + y4 + y5 + y6
'

#Fit (incorrectly) without specifying categorical data
fit2 <- cfa(mod2, data = Data, std.lv=TRUE)
summary(fit2, fit.measures = TRUE, standardized = TRUE)


#Fit (incorrectly) with robust ML (ignore categorical)
fit3 <- cfa(mod2, data = Data, 
            std.lv=TRUE, estimator = 'mlr')
summary(fit3, fit.measures = TRUE, standardized = TRUE)

#Fit with WLS categorical specification
fit4 <- cfa(mod2, data = Data, ordered = names(Data), 
            std.lv=TRUE)
summary(fit4, fit.measures = TRUE, standardized = TRUE)

fit4 <- cfa(mod2, data = Data, ordered = c("y1", "y2",
                                           "y3", "y4", 
                                           "y5", "y6"), 
            std.lv=TRUE)
summary(fit4, fit.measures = TRUE, standardized = TRUE)

fit4d <- cfa(mod2, data = Data, ordered = names(Data), 
            std.lv=TRUE, parameterization = "delta")
summary(fit4d, fit.measures = TRUE, standardized = TRUE)

fit4t <- cfa(mod2, data = Data, ordered = names(Data), 
             std.lv=TRUE, parameterization = "theta")
summary(fit4t, fit.measures = TRUE, standardized = TRUE)



#Fit with ML (experimental) specification
fit5 <- cfa(mod2, data = Data, ordered = names(Data), 
            std.lv=TRUE,
            estimator = 'pml')
summary(fit5, fit.measures = TRUE, standardized = TRUE)

#Nested model with categorical data

mod3 <- '
  etoh =~ l1*y1 + l1*y2 + l1*y3 + l1*y4 + l1*y5 + l1*y6
'

#Fit with WLS categorical specification
fit6 <- cfa(mod3, data = Data, ordered = names(Data), std.lv=TRUE)
summary(fit6, fit.measures = TRUE, standardized = TRUE)

#Compare models
anova(fit4,fit6)

fit7 <- cfa(mod3, data = Data, ordered = names(Data), std.lv=TRUE,
            estimator = 'pml')
summary(fit7, fit.measures = TRUE, standardized = TRUE)

anova(fit5, fit7)

#### Multilevel SEM

#Read in data
datM <- read.csv("msem.csv", na.strings = "-999")

# (incorrect) single level model
mod4 <- '
peer =~ peers1 + peers2 + peers3
bully =~ bully1 + bully2 + bully3
'

fit8 <- cfa(mod4, data = datM, 
            std.lv = TRUE, missing = "ml")
summary(fit8, fit.measures = TRUE, standardized = TRUE)

# Correct standard errors for clustering

fit9 <- cfa(mod4, data = datM, 
            std.lv = TRUE, missing = "ml", 
            cluster = "class")
summary(fit9, fit.measures = TRUE, standardized = TRUE)

#Fit MSEM CFA
mod5 <- '
level: 1
peerW =~ peers1 + peers2 + peers3
bullyW =~ bully1 + bully2 + bully3

level:2
peerB =~ peers1 + peers2 + peers3
bullyB =~ bully1 + bully2 + bully3

'
fit10 <- cfa(mod5, data = datM, effect.coding = TRUE, 
             missing = "ml", cluster = "class")
summary(fit10, fit.measures = TRUE, standardized = TRUE)

datM[datM$class == 1210,]

#Add level 2 predictor (class size)

mod6 <- '
level: 1
peerW =~ peers1 + peers2 + peers3
bullyW =~ bully1 + bully2 + bully3

level:2
peerB =~ peers1 + peers2 + peers3
bullyB =~ bully1 + bully2 + bully3

peerB + bullyB ~ class_sz
'
fit11 <- cfa(mod6, data = datM, std.lv = TRUE, missing = "ml", cluster = "class")
summary(fit11, fit.measures = TRUE, standardized = TRUE)


#Fit MSEM CFA: test for invariance
mod7 <- '
level: 1
peerW =~ L1*peers1 + L2*peers2 + L3*peers3
bullyW =~ L4*bully1 + L4*bully2 + L5*bully3

level:2
peerB =~ L1*peers1 + L2*peers2 + L3*peers3
bullyB =~ L4*bully1 + L4*bully2 + L5*bully3

'
fit12 <- cfa(mod7, data = datM, std.lv = TRUE, 
             missing = "ml", cluster = "class")
summary(fit12, fit.measures = TRUE, standardized = TRUE)
anova(fit10,fit12)
