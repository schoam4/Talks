###############################
### SEM with R              ###
### Winter Stats Camp 2021  ###
### Alexander Schoemann     ###
###############################


### Introduction to R ###


##R can be a calculator
3+4

3*4

3   ^    5

(12+
    5)/13



##Everything is an object

x <- 3

x

x+4

#You can overwrite existing objects!
x <- c(1,2,3,4,5,6)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('hsb2.csv')

dat1

head(dat1)

tail(dat1)

summary(dat1)

dat1a <- read.csv("~/Workshops/Stats Camp/SEM_R_Winter2021/hsb2.csv")

dat2 <- as.data.frame(dat2)

dat2

head(dat2)

tail(dat2)

summary(dat2)

dat1$prog

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

summary(dat1)

summary(dat1$math)

library(psych)

describe(dat1)


##Packages
#Install the mice package
install.packages('mice')

#load the mice package
library(mice)

#Install packages needed for the workshop
#(uncomment and run if these are not installed)
#Note: semPlot has trouble with Macs: http://sachaepskamp.com/semPlot

#install.packages(c("lavaan", "semTools", "simsem", "semPlot", "psych",
#                   "Amelia", "mice", "rockchalk", ))


####Load packages for today
library(lavaan)
library(semPlot)
library(semTools)
library(psych)


####Scale setting and identification 

################################################################################
## data preparation  
################################################################################

#This example uses a covariance matrix
#Usually we'll use raw data
dat <- matrix(c(1, .61251, .61733,
                .61251, 1, .65757,
                .61733, .65757, 1), 3, 3)

rownames(dat) <-c( "Great", "Cheerful", "Happy")
colnames(dat) <-c( "Great", "Cheerful", "Happy")

nObs <- 100

################################################################################
## Example -- Fixed-Factor Method
################################################################################
mod41 <- '
Positive =~ Great + Cheerful + Happy
#Fix factor variance to 1
Positive ~~ 1*Positive
#Residual variances
Great ~~ Great
Cheerful ~~ Cheerful
Happy ~~ Happy
'

fit41 <- lavaan(mod41, sample.cov=dat, 
                sample.nobs = nObs, 
                std.lv=TRUE)

summary(fit41, standardized=TRUE, fit.measures=TRUE)
semPaths(fit41, 'est', nCharNodes = 0)

################################################################################
## Example -- Marker-Variable Method (first variable)
################################################################################
mod42 <- 'Positive =~ 1*Great + Cheerful + Happy
Positive ~~ Positive
Great ~~ Great
Cheerful ~~ Cheerful
Happy ~~ Happy'

fit42 <- lavaan(mod42, sample.cov=dat, 
                sample.nobs = nObs)

summary(fit42, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example -- Marker-Variable Method (second variable)
################################################################################
mod43 <- '
Positive =~ Great + 1*Cheerful + Happy
Positive ~~ Positive
Great ~~ Great
Cheerful ~~ Cheerful
Happy ~~ Happy
'

fit43 <- lavaan(mod43, sample.cov=dat, sample.nobs = nObs)

summary(fit43, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example -- Marker-Variable Method (third variable)
################################################################################
mod44 <- 'Positive =~ Great + Cheerful + 1*Happy
Positive ~~ Positive
Great ~~ Great
Cheerful ~~ Cheerful
Happy ~~ Happy

'

fit44 <- lavaan(mod44, sample.cov=dat, sample.nobs = nObs)

summary(fit44, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example -- Effects-Coding Method
################################################################################

mod45 <- '
          Positive =~ L1*Great + L2*Cheerful + L3*Happy
					L1 == 3 - L2 - L3
          
          Positive ~~ Positive
          Great ~~ Great
          Cheerful ~~ Cheerful
          Happy ~~ Happy
					'

fit45 <- lavaan(mod45, sample.cov = dat, sample.nobs = nObs, 
                std.lv = FALSE, auto.fix.first = FALSE)

summary(fit45, standardized=TRUE, fit.measures=TRUE)

#########NOTE: lavaan has some built in shortcuts#######
#By default lavaan assumes you want to estimate residual variances
#and latent variances and covariances.
#The arguments std.lv effect.coding and auto.fix.first can be used to automatically specify a
#method of scale setting.

#Here's the same model but with the shortcuts

mod46 <- 'Positive =~ Great + Cheerful + Happy'

#Marker variable method is the default
fit46 <- cfa(mod46, sample.cov=dat, 
             sample.nobs = nObs)

summary(fit46, standardized=TRUE, fit.measures=TRUE)

#But it is easy to turn on the fixed factor method
fit47 <- cfa(mod46, sample.cov=dat, sample.nobs = nObs, 
             std.lv=TRUE)

summary(fit47, standardized=TRUE, fit.measures=TRUE)

#But it is easy to turn on the effect coding method
fit48 <- cfa(mod46, sample.cov=dat, 
             sample.nobs = nObs, 
             effect.coding=TRUE)
#Don't worry about the warning here
summary(fit48, standardized=TRUE, fit.measures=TRUE)


#### CFA

################################################################################
## data preparation
################################################################################

## read in example data file
dat <- read.csv('Lec3.CFA.csv')

## look at dat
summary(dat)
round(cor(dat),3)
round(cov(dat),3)

##Find reliability (alpha) using the psych package

#positive affect
alpha(dat[,c("great", "cheerful", "happy")])

#negative affect
alpha(dat[,4:6])


################################################################################
## EFA
################################################################################

##Use the fa function in the psych package.
EFA <- fa(dat, nfactors=2, fm="ml")
EFA


################################################################################
## example  CFA (no fixes)
################################################################################
mod51 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          
          Positive ~~ Negative
					'
fit51 <-  cfa(mod51, data=dat, std.lv=TRUE)

summary(fit51, standardized=TRUE, fit.measures=TRUE)

#Same model with the marker variable
fit51m <-  cfa(mod51, data=dat, std.lv=FALSE)

summary(fit51m, standardized=TRUE, fit.measures=TRUE)

#Create a path diagram with semPlot
semPaths(fit51, 'est')

#same diagram but with standardized estimates
semPaths(fit51, 'std')

#Get observed covariance a model implied covariance matrix
lavInspect(fit51, 'sampstat')

#Get model implied covariance matrix
fitted.values(fit51)

#Get fitted residuals: Observed covariances - Model implied covariances
lavInspect(fit51, 'sampstat')$cov-fitted.values(fit51)$cov

#Or use
residuals(fit51)

#We can also get standardized residuals (difference between the correlation matrices)
residuals(fit51, type='cor')

#Network plot of residuals
semCors(fit51, include = "difference")

#Get modification indices
modificationIndices(fit51)

#sort modification indices largest to smallest
modificationIndices(fit51, sort. = TRUE)

# Only return modification indices > 5
modificationIndices(fit51, minimum.value = 5)


################################################################################
## example CFA with a dual loading
################################################################################
mod52 <- 'Positive =~ great + cheerful + happy + sad
          Negative =~ sad + down + unhappy

          Positive ~~ Negative
  				'
fit52 <-  cfa(mod52, data=dat, std.lv=TRUE)

summary(fit52, standardized=TRUE, fit.measures=TRUE)

semPaths(fit52, 'est')

#Compare residuals
residuals(fit51, type='cor')
residuals(fit52, type='cor')

################################################################################
## example CFA with a correlated residual (withing the Negative construct)
################################################################################
mod53 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          
          down ~~ unhappy

          Positive ~~ Negative
    			'

fit53 <-  cfa(mod53, data=dat, std.lv=TRUE)

summary(fit53, standardized=TRUE, fit.measures=TRUE)

semPaths(fit53, 'est')


################################################################################
## example CFA with a correlated residual (across constructs)
################################################################################
mod54 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          great ~~ sad

          Positive ~~ Negative
      		'

fit54 <-  cfa(mod54, data=dat, std.lv=TRUE)

summary(fit54, standardized=TRUE, fit.measures=TRUE)

semPaths(fit54, 'est')

####Model fit

################################################################################
## example CFA (same as mod51 above)
################################################################################

mod71 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          
          Positive ~~ Negative
					'

fit71 <-  cfa(mod71, data=dat, std.lv=TRUE)

summary(fit71, standardized=TRUE, fit.measures=TRUE)

#Sample covariance matrix
inspect(fit71, 'sampstat')

#Model implied covariance matrix
fitted(fit71)

##Distribution of residuals
#Stem and leaf plot
stem(resid(fit71)$cov)
#Histogram
hist(resid(fit71)$cov)

#More fit measures
fitMeasures(fit71)

#from semTools package
moreFitIndices(fit71)

################################################################################
## example  Null model
################################################################################
mod72 <- 'great ~~ great
          cheerful ~~ cheerful
          happy ~~ happy
          sad ~~ sad
          down ~~ down
          unhappy ~~ unhappy
  				'

fit72 <- sem(mod72, data=dat, orthogonal=TRUE)

summary(fit72, standardized=TRUE, fit.measures=TRUE)

fitted(fit72)

semPaths(fit72, 'est')



################################################################################
## example Orthogonal (uncorrelated) constructs
################################################################################
mod73 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy

          Positive ~~ 0*Negative
         '


fit73 <- cfa(mod73, data=dat, std.lv=TRUE)

summary(fit73, standardized=TRUE, fit.measures=TRUE)

semPaths(fit73, 'est')


#compare models
anova(fit71, fit73)

lavTestLRT(fit71, fit73)

################################################################################
## example Perfectly correlated constructs (i.e., one construct)
################################################################################
mod74 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          
          Positive ~~ -1*Negative
         '

fit74 <- cfa(mod74, data=dat, std.lv=TRUE)

summary(fit74, standardized=TRUE, fit.measures=TRUE)


semPaths(fit74, 'est')


#compare models
anova(fit71, fit74)


################################################################################
## example One Construct
################################################################################
mod75 <- 'PosNeg =~ great + cheerful + happy + 
                    sad + down + unhappy
          '

fit75 <- cfa(mod75, data=dat, std.lv=TRUE)

summary(fit75, standardized=TRUE, fit.measures=TRUE)


semPaths(fit75, 'est')


#compare models
anova(fit71, fit75)


################################################################################
## example Cross-Loading
## Note that with a cross-loading the original model is nested within this model
################################################################################
mod76 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy + great

          Positive ~~ Negative
          '

fit76 <- cfa(mod76, data=dat, std.lv=TRUE)

summary(fit76, standardized=TRUE, fit.measures=TRUE)

#compare models
anova(fit76, fit71)

#Also consider 'practical' considerations. 
#Does the cross loading make sense? What is its magnitude?



################################################################################
## example  Non-nested model
################################################################################
mod77 <- 'Positive =~ sad + cheerful + happy
          Negative =~ great + down + unhappy
          
          Positive ~~ Negative
          '

fit77 <- cfa(mod77, data=dat, std.lv=TRUE)

summary(fit77, standardized=TRUE, fit.measures=TRUE)

#The anova command will still give you a p value. Don't trust it!
anova(fit71,fit77)


###### The net function in semTools provides a diagnostic for if models are nested#####
net(fit71, fit77, fit74)

moreFitIndices(fit77)

#### Multiple groups models

################################################################################
## data preparation
################################################################################

#Read data in 
dat <- read.csv('Lecture6_MG.csv')

dat$Grade <- as.factor(dat$Grade)

summary(dat)
describe(dat)
describeBy(dat, dat$Grade)

################################################################################
## Examples  -- Separate single-Group Models
################################################################################

##Only for example, not needed when fitting
##multiple group model

mod1 <- 'Positive =~ P1 + P2 + P3
         Negative =~ N1 + N2 + N3 

          Positive ~~ Negative
          '


## Fit model to 7th Grade

fitg1 <- cfa(mod1, data=dat[dat$Grade == '7th',],
             std.lv=TRUE)

summary(fitg1, standardized=TRUE, fit.measures=TRUE)

## Same model to 8th Grade

fitg2 <- cfa(mod1, data=dat[dat$Grade == '8th',], std.lv=TRUE)

summary(fitg2, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example -- Configural Invariance Model (Form)
################################################################################

## note, Both groups fit simultaneously, and there are 2 sets of parameter 
## estimates (identical to above), but there is a single set of fit measures

fit1 <- cfa(mod1, data=dat, std.lv=TRUE, 
            group = "Grade")

summary(fit1, standardized=TRUE, fit.measures=TRUE)

semPaths(fit1,'est', panelGroups=TRUE)


## Chi-square for the configural model is the sum of the individual models

fitmeasures(fitg1)["chisq"] + fitmeasures(fitg2)["chisq"]

fitmeasures(fit1)["chisq"]

modindices(fit1)

resid(fit1)

################################################################################
## Examples -- Weak Invariance Models (Loadings)
################################################################################

## Fixed-Factor method of identification

modWeak1 <- 'Positive =~ P1 + P2 + P3
             Negative =~ N1 + N2 + N3 

             Positive ~~ c(1, NA)*Positive
             Negative ~~ c(1, NA)*Negative

             Positive ~~ Negative'

fitWeak1 <- cfa(modWeak1, data=dat, std.lv=TRUE, 
                group = "Grade", 
                group.equal="loadings")

summary(fitWeak1, standardized=TRUE, fit.measures=TRUE)

#Compare configural and weak invariance models
#Non significant nested model test means weak invariance holds
anova(fit1, fitWeak1)

compareFit(config = fit1, weak = fitWeak1)

## Marker-Variable method

modWeak2 <- '
Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

Positive ~~ Positive
Negative ~~ Negative

Positive ~~ Negative

P1 ~ 0*1
P2 ~ 1
P3 ~ 1
N1 ~ 0*1
N2 ~ 1
N3 ~ 1
Positive ~ 1
Negative ~ 1'

fitWeak2 <- cfa(modWeak2, data=dat, group = "Grade", group.equal="loadings")

summary(fitWeak2, standardized=TRUE, fit.measures=TRUE)

#No difference in fit between types of scale setting
anova(fitWeak1, fitWeak2)


## Effects-Coding method

modWeak3 <- 'Positive =~ L11*P1 + L21*P2 + L31*P3
Negative =~ L42*N1 + L52*N2 + L62*N3
Positive ~~ Positive
Negative ~~ Negative
Positive ~~ Negative
P1 ~~ P1
P2 ~~ P2
P3 ~~ P3
N1 ~~ N1
N2 ~~ N2
N3 ~~ N3
P1 ~ c(t1, t7)*1
P2 ~ c(t2, t8)*1
P3 ~ c(t3, t9)*1
N1 ~ c(t4, t10)*1
N2 ~ c(t5, t11)*1
N3 ~ c(t6, t12)*1
Positive ~ 1
Negative ~ 1
t1 == 0 - t2 - t3
t4 == 0 - t5 - t6
t7 == 0 - t8 - t9
t10 == 0 - t11 - t12
L11 == 3 - L21 - L31
L42 == 3 - L52 - L62
'

fitWeak3 <- lavaan(modWeak3, data=dat, meanstructure=TRUE, group = "Grade", 
                   std.lv=FALSE, auto.fix.first=FALSE, group.equal="loadings")

summary(fitWeak3, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Examples -- Strong Invariance Models (Intercepts)
################################################################################

## Fixed-Factor method of identification

modStrong1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

Positive ~~ c(1, NA)*Positive
Negative ~~ c(1, NA)*Negative

Positive ~~ Negative

Positive ~ c(0, NA)*1
Negative ~ c(0, NA)*1
'

fitStrong1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                  group = "Grade", 
                  group.equal=c("loadings","intercepts"))

summary(fitStrong1, standardized=TRUE, fit.measures=TRUE)

## Use univariate Score test (like modification indices) to see
## which equality constraints should be relaxed (if any)

lavTestScore(fitStrong1, cumulative = TRUE)

parameterestimates(fitStrong1)

#Example partial invariance
fitStrong1m <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                   group = "Grade", 
                   group.equal=c("loadings","intercepts"),
                   group.partial = "P2~1")

summary(fitStrong1m, standardized=TRUE, fit.measures=TRUE)

#Compare weak and Strong invariance models
#Non signficanct nested model test means strong invariance holds
anova(fitWeak1, fitStrong1)

compareFit(config = fit1, weak = fitWeak1, strong = fitStrong1)


## Marker-Variable method

modStrong2 <- '
Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3 

Positive ~~ Positive
Negative ~~ Negative

Positive ~~ Negative

P1 ~ 0*1
P2 ~ 1
P3 ~ 1
N1 ~ 0*1
N2 ~ 1
N3 ~ 1
Positive ~ 1
Negative ~ 1'

fitStrong2 <- cfa(modStrong2, data=dat, 
                  group = "Grade", 
                  group.equal=c("loadings","intercepts"))

summary(fitStrong2, standardized=TRUE, fit.measures=TRUE)

#No difference in fit between types of scale setting
anova(fitStrong1, fitStrong2)


## Effects-Coding method

modStrong3 <- 'Positive =~ L11*P1 + L21*P2 + L31*P3
Negative =~ L42*N1 + L52*N2 + L62*N3
Positive ~~ Positive
Negative ~~ Negative
Positive ~~ Negative
P1 ~~ P1
P2 ~~ P2
P3 ~~ P3
N1 ~~ N1
N2 ~~ N2
N3 ~~ N3
P1 ~ t1*1
P2 ~ t2*1
P3 ~ t3*1
N1 ~ t4*1
N2 ~ t5*1
N3 ~ t6*1
Positive ~ 1
Negative ~ 1
t1 == 0 - t2 - t3
t4 == 0 - t5 - t6
L11 == 3 - L21 - L31
L42 == 3 - L52 - L62
'

fitStrong3 <- lavaan(modStrong3, data=dat,
                     meanstructure=TRUE, group = "Grade", 
                     std.lv=FALSE, auto.fix.first=FALSE, 
                     group.equal=c("loadings","intercepts"))

summary(fitStrong3, standardized=TRUE, fit.measures=TRUE)

###Note: Latent means are equal to means of scale scores
### with effects coding

dat$positive <- (dat$P1 + dat$P2 + dat$P3)/3
dat$negative <- (dat$N1 + dat$N2 + dat$N3)/3

describeBy(dat[,c("positive", "negative")], dat$Grade)

lavInspect(fitStrong3, "mean.lv")

################################################################################
## Example -- measEQ.syntax function
################################################################################

#Here's something cool


mod <- 'Positive =~ P1 + P2 + P3
         Negative =~ N1 + N2 + N3 
          '

confMod <-measEq.syntax(mod, data=dat, 
                        group = "Grade", 
                        return.fit = TRUE )
summary(confMod)

weakMod <-measEq.syntax(mod, data=dat, 
                        group = "Grade", return.fit = TRUE, 
                        group.equal = "loadings" )
summary(weakMod)

strongMod <-measEq.syntax(mod, data=dat, 
                          group = "Grade", return.fit = TRUE, 
                          group.equal = c("loadings", "intercepts") )
summary(strongMod)

compareFit(configural = confMod, weak = weakMod, strong = strongMod)

################################################################################
## Example -- Mean invariance
################################################################################

## fixed factor example
fitMean1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                group = "Grade", 
                group.equal=c("loadings","intercepts", "means"))

summary(fitMean1, standardized=TRUE, fit.measures=TRUE)

#Test of mean invariance
#Means do not differ across groups
anova(fitStrong1, fitMean1)


## effects coding 

fitMean3 <- lavaan(modStrong3, data=dat, meanstructure=TRUE, 
                   group = "Grade", 
                   std.lv=FALSE, auto.fix.first=FALSE, 
                   group.equal=c("loadings","intercepts", "means"))

summary(fitMean3, standardized=TRUE, fit.measures=TRUE)

#Test of mean invariance
#Means do not differ across groups
anova(fitStrong3, fitMean3)


################################################################################
## Example -- Variance/covariance invariance
################################################################################

fitVCOV1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
                group = "Grade", 
                group.equal=c("loadings","intercepts", 
                              "lv.variances", "lv.covariances"))

summary(fitVCOV1, standardized=TRUE, fit.measures=TRUE)

#Test of variance/covariance invariance
#Variances or covariances differ across groups
anova(fitStrong1, fitVCOV1)

## Effects coding

fitVCOV3 <- lavaan(modStrong3, data=dat, meanstructure=TRUE, 
                   group = "Grade", 
                   std.lv=FALSE, auto.fix.first=FALSE, 
                   group.equal=c("loadings","intercepts", 
                                 "lv.variances", "lv.covariances"))

summary(fitVCOV3, standardized=TRUE, fit.measures=TRUE)

#Test of variance/covariance invariance
#Variances or covariances differ across groups
anova(fitStrong3, fitVCOV3)


################################################################################
## Example -- Variance invariance
################################################################################

fitVar1 <- cfa(modStrong1, data=dat, std.lv=TRUE, 
               group = "Grade", 
               group.equal=c("loadings","intercepts", 
                             "lv.variances"))

summary(fitVar1, standardized=TRUE, fit.measures=TRUE)

#Test of variance invariance
#Variances do not differ across groups
#But for teaching purposes let's pretend they did...
anova(fitStrong1, fitVar1)

#Test latent covariances
anova(fitVar1, fitVCOV1)

##Effects coding

fitVar3 <- lavaan(modStrong3, data=dat, meanstructure=TRUE, 
                  group = "Grade", 
                  std.lv=FALSE, auto.fix.first=FALSE, 
                  group.equal=c("loadings","intercepts", 
                                "lv.variances"))

summary(fitVar3, standardized=TRUE, fit.measures=TRUE)

#Test of variance invariance
#Variances do not differ across groups
#But for teaching purposes let's pretend they did...
anova(fitStrong3, fitVar3)

anova(fitVar3, fitVCOV3)
################################################################################
## Example -- Phantom Variables
################################################################################


modPh1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3

#Fix loading to 1 in first group for scale setting
PhPos =~ c(1, NA)*Positive
PhNeg =~ c(1, NA)*Negative

Positive ~~ c(0, 0)*Positive
Negative ~~ c(0, 0)*Negative
PhPos ~~ c(1, 1)*PhPos
PhNeg ~~ c(1, 1)*PhNeg

Positive ~~ c(0, 0)*Negative
PhPos ~~ PhNeg
PhPos ~~ c(0, 0)*Negative
PhNeg ~~ c(0, 0)*Positive

Positive ~ 1
Negative ~ 1
PhPos ~ 0*1
PhNeg ~ 0*1

'

fitPh1 <- cfa(modPh1, data=dat, meanstructure=TRUE, 
              group = "Grade", 
              std.lv=TRUE, auto.fix.first=FALSE, 
              group.equal=c("loadings","intercepts"),
              group.partial = c('PhPos =~ Positive','PhNeg =~ Negative'))


summary(fitPh1, standardized=TRUE, fit.measures=TRUE)


#Equate latent correlations
fitPhCOR1 <- cfa(modPh1, data=dat, meanstructure=TRUE, 
                 group = "Grade", 
                 std.lv=TRUE, auto.fix.first=FALSE, 
                 group.equal=c("loadings","intercepts" , "lv.covariances"),
                 group.partial = c('PhPos =~ Positive','PhNeg =~ Negative'))


summary(fitPhCOR1, standardized=TRUE, fit.measures=TRUE)


#Test of equality of latent correlations
#Correlation between positive and negative affect differs across groups
anova(fitPh1, fitPhCOR1)


## Effects Coding

modPh3 <- 'Positive =~ L11*P1 + L21*P2 + L31*P3
Negative =~ L42*N1 + L52*N2 + L62*N3

PhPos =~ Positive
PhNeg =~ Negative

Positive ~~ c(0, 0)*Positive
Negative ~~ c(0, 0)*Negative
PhPos ~~ c(1, 1)*PhPos
PhNeg ~~ c(1, 1)*PhNeg

Positive ~~ c(0, 0)*Negative
PhPos ~~ PhNeg
PhPos ~~ c(0, 0)*Negative
PhNeg ~~ c(0, 0)*Positive

P1 ~~ P1
P2 ~~ P2
P3 ~~ P3
N1 ~~ N1
N2 ~~ N2
N3 ~~ N3
P1 ~ t1*1
P2 ~ t2*1
P3 ~ t3*1
N1 ~ t4*1
N2 ~ t5*1
N3 ~ t6*1
Positive ~ 1
Negative ~ 1
PhPos ~ 0*1
PhNeg ~ 0*1
t1 == 0 - t2 - t3
t4 == 0 - t5 - t6
L11 == 3 - L21 - L31
L42 == 3 - L52 - L62
'
fitPh3 <- lavaan(modPh3, data=dat, meanstructure=TRUE, 
                 group = "Grade", 
                 std.lv=FALSE, auto.fix.first=FALSE, 
                 group.equal=c("loadings","intercepts"), 
                 group.partial = c('PhPos =~ Positive',
                                   'PhNeg =~ Negative'))


summary(fitPh3, standardized=TRUE, fit.measures=TRUE)


#Equate latent correlations
fitPhCOR3 <- lavaan(modPh3, data=dat, meanstructure=TRUE, group = "Grade", 
                    std.lv=FALSE, auto.fix.first=FALSE, 
                    group.equal=c("loadings","intercepts", "lv.covariances"), 
                    group.partial = c('PhPos =~ Positive','PhNeg =~ Negative'))

summary(fitPhCOR3, standardized=TRUE, fit.measures=TRUE)


#Test of equality of latent correlations
#Correlation between positive and negative affect differs across groups
anova(fitPh3, fitPhCOR3)


##Effect sizes

#Cohen's d from lsr package
#install.packages('lsr')
library(lsr)
cohensD(positive~Grade, data=dat)

#latent d

(3.07-2.97)/sqrt(((380*.36+379*.44)/(380+379)))

## Testing


mod1 <- 'Positive =~ P1 + P2 + P3
         Negative =~ N1 + N2 + N3 

          '


## Weak invariance, lavaan automatically frees latent 
## variances in second and third groups

fitWTest <- cfa(mod1, data=dat,
             std.lv=TRUE, group = "Grade", 
             group.equal=c("loadings"))
summary(fitWTest)

## Same for strong invariance
fitSTest <- cfa(mod1, data=dat,
                std.lv=TRUE, group = "Grade", 
                group.equal=c("loadings", "intercepts"))
summary(fitSTest)

## effect.coding option works with multiple groups
fitWTest1 <- cfa(mod1, data=dat,
                effect.coding=TRUE, group = "Grade", 
                group.equal=c("loadings"))
summary(fitWTest1)

## Same for strong invariance
fitSTest1 <- cfa(mod1, data=dat,
                 effect.coding=TRUE, group = "Grade", 
                group.equal=c("loadings", "intercepts"))
summary(fitSTest1)
