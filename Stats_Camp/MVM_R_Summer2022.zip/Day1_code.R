##############################
### MVM with R             ###
### Summer Stats Camp 2022 ###
### Alexander Schoemann    ###
##############################


### Introduction to R ###

# This is a comment about stuff in R
# R is super cool

##R can be a calculator
3+4

3*4

3   ^    5

(12+
    5)/13



##Everything is an object

x <- 3

x

x+4

#Create a vector

c(1,2,3,4)

y <- c(1,2,3,4)

y

y + 3

y + x

mean(y+x)

#Character vector

char <- c("a1", "b2", "c3")

#Logical vector
yl <- y == 2

yl1 <- y < 3

yl2 <- y <= 3

charl <- char == "c3"

# Use is. and as. to check and convert vectors
is.logical(yl)
is.logical(y)

as.numeric(yl)

as.character(y)

#You can overwrite existing objects!
x <- c(1,2)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('C:/Users/schoemanna/Documents/Workshops/Stats Camp/MVM_R_Summer2021/hsb2.csv', 
                 stringsAsFactors = TRUE)

dat1

head(dat1)

tail(dat1)

summary(dat1)

library(haven)

dat2 <- read_spss('hsb2.sav')

dat2

head(dat2)

tail(dat2)

summary(dat2)

dat2 <- as.data.frame(dat2)

dat1$prog

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

dat1$progN <- as.numeric(dat1$prog)

summary(dat1)

summary(dat1$math)

library(rockchalk)

summarize(dat1)

library(psych)

describe(dat1)

##Plotting!

plot(dat1)

plot(dat1$math)

plot(dat1$prog)

plot(dat1$math, dat1$science)

plot(dat1$prog, dat1$math)

hist(dat1$math)

boxplot(dat1$math)

##Packages
#Install the mice package
install.packages('mice')

install.packages('haven')

#load the mice package
library(mice)

##Data manipulation

#Create total score using base R
dat1$tot <- (dat1$read + dat1$write + dat1$math + dat1$science +
               dat1$socst)/5

dat1$STEM <- (dat1$math + dat1$science)/2

## Same thing with dplyr
#install.packages('dplyr') #Run if dplyr is not installed
library(dplyr)

dat1 <- mutate(dat1, tot2 =  (read + write + math +
                             science + socst)/5,
                   STEM2 = (math + science)/2)

dat1 <- mutate(dat1, tot3 =  mean(c(read, write, math,
                                science, socst)),
               STEM3 = max(math, science)) ## Not working now

##Analyses

t.test(write ~ female, data=dat1)

t.test(dat1$write, dat1$science, paired = TRUE)

library(lsr)

independentSamplesTTest(write ~ female, data=dat1)

pairedSamplesTTest(~ write + science, data = dat1)

### Regression ###

mod0 <- lm(math ~ 1, data=dat1)

summary(mod0)

mod1 <- lm(math ~ schtyp + science, data=dat1)

summary(mod1)

dat1$schtyp <- as.factor(dat1$schtyp)

mod1c <- lm(math ~ schtyp + science, data=dat1)

summary(mod1c)

#Compare to a model with only science as a predictor
mod2 <- lm(math ~ science, data=dat1)

summary(mod2)
anova(mod2, mod1)

## Confidence Intervals for parameters
confint(mod1)

## Standardized coefficients
## Maybe not the best thing here...
library(effectsize)
effectsize(mod1)

#partial r2
eta_squared(mod1, partial = TRUE)
#semi-partial r2
eta_squared(mod1, partial = FALSE)


## CI for R2
library(MBESS)

## CI for R2 for model 1
ci.R2(.4011, 2, 197, conf.level = .90)

## CI for R2 difference
ci.R2(.0033, 1, 198, conf.level = .90)

#Report most results together with apaTables
library(apaTables)

apa.reg.table(mod1)

#90% CIs
apa.reg.table(mod1, prop.var.conf.level = 0.90)

#Output as Word
apa.reg.table(mod1, filename = "test.doc",prop.var.conf.level = 0.90)


apa.reg.table(mod2, mod1)

apa.cor.table(dat1[,c("science", "math", "read")])

## We will use the car package for diagnostics
library(car)

#Now we can pull everything we want out of the 
#mod1 object

#Influence measures
influence.measures(mod1)

#often this prints too much so we look at each one alone

#residuals
resid(mod1)

#Standardized Residuals
rstandard(mod1)

#Studentized Residuals
rstudent(mod1)

rconcern <- rstudent(mod1) > 3
dat1[rconcern,]

rconcern <- rstudent(mod1) < -3
dat1[rconcern,]


#leverage
hatvalues(mod1)

concern <- hatvalues(mod1) > .045

#Find cases to investigate
dat1[concern,]

# Cook's d
cooks.distance(mod1)

Cconcern <- cooks.distance(mod1) > 1
dat1[Cconcern,]

dat1a <- dat1[-21,]

mod1r <- lm(math ~ schtyp + science, 
            data=dat1, subset = !concern)
summary(mod1r)

#dfbetas
dfbetas(mod1)

#Plotting a regression object gives you 4 plots
#including residual plot and q-q plots

plot(mod1)

#We can also pull out specific plots with the which command

#Residuals plot
plot(mod1, which = 1)

#q-q plot of residuals
plot(mod1, which = 2)

hist(resid(mod1))

#Can also use the car package for this
influenceIndexPlot(mod1)
influencePlot(mod1)

#Multicollinearity

#VIF 
vif(mod1)

#Tolerance
1/vif(mod1)


#Model with the categorical variance prog

#note for prog: 1 = general, 2 = academic, 3 = vocational
## By default R uses dummy coding with the first category as the baseline
mod3 <- lm(math ~ schtyp + science + prog, data=dat1)
summary(mod3)
anova(mod3)
anova(mod1,mod3)

apa.reg.table(mod1, mod3)

## The C command (in the regression formula) can change defaults
mod4 <- lm(math ~ schtyp + science + C(prog, base = 2), 
           data=dat1)
summary(mod4)
anova(mod1,mod4)

levels(dat1$prog) <- c("general", "academic", "vocational")

dat1$ses <- as.factor(dat1$ses)
## The C command (in the regression formula) can change defaults
mod5 <- lm(math ~ schtyp + science + prog + ses, data=dat1)
summary(mod5)
anova(mod4,mod5)

mod5a <- lm(math ~ schtyp + science + ses, data=dat1)
summary(mod5a)
anova(mod5a,mod5)#test of program type controlling for SES...


mod5 <- lm(math ~ prog, data=dat1)
summary(mod5)

mod5m <- lm(math ~ 0 + prog, data=dat1)
summary(mod5m)


library(emmeans)

emmeans(mod5, "prog")



emmeans(mod4, "prog")

emmeans(mod4, "prog", by = "schtyp")


## Example heteroscedastic corrected standard errors

library(sandwich)
library(lmtest)

coeftest(mod4, vcov = vcovHC)


