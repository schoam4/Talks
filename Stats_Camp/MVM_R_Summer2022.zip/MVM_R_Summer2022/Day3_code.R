##############################
### MVM with R             ###
### Summer Stats Camp 2022 ###
### Alexander Schoemann    ###
##############################

library(lme4)
library(lmerTest)
library(nlme)
library(interactions)
library(dplyr)
library(clubSandwich)

### Multilevel Modeling ###

### Handling Nested Data ###


##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)

##Disaggregated regression

m1 <- lm(langpost ~ iq_verb, data=SB)
summary(m1)

##Aggregated regression

#use summarise function to compute group means
grpmeans<-summarise(group_by(SB, schoolnr), 
                    iq_verb = mean(iq_verb),
                    langpost = mean(langpost))
grpmeans

summary(grpmeans)

m2 <- lm(langpost~iq_verb, data=grpmeans)
summary(m2)

##Adjusting standard errors
## use clubSandwich package
# Uses the lm() results from disagregated regression

coef_test(m1, vcov = "CR2", 
          cluster = SB$schoolnr, 
          test = "Satterthwaite")

##Fixed effects approach
m4 <- lm(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m4)

##ANCOVA (same as fixed effects approach)
m5 <- aov(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m5)


##Seperate regressions

mL <- lmList(langpost~iq_verb|schoolnr, data=SB, 
             pool=FALSE, na.action=na.omit)
summary(mL)

#Get mean intercept and across schools
colMeans(coef(mL))

#Plot seperate regression lines for all schools
plot(SB$iq_verb, SB$langpost, xlab = "iq_verb", ylab = "langpost", type = 'n')

for(i in 1:dim(coef(mL))[[1]]){
  abline(coef=coef(mL)[i,])
  
}




##Multilevel models

m6 <- lmer(langpost~ 1 + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m6)

as.data.frame(VarCorr(m6))

#compute ICC
19.43/(64.57+19.43)

### Adding Predictors ###

#fixed L1 predictor
m7 <- lmer(langpost~ 1 + iq_verb + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor

m8 <- lmer(langpost ~ 1 + iq_verb + (1+iq_verb|schoolnr), 
           data = SB, REML = FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m8, correlation = FALSE)

#Compare model with fixed and random slopes

anova(m7, m8)

#use ranova to test random effects
ranova(m8)

#confidence interval for all effects
confint(m8)

confint(m8, level = .90)

#fixed L2 predictor
m9 <- lmer(langpost~1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)

#fixed L2 predictor
m10 <- lmer(langpost ~ 1 + iq_verb + percmino + sex + (1+iq_verb|schoolnr), 
            data = SB, REML = FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))

summary(m10)


## Effect sizes

#Level specific r2 "by hand" for random slopes model
(64.57- 41.48)/64.57
(19.43 - 65.88)/19.43

# For R2 measures use the performance package
library(performance)

# Overall R2 conditional and marginal
r2(m7)
r2(m8)
r2(m9)

# Level specific R2
r2(m7, by_group = TRUE)
r2(m8, by_group = TRUE) #Doesn't make sense with random slopes!
r2(m9, by_group = TRUE)

# Rights and Sterba R2 from r2mlm
library(r2mlm)

r2mlm(m7)
r2mlm(m8)
r2mlm(m9)

#standardized mean difference
m10 <- lmer(langpost~1 + sex + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m10)

sd(SB$langpost)


2.5679/9.003676

# Standardized slopes

# Standardize outcomes and predictors

SB$langpostS <- scale(SB$langpost)
SB$iq_verbS <- scale(SB$iq_verb)
SB$percminoS <- scale(SB$percmino)

# Fit models with L1 and L2 predictors
# DO NOT USE THESE FOR HYPOTHESIS TESTING!
m7S <- lmer(langpostS~1 + iq_verbS + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m7S)

m9S <- lmer(langpostS~1 + percminoS + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m9S)

# Use Hox (2010) computations from raw models

#Slope of verbal IQ
fixef(m7)

#SD verbal IQ
sd(SB$iq_verb)

#SD langpost
sd(SB$langpost)

#Standardized slope
(2.488094*2.06889)/9.003676


### Interactions ###


##MLM with interaction
m2a <- lmer(langpost~ iq_verb+groupsiz +
              (1 + iq_verb|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m2a)

m2 <- lmer(langpost~ iq_verb*groupsiz +
             (1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m2)

#R2 for random slope
(0.2024-0.1661)/0.2024

# Simple slopes and j-n intervals/plot
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, jnplot = TRUE)
# Simple slopes plot
interact_plot(m2, pred = iq_verb, modx = groupsiz)

# Simple slopes with specified values for the moderator
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, modx.values = c(5,37))

sim_slopes(m2, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, modx.values = "terciles")

# Simple slopes and j-n intervals/plot switch moderator
sim_slopes(m2, pred = groupsiz, 
           modx = iq_verb, jnplot = TRUE)


### Longitudinal Data ###



##Read in simchild data

simchild <- read.csv('simchild.csv', 
                      na.string = '-999999')
summary(simchild)
head(simchild)

#Fit model with fixed intercept, fixed slope. 
#Need to do this with regression
m1 <- lm(CLOSEDAD ~ 1 + GRADE_C, data = simchild)
summary(m1)

#Null model
m0a <- lmer(CLOSEDAD ~ 1 +  (1|id), data = simchild, 
            REML = FALSE)
summary(m0a)

#ICC
10.09/(10.09+7.85)

#Fit model with random intercept, fixed slope
m1a <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1|id), 
            data = simchild, 
            REML = FALSE)
summary(m1a)

#Fit model with fixed intercept, random slope
m1b <- lmer(CLOSEDAD ~ 1 + GRADE_C + (0 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1b)

#Fit model with random intercept, random slope
m1c <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1c, correlation = FALSE)

#Random intercept, random slope model with uncentered data
m1d <- lmer(CLOSEDAD ~ 1 + GRADE + (1 + GRADE|id), 
            data = simchild, REML = FALSE)
summary(m1d)

#Compare models
anova(m1a,m1c)
anova(m1b, m1c)

#profile CI for random intercepts and slopes
#this might take a while...
confint(m1c, method="profile")

confint(m1c, method="profile", level = .90)

#Random intercept, random slope model with rescaled time

simchild$dec <- simchild$GRADE_C/10

m1e <- lmer(CLOSEDAD ~ 1 + dec + (1 + dec|id), 
            data = simchild, REML = FALSE)
summary(m1e)


##The aperature for this model Tau_0,1/Tau_1,1

#Compute covariance (only get correlation in lmer)
tauCor <- matrix(c(1,.47, .47, 1), byrow=TRUE, nrow=2)
library(lavaan)
tauCov <- cor2cov(tauCor, c(2.5775, 0.3904))

#apature
-tauCov[1,2]/tauCov[2,2]

#Create new time variable
simchild$NEW_GRADE <- simchild$GRADE_C - (-tauCov[1,2]/tauCov[2,2])

#Fit model with random intercept, random slope
m1cAP <- lmer(CLOSEDAD ~ 1 + NEW_GRADE + (1 + NEW_GRADE|id), 
              data = simchild, REML = FALSE)
summary(m1cAP)

confint(m1cAP, method="profile", level = .90)

##Does gender predict growth? Use CONFLMOM now
## Boys = 1, girls = 0

##Predicting intercept only
m1d <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1d)


##Predicting intercept and slope
m1f <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + GRADE_C*SEX + 
              (1 + GRADE_C|id),
            data = simchild, REML = FALSE)
summary(m1f)

#Probe interaction between time and SEX
library(interactions)
sim_slopes(m1f, pred = GRADE_C, modx = SEX)
interact_plot(m1f, pred = GRADE_C, modx = SEX)


#Time varying covariate. Change in CLOSEDAD controlling for CLOSEMOM
#Time varying covariate should be centered so the intercept is interpretable
m1h <- lmer(CLOSEDAD ~ 1 + GRADE_C + CLOSEMOM + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1h)

#Random intercept, random slope model with quadratic data
simchild$GRADE_C2 <- simchild$GRADE_C*simchild$GRADE_C 
m1d2 <- lmer(CLOSEDAD ~ 1 + GRADE_C + GRADE_C2 + 
               (1 + GRADE_C + GRADE_C2|id), 
            data = simchild, REML = FALSE,
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m1d2)

anova(m1c, m1d2)

#Plot results
#Get slopes
slopes <- fixef(m1d2)
#Get values of time
GRADE <- 0:5
GRADE2 <- GRADE*GRADE

y <- slopes[1] + slopes[2]*GRADE + slopes[3]*GRADE2

plot(GRADE, y, type = "l")

## Complex Error Structures 

#homoscedastic  errors
m1 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML')
summary(m1)

#let errors vary...

m2 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          weights = varIdent(form = ~1|GRADE_C))
summary(m2)

#Should we use heteroscedastic  errors?
anova(m1,m2)

#Add an AR1 correlation structure
m3 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          corr = corAR1())
summary(m3)

anova(m1,m3)

#Add AR1 and heteroskedasticy. Need to increase iterations! 
cont<-lmeControl(maxIter=500, msMaxIter=50,  niterEM=30)

m4 <- lme(CLOSEDAD ~ 1 + GRADE_C, random = ~ 1 + GRADE_C|id, 
          data=simchild, na.action = 'na.omit', method = 'ML', 
          corr = corAR1(), 
          weights = varIdent(form = ~1|GRADE), 
          control=cont)
summary(m4)
anova(m3,m4)
anova(m2,m4)


## Multiple group models
## If we have time! 

mMG <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
           random = list(id=pdBlocked(list(pdSymm(form=~ 0+CONSBOY + GRDBOY_C),
                                           pdSymm(form=~0+CONSGRL + GRDGRL_C)))), 
           data=simchild, na.action = 'na.omit', method = 'ML', 
           weights = varIdent(form = ~1|SEX))
summary(mMG)


#Nested model, are intercept and slope variances equal?
mMG1 <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
            random = ~ 1 + GRADE_C|id, 
            data=simchild, na.action = 'na.omit', method = 'ML', 
            weights = varIdent(form = ~1|SEX))
summary(mMG1)

anova(mMG, mMG1)

#All variances equal?
mMG1a <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
             random = ~ 1 + GRADE_C|id, 
             data=simchild, na.action = 'na.omit', method = 'ML')
summary(mMG1a)
rbind(fixef(mMG1), fixef(mMG1a))

##Compare nested MG with interaction effect

#Interaction model
mInt <- lme(CLOSEMOM ~ SEX + GRADE_C + SEX*GRADE_C, random = ~ 1 + GRADE_C|id, 
            data=simchild, na.action = 'na.omit', method = 'ML')
summary(mInt)
anova(mMG1a, mInt)
