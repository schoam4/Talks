##############################
### MLM with R             ###
### Summer Stats Camp 2022 ###
### Alexander Schoemann    ###
##############################



library(lme4)
library(lmerTest)
library(foreign)

### Cross Classified Models ###

#Data from Hox (2002)

pupcross<-read.dta("https://stats.idre.ucla.edu/stat/stata/examples/mlm_ma_hox/pupcross.dta")

pupcross$pschool <- as.factor(pupcross$pschool)
pupcross$sschool <- as.factor(pupcross$sschool)
pupcross$pXsschool <- pupcross$sschool:pupcross$pschool

summary(pupcross)
head(pupcross)

#"Main effects" model without pXs interaction
m0<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m0)

#Full cross-classified model
m1<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + 
           (1|pXsschool), data = pupcross, REML=FALSE)
summary(m1)

#ICCs
#Secondary School
.06447/(.03362+.16817 + .06447 + .48201)
#Primary School
.16817/(.03362+.16817 + .06447 + .48201)
#PrimaryXSecondary School
.03362/(.03362+.16817 + .06447 + .48201)

anova(m0,m1)

#Full cross-classified model: alternative code
m1b <-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + 
           (1|sschool:pschool), data = pupcross, REML=FALSE)
summary(m1b)

# Add level 1 predictors
m1a<-lmer(achiev ~ pupsex + pupses +(1|sschool) + 
            (1|pschool),
          pupcross, REML=FALSE)
summary(m1a)

# Include random slope for pschool
m2<-lmer(achiev ~ pupsex + pupses +
                  (1|sschool) + (pupsex|pschool), 
         pupcross, REML=FALSE)
summary(m2)

anova(m1a,m2)

# Add random slopes for both level 2 units
m3<-lmer(achiev ~ pupsex  + pupses +
           (pupses|sschool) + (pupses|pschool), 
         data = pupcross, REML=FALSE,
         control = lmerControl(optimizer="Nelder_Mead"))
summary(m3)

anova(m1a,m3)

# Add level 2 predictors
m4<-lmer(achiev ~ pupsex  + pupses + pdenom + sdenom +
           (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m4)

# Add random effect of level 2 predictor for other random slope
m5<-lmer(achiev ~ pupsex  + pupses + pdenom + sdenom +
           (1|sschool) + (sdenom|pschool), 
         data = pupcross, REML=FALSE)
summary(m5)

anova(m4, m5)

# Add random slopes for both level 2 units
#And interactions with pdenom
m3int<-lmer(achiev ~ pupsex  + pupses * sdenom + 
           (pupses|sschool) + (pupses|pschool), 
         data = pupcross, REML=FALSE)
summary(m3int)



### Missing Data ###

# Use simchild data
simchild <- read.csv('simchild.csv', na.string = '-999999')
summary(simchild)


#lots of missing on CONFLDAD! 1444/5144 = .2807 proportion missing

simchildMISS <- simchild[,c('id', 'SEX', 'GRADE_C', 'CONFLMOM', 'CONFLDAD', 'CLOSEMOM', 'CLOSEDAD')]


m1LW <- lmer(CONFLDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
             data = simchildMISS, REML = FALSE)
summary(m1LW)
## Uses 3700 observations, so uses 3700/5144 = 72% of available data

m1LWc <- lmer(CONFLDAD ~ 1 + GRADE_C + CONFLMOM + (1 + GRADE_C|id), 
             data = simchildMISS, REML = FALSE)
summary(m1LWc)

##impute missing data in simchild

library(mice)
library(miceadds)
library(mitml)

# mice won't pool with lmerTest
detach(package:lmerTest)

#set up imputation template
template<- mice(simchildMISS, maxit = 0)
pred <- template$pred
meth <- template$method

#set id as the L2 identifier
pred[4:7,1] <- -2
pred

#set variable with random slopes (GRADE_C)
pred[4:7,3] <- 2
pred

#now set imputation methods (in this case use 2l.contiuous from miceadds for speed)
# In reality I'd probaby use 2l.norm or 2l.pmm
meth
meth[4:7] <- '2l.continuous'
meth

#Start MI
# Use only 5 imputation for speed
imp <- mice(simchildMISS, m = 5, maxit = 10, 
            meth = meth, pred = pred)

#Run model on all 5 imputed data sets using with and lmer

m1imp <- with(imp, lmer(CONFLDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
                        REML = FALSE, 
                        control = lmerControl(optimizer="Nelder_Mead")))
m2imp <- with(imp, lmer(CONFLDAD ~ 1 + GRADE_C + (1 |id), 
                        REML = FALSE, 
                        control = lmerControl(optimizer="Nelder_Mead")))


#Use mitml to pool
m1impM <- as.mitml.result(m1imp)
m2impM <- as.mitml.result(m2imp)

testEstimates(m1impM, extra.pars = TRUE)
testEstimates(m2impM, extra.pars = TRUE)

#compare models
testModels(m1impM, m2impM, method = "D3")

#Conflict with Mom as a L1 covariate
m1impc <- with(imp, lmer(CONFLDAD ~ 1 + GRADE_C+ CONFLMOM + (1 + GRADE_C|id), 
                        REML = FALSE, 
                        control = lmerControl(optimizer="Nelder_Mead")))
m1impc <- as.mitml.result(m1impc)

testEstimates(m1impc, extra.pars = TRUE)


### Binary outcomes ###


#Read in loop data for categorical outcome
#3432 students in 240 schools
# interested in predicting if students took a science course

loop <- read.csv('loop.csv')
summary(loop)

#null model

mc0 <- glmer(scisub ~ 1 + (1|school), 
             data = loop, family = binomial)
summary(mc0)

#odds of taking a science class
exp(fixef(mc0))
#probability of taking a science class
exp(fixef(mc0)) / (1 + exp(fixef(mc0)))

#ICC
0.4232 / (0.4232 + (pi/3))

#gender (0=boys, 1= girls) and minority (0=no, 1=yes) status as predictors

mc1 <- glmer(scisub ~ 1 + gender + minority + 
               (1|school), data = loop, 
             family = binomial)
summary(mc1)

#odds ratios for fixed predictors
exp(fixef(mc1))

#Random effect
mc2 <- glmer(scisub ~ 1 + gender +
               minority + (gender|school), 
             data = loop, family = binomial)
summary(mc2)

#odds ratios for fixed predictors
exp(fixef(mc2))

#Test random effect
anova(mc1, mc2)

library(performance)
r2(mc1)

#Interaction
mc3 <- glmer(scisub ~ 1 + gender * minority + 
               (1|school), data = loop, 
             family = binomial)
summary(mc3)

library(interactions)
sim_slopes(mc3, gender, minority)

##Example with probit link instead of logit
mc2p <- glmer(scisub ~ 1 + gender +
                minority + (gender|school), 
              data = loop, 
              family = binomial(link = "probit"))
summary(mc2p)

## For ordinal outcomes use clmm() function in the ordinal package
## Or use MCMCglmm or brms with Bayes

