#############################
### MLM with R            ###
### Fall Stats Camp 2021  ###
### Alexander Schoemann   ###
#############################


### Interactions ###

library(lme4)
library(lmerTest)
library(interactions)
library(dplyr)

##Read in data
SB <- read.csv('SB.csv')

##Disaggregated regression with interaction
m1a <- lm(langpost~ iq_verb + groupsiz, 
          data=SB)
summary(m1a)

m1 <- lm(langpost~ iq_verb * groupsiz, 
         data=SB)
summary(m1)

m1b <- lm(langpost~ iq_verb + groupsiz +iq_verb:groupsiz, 
          data=SB)
summary(m1b)

#compute intercept when grpsiz=23
(-.22+.44*37)
#compute slope when grpsiz=23
(3.35+ -0.03*37)

round(vcov(m1),4)

#use interactions package to probe

# Simple slopes and j-n intervals/plot
sim_slopes(m1, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, mod.range = c(0,250))

sim_slopes(m1, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, mod.range = c(0,250), 
           modx.values = c(5,37))

sim_slopes(m1, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, mod.range = c(0,250), 
           modx.values = "terciles")

# Simple slopes plot
interact_plot(m1, pred = iq_verb, 
              modx = groupsiz)

interact_plot(m1, pred = iq_verb, 
              modx = groupsiz, 
              modx.values = "terciles")


##MLM with interaction
m2a <- lmer(langpost~ iq_verb+groupsiz +
              (1 + iq_verb|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m2a)

m2 <- lmer(langpost~ iq_verb*groupsiz +
             (1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m2)

#R2 for random slope
(0.2016-0.1644)/0.2016

# Simple slopes and j-n intervals/plot
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, jnplot = TRUE)
# Simple slopes plot
interact_plot(m2, pred = iq_verb, modx = groupsiz)

# Simple slopes with specified values for the moderator
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, 
           modx.values = c(5,37))

interact_plot(m2, pred = iq_verb, 
           modx = groupsiz, 
           modx.values = c(5,37))

sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, 
           modx.values = "terciles")

# Simple slopes and j-n intervals/plot switch moderator
sim_slopes(m2, pred = groupsiz, 
           modx = iq_verb, jnplot = TRUE)

# Example cross-level interaction
m3a <- lmer(langpost~ iq_verb+percmino +(iq_verb|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m3a)

m3 <- lmer(langpost~ iq_verb*percmino +(1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m3)

##dichotomous predictor example with Hox data
pop <- read.csv('popular.csv')
summary(pop)
#For variable SEX: boy=0 girl=1
m3a <- lmer(POPULAR ~ SEX + TEXP + 
              (1 + SEX|SCHOOL), 
            data=pop, REML=FALSE)
summary(m3a)

m3 <- lmer(POPULAR ~ SEX*TEXP + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)
summary(m3)

#only for teaching, don't use L1 variable as a moderator!
sim_slopes(m3, pred = TEXP, modx = SEX)
interact_plot(m3, pred = TEXP, modx = SEX)

#this is the way to do it for real
sim_slopes(m3, pred = SEX, modx = TEXP)

#R2 for random slopes
(0.2697 - 0.2202)/0.2697

##MLM with interaction centered

SB <- mutate(SB, IQV_CGM = iq_verb - 11.83406) 
SB <- mutate(SB, IQV_CGM2 = iq_verb - mean(SB$iq_verb))
# Group mean centering
#Use aggregate command to compute group means
grpmeans<-aggregate(SB$iq_verb, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)
grpmeans
##Rename columns for merging
names(grpmeans)<-c("schoolnr","IQ_GM")
##Merge group means back to data set by school (L2 unit)
SB<-merge(SB,grpmeans,by="schoolnr")
head(SB)
summary(SB)
# Group mean center
SB<- mutate(SB, IQV_CWC = (iq_verb - IQ_GM))

#Grand mean centered
SB <- mutate(SB, groupsizC = groupsiz - mean(SB$groupsiz))

m2aC <- lmer(langpost~ IQV_CGM2+groupsizC +(1 + IQV_CGM2|schoolnr),
             data=SB, REML=FALSE, 
             control = lmerControl(optimizer="Nelder_Mead"))
summary(m2aC)

m2C <- lmer(langpost~ IQV_CGM2*groupsizC +(1 + IQV_CGM2|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m2C)


#Group mean centered
m2aC <- lmer(langpost~  IQV_CWC + IQ_GM+
               groupsizC +
               (1 + IQV_CWC|schoolnr),
             data=SB, REML=FALSE, 
             control = lmerControl(optimizer="Nelder_Mead"))
summary(m2aC)

m2C <- lmer(langpost~ IQV_CWC*groupsizC + 
              IQ_GM*groupsizC +
              (1 + IQV_CWC|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m2C)


sim_slopes(m2C, pred = IQV_CWC, 
           modx = groupsizC, 
           modx.values = "terciles")

## Example with multicategory moderator
## denomina has 4 levels (I forget what they are)

SB$denomina <- as.factor(SB$denomina)

m3a <- lmer(langpost~ iq_verb + denomina + 
             (1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m3a)

m3 <- lmer(langpost~ iq_verb*denomina + 
                (1 + iq_verb|schoolnr),
            data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m3)

anova(m3a,m3)

sim_slopes(m3, pred = iq_verb, 
           modx = denomina)

### Estimation ###

pop <- read.csv('popular.csv')
summary(pop)

## Use the popularity data
#For variable SEX: boy=0 girl=1
## Fit the same model with FIML and REML
m1ML <- lmer(POPULAR ~ 1 + SEX + TEXP + 
               (1 + SEX|SCHOOL), 
             data=pop, REML=FALSE)
m1MLa <- lmer(POPULAR ~ 1 + SEX + TEXP + 
                (1|SCHOOL), 
             data=pop, REML=FALSE)
m1REML <- lmer(POPULAR ~ 1 + SEX + TEXP + 
                 (1 + SEX|SCHOOL), 
               data=pop, REML=TRUE)
m1REMLa <- lmer(POPULAR ~ 1 + SEX + TEXP + 
                  (1 |SCHOOL), 
               data=pop, REML=TRUE)

summary(m1ML)
summary(m1MLa)
summary(m1REML)

anova(m1MLa, m1ML)
anova(m1REMLa, m1REML)

confint(m1REML)

## Compare fixed effects, top row is FIML
rbind(fixef(m1ML), fixef(m1REML))

## Compare random effects
ranEFF <-cbind(data.frame(summary(m1ML)$varcor)[1:2,c(1,4)],data.frame(summary(m1REML)$varcor)[1:2,c(1,4)])
colnames(ranEFF) <- c(rep('ML', 2),rep('REML', 2))
ranEFF

library(performance)

r2(m1ML)
r2(m1REML)

### Power and sample size determination ###

## Example from Arend & Schafer (2019)

library(simr)
##### Example 1: R code for individuals-within-clusters example #####
set.seed(123)
#### Specification of Input Parameters ####
### Specification of standardized input parameters ###
L1_DE_standardized <- .10 	## standardized L1 direct effect
L2_DE_standardized <- .40 	## standardized L2 direct effect
ICC <- .10 			## standardized intraclass correlation coefficient
alpha.S <- .05 		## significance level
Size.clus <- 10 		## L1 sample size (cluster size)
N.clus <- 100 			## L2 sample size (number of clusters)

### Derivation of a population model for the power analysis ###
## Specification of predictor variables ##
x <- scale(rep(1:Size.clus))
g <- as.factor(1:N.clus)
X <- cbind(expand.grid("x"=x, "g"=g))
X <- data.frame(X, Z=as.numeric(X$g))
X$Z <- scale(X$Z)

## Specification of the outcome variable ##
varL1 <- 1 						## uncond. L1 variance (fixed at 1)
s <- sqrt((varL1)*(1-(L1_DE_standardized^2)))	## cond. L1 variance (Equation 11)
varL2 <- ICC/(1-ICC) 					## uncond. L2 variance (Equation 10)
V1 <- varL2*(1-(L2_DE_standardized^2)) 		## cond. L2 variance (Equation 11)

## Adjustment of fixed effects (Equation 15) ##
L1_DE <- L1_DE_standardized*sqrt(varL1)
L2_DE <- L2_DE_standardized*sqrt(varL2)

#### Implementation of a Power Analysis in a Two-Level Model in SIMR ####
### Vector of fixed effects ###
b <- c(0, L1_DE, L2_DE)

### Setting up the population model ###
model <- makeLmer(y ~ x + Z + (1|g), fixef=b, VarCorr=V1, sigma=s, data=X)
print(model)

### Simulating power for the L1 direct effect ###

#Only uses 100 replications for example, use more in real life!
sim.ef <- powerSim(model,
                   fixed("x","kr"),
                   nsim=1000)
print(sim.ef)
simdat_E1 <- cbind(effect="x", 
                   Size.clus, 
                   N.clus, 
                   L1_DE_standardized, 
                   L2_DE_standardized, 
                   summary(sim.ef))

### Simulating power for the L2 direct effect ###
sim.ef <- powerSim(model,
                   fixed("Z","kr"),
                   nsim=1000)
print(sim.ef)

### Power of all effects is stored in the data frame simdat_E1 ###
simdat_E1 <- rbind(simdat_E1,cbind(effect="Z", 
                                   Size.clus, 
                                   N.clus, 
                                   L1_DE_standardized, 
                                   L2_DE_standardized, 
                                   summary(sim.ef)))
simdat_E1



### Longitudinal Data ###

library(nlme)
##Read in simchild data

simchild <- read.csv('simchild.csv', 
                     na.string = '-999999')
summary(simchild)
head(simchild)

#Fit model with fixed intercept, fixed slope. 
#Need to do this with regression
m1 <- lm(CLOSEDAD ~ 1 + GRADE_C, data = simchild)
summary(m1)

m0a <- lmer(CLOSEDAD ~ 1 +  (1|id), data = simchild, 
            REML = FALSE)
summary(m0a)

#ICC
10.09/(10.09+7.85)

#Fit model with random intercept, fixed slope
m1a <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1|id), 
            data = simchild, 
            REML = FALSE)
summary(m1a)

#Fit model with fixed intercept, random slope
m1b <- lmer(CLOSEDAD ~ 1 + GRADE_C + (0 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1b)

#Fit model with random intercept, random slope
m1c <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1c)

#Random intercept, random slope model with uncentered data
m1d <- lmer(CLOSEDAD ~ 1 + GRADE + (1 + GRADE|id), 
            data = simchild, REML = FALSE)
summary(m1d)

#Compare models
anova(m1a,m1c)
anova(m1b, m1c)

#profile CI for random intercepts and slopes
#this might take a while...
confint(m1c, method="profile")

confint(m1c, method="profile", level = .90)

##The apature for this model Tau_0,1/Tau_1,1

#Compute covariance (only get correlation in lmer)
tauCov <- .47*2.5775*0.3904

#apature
ap <- -tauCov/.3904^2
ap 

#Create new time variable
simchild$NEW_GRADE <- simchild$GRADE_C - ap

#Fit model with random intercept, random slope
m1cAP <- lmer(CLOSEDAD ~ 1 + NEW_GRADE + (1 + NEW_GRADE|id), data = simchild, REML = FALSE)
summary(m1cAP)

#Create new time variable
simchild$months <- simchild$GRADE_C*12

#Fit model with random intercept, random slope
m1cMon <- lmer(CLOSEDAD ~ 1 + months + (1 + months|id), data = simchild, REML = FALSE,control = lmerControl(optimizer="Nelder_Mead"))
summary(m1cMon)

##Does gender predict growth? Use CONFLMOM now
## Boys = 1, girls = 0

##Predicting intercept only
m1d <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1d)


##Predicting intercept and slope
m1f <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX +
              GRADE_C*SEX + 
              (1 + GRADE_C|id),
            data = simchild, REML = FALSE)
summary(m1f)

#Probe interaction between time and SEX
library(interactions)
sim_slopes(m1f, pred = GRADE_C, modx = SEX)
interact_plot(m1f, pred = GRADE_C, modx = SEX)


#Time varying covariate. Change in CLOSEDAD controlling for CLOSEMOM
#Time varying covariate should be centered so the intercept is interpretable
m1h <- lmer(CLOSEDAD ~ 1 + GRADE_C + CLOSEMOM + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1h)



#Anti-read example
anti <- read.csv('antiread.csv')
summary(anti)

#Using Wave as the predictor
m2w <- lmer(ANTI ~ 1 + WAVE_C + 
              (1 + WAVE_C|id), 
            data = anti, REML = FALSE)
summary(m2w)

#Using Age as the predictor
m2a <- lmer(ANTI ~ 1 + AGE_C + 
              (1 + AGE_C|id), 
            data = anti, REML = FALSE)
summary(m2a)

#Quadratic effect of Age
anti$AGE_C2 <- anti$AGE_C*anti$AGE_C 
m2aq <- lmer(ANTI ~ 1 + AGE_C + AGE_C2 + 
               (1 + AGE_C|id), data = anti, REML = FALSE,
             control = lmerControl(optimizer="Nelder_Mead"))

summary(m2aq)

anova(m2a, m2aq)

#Spline example using STARS data
STARS <- read.csv('STARS.csv', na.string = '-999999')
summary(STARS)

#Linear-Linear Spline
mSPL <- lmer(SBPSPCH ~ 1 + PHASE1L + PHASE2L + 
               (1 + PHASE1L + PHASE2L|USERID), 
             data = STARS, REML = FALSE)
summary(mSPL)

#Quadradic-Linear Spline
mSPQ <- lmer(SBPSPCH ~ 1 + PHASE1L+ PHASE1Q + PHASE2L + 
               (1 + PHASE1L+ PHASE1Q + PHASE2L|USERID), 
             data = STARS, REML = FALSE)
summary(mSPQ)
anova(mSPL, mSPQ)

#Linear slope
mL <- lmer(SBPSPCH ~ 1 + TIME + (1 + TIME|USERID), 
           data = STARS, REML = FALSE)
summary(mL)

#Compare to see if spline is reasonable
anova(mSPL, mL)

## Complex Error Structures 

#homoscedastic  errors
m1 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, 
          data=simchild, 
          na.action = 'na.omit', method = 'ML')
summary(m1)

#let errors vary...

m2 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, 
          data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          weights = varIdent(form = ~1|GRADE_C))
summary(m2)

#Figure out different L1 SD
2.025552*c(1.000000, 1.263662, 1.190792, 1.353371, 1.285797)

#Should we use heteroscedastic  errors?
anova(m1,m2)

#Add an AR1 correlation structure
m3 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          corr = corAR1())
summary(m3)

anova(m1,m3)

#Add AR1 and heteroskedasticy. Need to increase iterations! 
cont<-lmeControl(maxIter=500, msMaxIter=50,  
                 niterEM=30)

m4 <- lme(CLOSEDAD ~ 1 + GRADE_C, random = ~ 1 + GRADE_C|id, 
          data=simchild, na.action = 'na.omit', method = 'ML', 
          corr = corAR1(), 
          weights = varIdent(form = ~1|GRADE_C), 
          control=cont)
summary(m4)
anova(m3,m4)
anova(m2,m4)

