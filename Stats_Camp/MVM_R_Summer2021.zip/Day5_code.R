#############################
### MVM with R            ###
### Summer Stats Camp 2021###
### Alexander Schoemann   ###
#############################


####Load packages for today
library(lavaan)
library(semPlot)
library(semTools)
library(psych)

#### Structural Models


################################################################################
## data preparation
################################################################################

## Data is in a tab delimited file with no names

dat <- read.table("11.Grade7.dat")

# This assigns names to each column in dat
names(dat) <- c("Agency1","Agency2","Agency3","Intrin1","Intrin2","Intrin3","Extrin1","Extrin2","Extrin3","PosAFF1","PosAFF2","PosAFF3","NegAFF1","NegAFF2","NegAFF3","Gender","Ethnic2","Ethnic3","Ethnic4")

## Create scale scores for OLS regression

dat$AgencyO <- (dat$Agency1 + dat$Agency2 + dat$Agency3)/3
dat$IntrinO <- (dat$Intrin1 + dat$Intrin2 + dat$Intrin3)/3
dat$ExtrinO <- (dat$Extrin1 + dat$Extrin2 + dat$Extrin3)/3
dat$PosAFFO <- (dat$PosAFF1 + dat$PosAFF2 + dat$PosAFF3)/3
dat$NegAFFO <- (dat$NegAFF1 + dat$NegAFF2 + dat$NegAFF3)/3

################################################################################
## Example Path model predicting positive affect
################################################################################

mod70 <- lm(PosAFFO ~ AgencyO + IntrinO + ExtrinO, data=dat)
summary(mod70)
standardize(mod70)

mod71 <- '
PosAFFO ~ AgencyO + IntrinO + ExtrinO
'

fit71 <- sem(mod71, data = dat, fixed.x=FALSE)
summary(fit71, fit.measures=TRUE, standardized=TRUE)
#Get r^2
lavInspect(fit71, 'r2')


################################################################################
## Example Always start with a CFA
################################################################################
mod72 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
            Extrin =~ Extrin1 + Extrin2 + Extrin3
            Positive =~ PosAFF1 + PosAFF2 + PosAFF3
            '

fit72 <- cfa(mod72, data=dat, std.lv=TRUE)

summary(fit72, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example Change CFA to Structural (Latent) Regression
################################################################################
mod73 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
						Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3

            Positive ~ Agency + Intrin + Extrin
'

fit73 <- sem(mod73, data=dat, std.lv=TRUE)

summary(fit73, standardized=TRUE, fit.measures=TRUE)

lavInspect(fit73, 'r2')

semPaths(fit73)

################################################################################
## Example Add Negative Affect
################################################################################
mod74 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
						Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

            Positive ~ Agency + Intrin + Extrin
            Negative ~ Agency + Intrin + Extrin
						'

fit74 <- sem(mod74, data=dat, std.lv=TRUE)

summary(fit74, standardized=TRUE, fit.measures=TRUE)

lavInspect(fit74, 'r2')


################################################################################
## Example Trim Non-Significant Paths
################################################################################
mod75 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
						Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

						Positive ~ Agency + Intrin
						Negative ~ Extrin
						'

fit75 <- sem(mod75, data=dat, std.lv=TRUE)

summary(fit75, standardized=TRUE, fit.measures=TRUE)

#Compare to unpruned model
anova(fit74, fit75)


################################################################################
## Example Introduce Covariates, regress all constructs on them
################################################################################
mod76 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
						Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

						Agency ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
						Intrin ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
						Extrin ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
						Positive ~ Agency + Intrin + Gender + Ethnic2 + Ethnic3 + Ethnic4
						Negative ~ Extrin + Gender + Ethnic2 + Ethnic3 + Ethnic4
						'

fit76 <- sem(mod76, data=dat, std.lv=TRUE)

summary(fit76, standardized=TRUE, fit.measures=TRUE)

#Ethinic2 = black
#Ethnic3 = Hispanic
#Ethnic4 = Other
#Gender: 1 = Female

################################################################################
## Example Trim Non-Significant Paths (again)
################################################################################
mod77 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
  					Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

						Intrin ~ Gender + Ethnic3 
						Extrin ~ Gender
						Positive ~ Agency + Intrin 
						Negative ~ Extrin + Gender + Ethnic2 
           '

fit77 <-  sem(mod77, data=dat, std.lv=TRUE)

summary(fit77, standardized=TRUE, fit.measures=TRUE)


################################################################################
## Example Covariate Controls as Semi-Partial Effects
################################################################################
mod78 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
  					Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

						Positive ~ Agency + Intrin + Gender + Ethnic2 + Ethnic3 + Ethnic4
						Negative ~ Extrin + Gender + Ethnic2 + Ethnic3 + Ethnic4
						'

fit78 <- sem(mod78, data=dat, std.lv=TRUE)

summary(fit78, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example Covariate Controls as indirect Effects
################################################################################
mod79 <- 'Agency =~ Agency1 + Agency2 + Agency3
            Intrin =~ Intrin1 + Intrin2 + Intrin3
  					Extrin =~ Extrin1 + Extrin2 + Extrin3
						Positive =~ PosAFF1 + PosAFF2 + PosAFF3
						Negative =~ NegAFF1 + NegAFF2 + NegAFF3

						Agency ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
						Intrin ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
						Extrin ~ Gender + Ethnic2 + Ethnic3 + Ethnic4
						Positive ~ Agency + Intrin
						Negative ~ Extrin
						'

fit79 <- sem(mod79, data=dat, std.lv=TRUE)

summary(fit79, standardized=TRUE, fit.measures=TRUE)


#### Mediation

################################################################################
## data preparation
################################################################################

## read raw data file for mediation model
dat <- read.csv("SEMmediation.csv")



################################################################################
## example Structural Regression, with Agency as auxilliary covariate
## C PATHWAY
################################################################################
mod91 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## Covariances
      Agency ~~ Intrin
      Positive ~~ Agency
# Regression
      Positive ~ Intrin
'

fit91 <- sem(mod91, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit91, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Mediation model
################################################################################
mod92 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent regression
      Agency ~ a*Intrin
      Positive ~ b*Agency + cprime*Intrin
## Define indirect effect
ab := a*b
tot := a*b + cprime
'

fit92 <- sem(mod92, data=dat, meanstructure=TRUE, 
             std.lv=TRUE)

summary(fit92, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping
#Only  500 bootstraps to save time. Usually use 1000+
fit92b <- sem(mod92, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit92b, standardized=TRUE, fit.measures=TRUE)


#Get bootstrapped CI
parameterEstimates(fit92b)

##Monte Carlo CI

#If you provide the function with a lavaan object it 
# finds parameters with given names


monteCarloMed("a*b", object=fit92, plot=TRUE,
              rep = 50000)


################################################################################
## example Structural Regression, with Intrinsic as auxiliary covariate
################################################################################
mod93 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
      Agency ~~ Intrin
      Positive ~~ Intrin
## latent regression
      Positive ~ Agency
'

fit93 <- sem(mod93, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit93, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example Mediation model with Intrisic as the mediator
################################################################################
mod94 <- '
## define latent variables
      Intrin =~ Intrin1 + Intrin2 + Intrin3
      Agency =~ Agency1 + Agency2 + Agency3
      Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent regression
      Intrin ~ a*Agency
      Positive ~ b*Intrin + Agency

ab := a*b
'

fit94 <- sem(mod94, data=dat, meanstructure=TRUE, std.lv=TRUE)

summary(fit94, standardized=TRUE, fit.measures=TRUE)

##Test indirect effect with bootstrapping

fit94b <- sem(mod94, data=dat, meanstructure=TRUE, 
              std.lv=TRUE, se = "boot", bootstrap = 500)

summary(fit94b, standardized=TRUE, fit.measures=TRUE)

parameterEstimates(fit94b)


### Moderation ###


##Read in data
dat2 <- read.csv('SEMmoderation.csv')

##Create data with orthogonalized terms

dat3 <- indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
                c('meUNK1', 'meUNK2', 'meUNK3'), 
                match=FALSE,
                meanC = FALSE, residualC = TRUE,
                namesProd = c('int1', 'int2', 'int3', 'int4', 'int5',
                              'int6', 'int7', 'int8', 'int9'))

summary(dat3)
round(cor(dat3), 3)

################################################################################
## example "Main effect" Model
################################################################################
mod95a <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
    		Positive =~ PosAFF1 + PosAFF2 + PosAFF3
#Latent regression
				Positive ~ Agency + Unknown 
'

fit95a <- sem(mod95a, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit95a, fit.measures=TRUE)

################################################################################
## example Moderation model Orthogonalizing
################################################################################
mod95 <- '
## define latent variables
				Agency =~ agATT1 + agATT2 + agATT3
				Unknown =~ meUNK1 + meUNK2 + meUNK3
				Interact =~ int1 + int2 + int3 + int4 + int5 + int6 + int7 + int8 + int9
				Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
				Agency ~~ Unknown
				Agency ~~ 0*Interact
				Unknown ~~ 0*Interact
## latent regression
				Positive ~ Agency + Unknown + Interact
## correlated residuals
				int2 ~~ T1*int1
				int3 ~~ T1*int1
				int3 ~~ T1*int2
				int5 ~~ T2*int4
				int6 ~~ T2*int4
				int6 ~~ T2*int5
				int8 ~~ T3*int7
				int9 ~~ T3*int7
				int9 ~~ T3*int8
				int4 ~~ T4*int1
				int7 ~~ T4*int4
				int7 ~~ T4*int1
				int5 ~~ T5*int2
				int8 ~~ T5*int5
				int8 ~~ T5*int2
				int6 ~~ T6*int3
				int9 ~~ T6*int6
				int9 ~~ T6*int3
'

fit95 <- sem(mod95, data=dat3, std.lv=TRUE, meanstructure=TRUE)

summary(fit95, fit.measures=TRUE)


################################################################################
## example Moderation model Double Mean Centering
################################################################################

dat4 <-indProd(dat2, c('agATT1', 'agATT2', 'agATT3'), 
               c('meUNK1', 'meUNK2', 'meUNK3'), 
               meanC=FALSE, doubleMC =TRUE, 
               namesProd = c('int1', 'int2', 'int3'))

mod96 <- '
## define latent variables
Agency =~ agATT1 + agATT2 + agATT3
Unknown =~ meUNK1 + meUNK2 + meUNK3
Interact =~ int1 + int2 + int3
Positive =~ PosAFF1 + PosAFF2 + PosAFF3
## latent correlations
Agency ~~ Unknown
Agency ~~ Interact
Unknown ~~ Interact
## latent regression
Positive ~ Agency + Unknown + Interact
'

fit96 <- sem(mod96, data=dat4, std.lv=TRUE, meanstructure=TRUE)

summary(fit96, fit.measures=TRUE)

##Probing interactions

probed <-probe2WayRC(fit95, nameX=c('Agency', 'Unknown', 'Interact'), 
                     nameY='Positive', modVar='Unknown', c(-1, 0, 1))
probed

probe2WayMC(fit96, nameX=c('Agency', 'Unknown', 'Interact'), 
            nameY='Positive', modVar='Unknown', c(-1,1))

plotProbe(probed, c(-1,1))
