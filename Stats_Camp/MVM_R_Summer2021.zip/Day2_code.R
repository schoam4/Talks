#############################
### MVM with R            ###
### Summer Stats Camp 2021###
### Alexander Schoemann   ###
#############################


### Mediation ###

#Example from Jose (2013)

pos <- read.csv("Mediation_example.csv")

#c path (total effect)
modC <- lm(shs ~ ple, data = pos)
summary(modC)

#a path
modA <- lm(grat ~ ple, data = pos)
summary(modA)

#b and c' paths
modB <- lm(shs ~ grat + ple, data = pos)
summary(modB)

#Use lavaan to estimate model

library(lavaan)

#specify model
# use ~ for regressions
# use * to give a parameter a label
# use := to create a new parameter

modMed <- '
grat ~ a*ple
shs ~ b*grat + cprime*ple

ab := a*b
totEff := a*b + cprime

'

#fit model with the sem function
#these results give a test of ab equal to the Sobel test
fit <- sem(modMed, data = pos)
summary(fit, standardized = TRUE)
#get r2
lavInspect(fit, what = "r2")

#Bootstrap CI (use more than 500 reps for real analysis!)
fitBoot <- sem(modMed, data = pos, 
               se = "boot", bootstrap = 500)
summary(fitBoot)

#use the parameterEstimates function to get the CI
parameterEstimates(fitBoot)

#Need to use the semTools package to get Monte Carlo CI

library(semTools)

#Use the monteCarloMed function
monteCarloMed("a*b", object = fit, 
              rep = 50000)

monteCarloMed("a*b", object = fit, 
              rep = 50000, plot = TRUE)


## Multiple mediation


## Example mediation models using pmi data

pmi <- read.csv("pmi.csv")


#Multiple mediator model
MultMed <- '
import ~ a1*cond 
pmi ~ a2*cond

reaction ~ cprime*cond + b1*import + b2*pmi

ab1 := a1*b1
ab2 := a2*b2

diffInd:= a1*b1 - a2*b2
totInd := a1*b1 + a2*b2
totEff := a1*b1 + a2*b2 + cprime

'

#fit model with the sem function
#these results give a test of ab equal to the Sobel test
fitMultMed <- sem(MultMed, data = pmi)
summary(fitMultMed, standardized = TRUE)
#get r2
lavInspect(fitMultMed, what = "r2")

#Bootstrap CI (use more than 500 replications!)
fitBootMultMed <- sem(MultMed, data = pmi, 
                      se = "boot", bootstrap = 500)

#use the parameterEstimates function to get the CI
parameterEstimates(fitBootMultMed)

#Need to use the semTools package to get Monte Carlo CI

#Use the monteCarloMed function
monteCarloMed("a1*b1", object = fitMultMed, 
              rep = 50000)

monteCarloMed("a2*b2", object = fitMultMed, 
              rep = 50000)

monteCarloMed("a1*b1 - a2*b2", object = fitMultMed, 
              rep = 50000)

# Serial Mediation

SerMed <- '
import ~ a*cond
pmi ~ cp1*cond + b*import

reaction ~ cp3*cond + cp2*import + d*pmi

ind1 := a*cp2
ind2 := cp1*d
ind3 := a*b*d
tot := ind1 + ind2 + ind3
'

#fit model with the sem function
#these results give a test of ab equal to the Sobel test
fitSerMed <- sem(SerMed, data = pmi)
summary(fitSerMed, standardized = TRUE)
#get r2
lavInspect(fitSerMed, what = "r2")

#Bootstrap CI (use more than 500 replications!)
fitBootSerMed <- sem(SerMed, data = pmi, 
                     se = "boot", bootstrap = 500)

#use the parameterEstimates function to get the CI
parameterEstimates(fitBootSerMed)

# Alternate method of bootstrapping (use more than 500 replications!)
# Requires extra post processing, be careful!
library(dplyr)
bootSerMed <- bootstrapLavaan(fitSerMed, R = 500,
                              parallel = "multicore", double.boostrap = "no")

bootSerMed <- mutate(data.frame(bootSerMed), 
                                 ind1 = a*cp2,
                                 ind2 = cp1*d,
                                 ind3 = a*b*d)
#Get CIs
quantile(bootSerMed$ind1, c(.025, .975))
quantile(bootSerMed$ind2, c(.025, .975))
quantile(bootSerMed$ind3, c(.025, .975))

monteCarloMed("a*cp2", object = fitSerMed, 
              rep = 50000)

monteCarloMed("cp1*d", object = fitSerMed, 
              rep = 50000)

monteCarloMed("a*b*d", object = fitSerMed, 
              rep = 50000)

### Moderation ###

## Read in data

exMod <- read.csv("continuous_moderation_example.csv")

## Fit regression models

#Main effect
mod1 <- lm(dep ~ stress + socsup, data = exMod)
summary(mod1)
#Moderation
mod2 <- lm(dep ~ stress + socsup + stressXss, 
           data = exMod)
summary(mod2)

#The moderation model with R automatically creating product terms
mod2a <- lm(dep ~ stress * socsup, data = exMod)
summary(mod2a)

#One more way to fit the moderation model
mod2b <- lm(dep ~ stress + socsup + stress:socsup, 
            data = exMod)
summary(mod2b)

## Plot and probe with interactions package

library(interactions)


# Simple slopes and j-n intervals/plot
sim_slopes(mod2a, pred = stress, 
           modx = socsup, jnplot = TRUE)
# Simple slopes plot
interact_plot(mod2a, pred = stress, modx = socsup)

# Use terciles
sim_slopes(mod2a, pred = stress, 
           modx = socsup, modx.values = "terciles")

# Simple slopes with specified values for the moderator
sim_slopes(mod2a, pred = stress, 
           modx = socsup, modx.values = c(5,37))

interact_plot(mod2a, pred = stress, 
              modx = socsup, modx.values = c(5,37))

#Can also use probe interaction to get simple slopes plot
#but not J-N plot
probe_interaction(mod2a, pred = stress, 
                  modx = socsup)

## Multiple moderators 

## Read in data

exMod2 <- read.csv("multiple_moderators.csv")

## Fit regression models

## Main effects model
mod1 <- lm(selfharm ~ stress + rum + age, data = exMod2)
summary(mod1)

#Two 2-way interactions
mod2 <- lm(selfharm ~ stress + rum + age + 
             stress:rum + stress:age, data = exMod2)
summary(mod2)


## Plot and probe with interactions

library(interactions)

sim_slopes(mod2, pred = stress, 
           modx = rum, mod2 = age, jnplot = TRUE)

interact_plot(mod2, pred = stress, 
              modx = rum, mod2 = age)

## Three-way interactions

#To get all 2 way interactions use the ^2 trick
mod2a <- lm(selfharm ~ (stress + rum + age)^2, data = exMod2)
summary(mod2a)

#To get the 3 way interactions use the ^3 trick
mod3 <- lm(selfharm ~ (stress + rum + age)^3, data = exMod2)
summary(mod3)

#The same thing, with R automatically creating product terms
mod3a <- lm(selfharm ~ stress * rum * age, data = exMod2)
summary(mod3a)

## Plot and probe with interactions
sim_slopes(mod3a, pred = stress, 
           modx = rum, mod2 = age, jnplot = TRUE)

interact_plot(mod3a, pred = stress, 
              modx = rum, mod2 = age)

### Combining mediation and moderation


## Read in data

exMedMod <- read.csv("medmod.csv")

#Get descriptives for probing interactions
summary(exMedMod)
#Use the 25, 50, and 75th percetiles of control
#-5.44, -0.44, 6.55

## Fit model in lavaan

medMod <-
  '
#a pathway (can use : to specify and interaction)
baia ~ a1*rumcen + a2*concen + a3*rumcen:concen

#cprime and b pathway
depcen ~ c1*rumcen + c2*concen + c3*rumcen:concen + b*baia

SSaLow  := a1 + a3*-5.44
SSaMed  := a1 + a3*-0.44
SSaHigh := a1 + a3*6.55

SScLow  := c1 + c3*-5.44
SScMed  := c1 + c3*-0.44
SScHigh := c1 + c3*6.55

indLow  := SSaLow*b
indMed  := SSaMed*b
indHigh := SSaHigh*b

indModMed := a3*b
'

fitMedMod <- sem(medMod, data = exMedMod)
summary(fitMedMod)

#Bootstrap CIs
fitMedModB <- sem(medMod, data = exMedMod,
                  se = "boot", bootstrap = 1000)
parameterEstimates(fitMedModB)

#Monte Carlo CIs

#Need to use parameter from the model, 
#not defined parameters
#Indirect effect low
monteCarloMed("(a1 + a3*-5.44)*b", object = fitMedMod)

#Indirect effect medium
monteCarloMed("(a1 + a3*-0.44)*b", object = fitMedMod)

#Indirect effect high
monteCarloMed("(a1 + a3*6.55)*b", object = fitMedMod)

#Index of Moderated Mediation
#Indirect effect low
monteCarloMed("a3*b", object = fitMedMod)

### Missing Data ###


## Example Regression using nhanes data

dat <- read.csv("nhanes.csv")


# linear regression model with listwise deletion
mod1 <- lm(bmi~ age2 + age3 + hyp + chl, data =dat)
summary(mod1)

##Use the mice package for MI

#Get rid of the age variable since it will cause problems

dat2 <- dat[,c("age2", "age3", "bmi", "hyp", "chl")]

library(mice)

imps <- mice(dat2, m = 20 )

#Imputation diagnostics

#Plot of MCMC chains
plot(imps)

#Plot observed and imputed data with a strip plot
#and box plots
stripplot(imps)

bwplot(imps)

##Looks like we need to impute with more iterations
imps <- mice(dat2, m = 20, maxit =  20)

#Fit model using the with command

impM <- with(imps, lm(bmi~ age2 + age3 + hyp + chl))

#Pool results with pool, use summary to see more results

results <- pool(impM)
results
summary(results)

pool.r.squared(impM)

#Compare a model without age
impM2 <- with(imps, lm(bmi~ hyp + chl))

D1(impM, impM2)

#Get overall test of a model
#Fit a model with only an intercept
impM3 <- with(imps, lm(bmi~ 1))

#Compare intercept model to model of interest
D1(impM, impM3)

## Use lavaan for fiml

modFIML <-'
bmi~ age2 + age3 + hyp + chl
'

fitFIML <- sem(modFIML, data = dat, missing = "fiml")
summary(fitFIML)
#by default lavaan only uses FIML for outcomes

#To use FIML for predictors too set fixed.x = FALSE
fitFIML2 <- sem(modFIML, data = dat, fixed.x = FALSE, missing = "fiml")
summary(fitFIML2)
#get R2
lavInspect(fitFIML2, "r2")

