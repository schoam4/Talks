#############################
### MLM                   ###
### Summer Stats Camp 2021###
### Alexander Schoemann   ###
#############################

### Power and sample size determination ###

## Example from Arend & Schafer (2019)

library(simr)
##### Example 1: R code for individuals-within-clusters example #####
set.seed(123)
#### Specification of Input Parameters ####
### Specification of standardized input parameters ###
L1_DE_standardized <- .10 	## standardized L1 direct effect
L2_DE_standardized <- .40 	## standardized L2 direct effect
ICC <- .10 			## standardized intraclass correlation coefficient
alpha.S <- .05 		## significance level
Size.clus <- 20 		## L1 sample size (cluster size)
N.clus <- 100 			## L2 sample size (number of clusters)

### Derivation of a population model for the power analysis ###
## Specification of predictor variables ##
x <- scale(rep(1:Size.clus))
g <- as.factor(1:N.clus)
X <- cbind(expand.grid("x"=x, "g"=g))
X <- data.frame(X, Z=as.numeric(X$g))
X$Z <- scale(X$Z)

## Specification of the outcome variable ##
varL1 <- 1 						## uncond. L1 variance (fixed at 1)
s <- sqrt((varL1)*(1-(L1_DE_standardized^2)))	## cond. L1 variance (Equation 11)
varL2 <- ICC/(1-ICC) 					## uncond. L2 variance (Equation 10)
V1 <- varL2*(1-(L2_DE_standardized^2)) 		## cond. L2 variance (Equation 11)

## Adjustment of fixed effects (Equation 15) ##
L1_DE <- L1_DE_standardized*sqrt(varL1)
L2_DE <- L2_DE_standardized*sqrt(varL2)

#### Implementation of a Power Analysis in a Two-Level Model in SIMR ####
### Vector of fixed effects ###
b <- c(0, L1_DE, L2_DE)

### Setting up the population model ###
model <- makeLmer(y ~ x + Z + (1|g), fixef=b, 
                  VarCorr=V1, sigma=s, data=X)
print(model)

### Simulating power for the L1 direct effect ###

#Only uses 100 replications for example, use more in real life!
sim.ef <- powerSim(model,
                   fixed("x","z"),
                   nsim=100)
print(sim.ef)
simdat_E1 <- cbind(effect="x", 
                   Size.clus, 
                   N.clus, 
                   L1_DE_standardized, 
                   L2_DE_standardized, 
                   summary(sim.ef))

### Simulating power for the L2 direct effect ###
sim.ef <- powerSim(model,
                   fixed("Z","z"),
                   nsim=100)
print(sim.ef)

### Power of all effects is stored in the data frame simdat_E1 ###
simdat_E1 <- rbind(simdat_E1,cbind(effect="Z", 
                                   Size.clus, 
                                   N.clus, 
                                   L1_DE_standardized, 
                                   L2_DE_standardized, 
                                   summary(sim.ef)))
simdat_E1

#### Power for longitudinal model 
#### Specification of Input Parameters ####
### Specification of standardized input parameters ###
L1_time <- .25 	## fixed effect of time
ICC <- .60 			## standardized intraclass correlation coefficient
alpha.S <- .05 		## significance level
Size.clus <- 4 		## number of observations per person (cluster size)
N.clus <- 70 			## number of people (number of clusters)

### Derivation of a population model for the power analysis ###
## Specification of predictor variables ##
x <- 0:3
g <- as.factor(1:N.clus)
X <- cbind(expand.grid("time"=x, "g"=g))


## Specification of the outcome variable ##
varL1 <- 1 						## uncond. L1 variance (fixed at 1)
s <- sqrt((varL1)*(1-(L1_time^2)))	## cond. L1 variance (Equation 11)
V1i <- ICC/(1-ICC) 		## cond. L2 variance (Equation 11)
V1s <- .2 ## Variance of the slope
V1c <- .2 ## intercept slope correlation
V1cov <- V1c*sqrt(V1i)*sqrt(V1s) ## intercept slope covariance

V <- matrix(c(V1i, V1cov, V1cov,V1s), nrow = 2, byrow = TRUE)

#### Implementation of a Power Analysis in a Two-Level Model in SIMR ####
### Vector of fixed effects ###
b <- c(5, L1_time)

### Setting up the population model ###
model <- makeLmer(y ~ time + (1 +time|g), fixef=b, VarCorr=V, sigma=s, data=X)
print(model)

### Simulating power for the L1 direct effect ###

#Only uses 100 replications for example, use more in real life!
sim.ef <- powerSim(model,
                   fixed("time","t"),
                   nsim=100)
print(sim.ef)
simdat_E2 <- cbind(effect="time", 
                   Size.clus, 
                   N.clus, 
                   L1_time, 
                   V1s, 
                   summary(sim.ef))

### Simulating power for the random slope ###
sim.ef <- powerSim(model,
                   compare(. ~ time + (1|g)),
                   nsim=100)
print(sim.ef)

### Power of all effects is stored in the data frame simdat_E1 ###
simdat_E2 <- rbind(simdat_E2,cbind(effect="rand slope", 
                                   Size.clus, 
                                   N.clus, 
                                   L1_time, 
                                   V1s, 
                                   summary(sim.ef)))
simdat_E2

## Use existing model
library(lme4)
library(lmerTest)

##Read in simchild data

simchild <- read.csv('simchild.csv', 
                     na.string = '-999999')
#Fit model with random intercept, fixed slope
m1a <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1|id), 
            data = simchild, 
            REML = FALSE)
summary(m1a)

sim.ex <- powerSim(m1a,
                   fcompare(~  0 + GRADE_C),
                   nsim=100)
print(sim.ex)
#0% power from errors in models
lastResult()$errors



### Multivariate Models ###

#Use nlme for complex level 1 error structure
library(nlme)

simchild <- read.csv('simchild.csv', 
                     na.string = '-999999')

#simchildMV has data management for multivariate models completed
simchildMV <- read.csv('simchildMV.csv', na.string = '-999999')
summary(simchildMV)
head(simchildMV)
tail(simchildMV)

#Univariate models for dad and mom
m1D <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML')
summary(m1D)
m1M <- lme(CLOSEMOM ~ 1 + GRADE_C, 
           random = ~ 1 + GRADE_C|id, data=simchild, 
           na.action = 'na.omit', method = 'ML')
summary(m1M)

# Fit multivariate model for closeness with mom and data
# D1 is Dad and D2 is MOM
m1 <- lme(CLOSE ~ 0 + D1 + D1_GRD_C + D2 + D2_GRD_C, data = simchildMV,
          random = ~0 + D1 + D1_GRD_C + D2 + D2_GRD_C| id,
          weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
          control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400))
summary(m1)

#Compare fixed effects
fixef <- rbind(c(fixef(m1D), fixef(m1M)),
        fixef(m1))
row.names(fixef) <- c("univariate", "multivariate")
fixef

#Compare random effects
VarCorr(m1D)
VarCorr(m1M)
VarCorr(m1)

#Equal fixed intercepts?

m1a <- lme(CLOSE ~ 1 + D1_GRD_C + D2_GRD_C, data = simchildMV,
           random = ~0 + D1 + D1_GRD_C + D2 + D2_GRD_C| id,
           weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
           control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400))
summary(m1a)
anova(m1,m1a)

#Equal random intercepts?

m1b <- lme(CLOSE ~ 0 + D1 + D1_GRD_C + D2 + D2_GRD_C, data = simchildMV,
           random = ~1 + D1_GRD_C + D2_GRD_C| id,
           weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
           control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400))
summary(m1b)
anova(m1,m1b)

#Equal fixed slopes?

simchildMV$GRADE_C <- simchildMV$GRADE - 1

m1a1 <- lme(CLOSE ~ 0 + D1 + D2 + GRADE_C, data = simchildMV,
           random = ~0 + D1 + D1_GRD_C + D2 + D2_GRD_C| id,
           weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
           control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400))
summary(m1a1)
anova(m1,m1a1)

#Equal variance of random slopes?

m1b1 <- lme(CLOSE ~ 0 + D1 + D2 + D1_GRD_C + D2_GRD_C, data = simchildMV,
            random = ~0 + D1 + D2 + GRADE_C| id,
            weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
            control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400))
summary(m1b1)
anova(m1,m1b1)

# Let  L1 residuals covary
m1c <- lme(CLOSE ~ 0 + D1 + D1_GRD_C + D2 + D2_GRD_C, data = simchildMV,
          random = ~0 + D1 + D1_GRD_C + D2 + D2_GRD_C| id,
          weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
          control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400),
          corr = corAR1())
summary(m1c)

# D1 is Dad and D2 is Mom
# SEX as L2 predictor, 
## Add SEX to the data SEX not in the DATA.

sexDf <- simchild[,c("id", "SEX")]
simchildMV1 <- merge(simchildMV, sexDf, by = "id")


m1S <- lme(CLOSE ~ 0 + D1 + D1_GRD_C + D2 + D2_GRD_C
          + D1:SEX + D1_GRD_C:SEX + D2:SEX + D2_GRD_C:SEX, data = simchildMV1,
          random = ~0 + D1 + D1_GRD_C + D2 + D2_GRD_C| id,
          weights = varIdent(form = ~1 | D1), na.action = "na.omit", method = 'ML',
          control = lmeControl(maxIter = 500, msMaxIter = 500, niterEM = 100, msMaxEval = 400))
summary(m1S)

### Three level models ###

library(lme4)
library(lmerTest)

#Read in loneliness data

#ID1=BEEPNUM;
#ID2=STUDYDAY;
#ID3=SUBNUM;

lonely <- read.csv('loneliness.csv', na.string = '-999')
summary(lonely)
head(lonely)
tail(lonely)

#need to set identifiers as factors
lonely$SUBNUM <- as.factor(lonely$SUBNUM)
lonely$STUDYDAY <- as.factor(lonely$STUDYDAY)
#Create overall identifier
lonely$BEEPNUM <- as.factor(lonely$BEEPNUM)

## How many subjects?
length(levels(lonely$SUBNUM))

m0 <- lmer(POSAFF ~ 1 + (1| SUBNUM/STUDYDAY ), 
           data = lonely, REML = FALSE)

summary(m0)

#ICC for proportion of variance
#Level 3
32.522/(43.829+7.581+32.522)
#Level 2
7.581/(43.829+7.581+32.522)

## ICC for expected correlation
#Level 3
32.522/(43.829+7.581+32.522)
#Level 2
(32.522+7.581)/(43.829+7.581+32.522)

#Remove L2
m0a <- lmer(POSAFF ~ 1 + (1|SUBNUM), 
            data = lonely, REML = FALSE)

summary(m0a)

#Remove L3
m0b <- lmer(POSAFF ~ 1 + (1|STUDYDAY:SUBNUM), 
            data = lonely, REML = FALSE)

summary(m0b)

#Fixed L1 predictor
m1 <- lmer(POSAFF ~ 1 + POSINT_1 + (1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1)
#Show fixed effects without scientific notation
fixef(m1)

#Random L1 predictor
m1r <- lmer(POSAFF ~ 1 + POSINT_1 + 
              (1 + POSINT_1|SUBNUM/STUDYDAY), 
            data = lonely, REML = FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))

summary(m1r)

anova(m1, m1r)

#L2 fixed predictor
m12 <- lmer(POSAFF ~ 1 + WEEKEND + 
              (1 |SUBNUM/STUDYDAY), 
            data = lonely, REML = FALSE)

summary(m12)

#L2 random predictor

#Create variable that is combination of subject and day
lonely$sample <- lonely$STUDYDAY:lonely$SUBNUM

m12r <- lmer(POSAFF ~ 1 + WEEKEND + 
               (1|sample) + (1 + WEEKEND |SUBNUM), 
             data = lonely, REML = FALSE)

summary(m12r)
anova(m12,m12r)

#Only random slope at L2
m1r2 <- lmer(POSAFF ~ 1 + POSINT_1 + 
               (1+ POSINT_1|sample) + (1|SUBNUM),
             data = lonely, REML = FALSE)

summary(m1r2)

#Compare to fixed effect only
anova(m1, m1r2)
#Compare to all random effects
anova(m1r2, m1r)

## Test interactions between level 1 and level 2 predictor

m2r2 <- lmer(POSAFF ~ 1 + POSINT_1*WEEKEND + 
               (1+ POSINT_1|sample) + (1 + WEEKEND|SUBNUM),
             data = lonely, REML = FALSE)

summary(m2r2)

library(interactions)
sim_slopes(m2r2, pred = POSINT_1, 
           modx = WEEKEND)
# Simple slopes plot
interact_plot(m2r2, pred = POSINT_1, modx = WEEKEND)

## Test interactions between level 2 and level 3 predictor

m12rINT <- lmer(POSAFF ~ 1 + WEEKEND*UCLASRV + 
                  (1|sample) + (1 + WEEKEND|SUBNUM), 
                data = lonely, REML = FALSE)

summary(m12rINT)

sim_slopes(m12rINT, pred = WEEKEND, 
           modx = UCLASRV, jnplot = TRUE)

#Autoregressive L1 predictor
m1 <- lmer(POSAFF ~ 1 + POSAFF_1 + (1+POSAFF_1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1)

m1f <- lmer(POSAFF ~ 1 + POSAFF_1 + (1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1f)

anova(m1,m1f)

m1i <- lmer(POSAFF ~ 1 + POSAFF_1 + POSINT_1 + (1+POSAFF_1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1i)

#Interaction between autoregressive slope and L2 predictor
m1w <- lmer(POSAFF ~ 1 + POSAFF_1*WEEKEND + (1+POSAFF_1|SUBNUM/STUDYDAY),
           data = lonely, REML = FALSE)

summary(m1w)
sim_slopes(m1w, pred = POSAFF_1, 
           modx = WEEKEND)

#Interaction between autoregressive slope and L3 predictor
m1l <- lmer(POSAFF ~ 1 + POSAFF_1*UCLASRV + (1+POSAFF_1|SUBNUM/STUDYDAY),
            data = lonely, REML = FALSE)

summary(m1l)
sim_slopes(m1w, pred = POSAFF_1, 
           modx = UCLASRV)
