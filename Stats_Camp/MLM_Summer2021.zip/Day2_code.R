#############################
### MLM with R            ###
### Summer Stats Camp 2021###
### Alexander Schoemann   ###
#############################

## Convert data from wide to long
library(tidyr)
library(dplyr)
library(lme4)
library(lmerTest)
library(interactions)

## Use hsb data
## Combine all tests into one variable

hsb <- read.csv("hsb2.csv")

head(hsb)

#Use the pivot_longer function in tidyr

hsbL <- pivot_longer(hsb, cols = c(read, write, math, science, socst),
                     names_to = "subject", values_to = "score")
hsbL <- as.data.frame(hsbL)

hsbL

### Centering ###

SB <- read.csv("SB.csv")

mean(SB$iq_verb)

# Grand mean centering
SB <- mutate(SB, IQV_CGM = iq_verb - 11.83406) 

SB <- mutate(SB, IQV_CGM2 = iq_verb - mean(SB$iq_verb))
# Group mean centering
#Use summarise command to compute group means
grpmeans<-summarise(group_by(SB, schoolnr), IQ_GM = mean(iq_verb))
grpmeans

##Merge group means back to data set by school (L2 unit)
SB<-merge(SB,grpmeans,by="schoolnr")
head(SB)
summary(SB)
# Group mean center
SB<- mutate(SB, IQV_CWC = (iq_verb - IQ_GM))
head(SB)
summary(SB)

#Uncentered
m1 <- lmer(langpost ~ 1 + iq_verb + (1 + iq_verb|schoolnr), 
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m1)

#Grand mean centered
m1Grand <- lmer(langpost ~ 1 + IQV_CGM + (1 + IQV_CGM|schoolnr),
                data=SB, REML=FALSE)
summary(m1Grand)

#Group mean centered
m1Group <- lmer(langpost ~ 1 + IQV_CWC + (1 + IQV_CWC|schoolnr), 
                data=SB, REML=FALSE)
summary(m1Group)

#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1 + IQV_CWC|schoolnr), 
                   data=SB, REML=FALSE)
summary(m1AddMeans)

##Compare fixed effects...
fixEFF <-rbind(c(fixef(m1),NA),c(fixef(m1Grand),NA),c(fixef(m1Group),NA),fixef(m1AddMeans))
rownames(fixEFF) <- c("uncentered", "Grand Mean Centered", "Group Mean Centered", "Group Mean Centered with means")
colnames(fixEFF)[3] <- "Grp Mean iq_verb"
fixEFF

# Center the group means
SB <- mutate(SB, IQV_GMC = IQ_GM - mean(SB$IQ_GM))
#Group mean centered with means added back in Group means centered
m1AddMeans2 <- lmer(langpost ~ 1 + IQV_CWC + IQV_GMC + 
                     (1 + IQV_CWC|schoolnr), 
                    data=SB, REML=FALSE)
summary(m1AddMeans2)


# Conditional Value centering
SB <- mutate(SB, IQV_CONDV = iq_verb - 8)

m1Cond <- lmer(langpost ~ 1 + IQV_CONDV + 
                      (1 + IQV_CONDV|schoolnr), 
               data=SB, REML=FALSE, 
               control = lmerControl(optimizer="Nelder_Mead"))
summary(m1Cond)

library(performance)

r2(m1)
r2(m1Grand)
r2(m1Group)
r2(m1AddMeans)

library(r2mlm)
r2mlm(m1)
r2mlm(m1Grand)
r2mlm(m1Group)
r2mlm(m1AddMeans)


#Refit without random slopes
#Uncentered
m1 <- lmer(langpost ~ 1 + iq_verb + (1 |schoolnr), 
           data=SB, REML=FALSE)
summary(m1)

#Grand mean centered
m1Grand <- lmer(langpost ~ 1 + IQV_CGM + (1 |schoolnr),
                data=SB, REML=FALSE)
summary(m1Grand)

#Group mean centered
m1Group <- lmer(langpost ~ 1 + IQV_CWC + (1 |schoolnr), 
                data=SB, REML=FALSE)
summary(m1Group)

#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1|schoolnr), data=SB, REML=FALSE)
summary(m1AddMeans)
r2(m1, by_group = TRUE)
r2(m1Grand, by_group = TRUE)
r2(m1Group, by_group = TRUE)
r2(m1AddMeans, by_group = TRUE)

### Interactions ###

##Disaggregated regression with interaction
m1a <- lm(langpost~ iq_verb + groupsiz, 
          data=SB)
summary(m1a)

m1 <- lm(langpost~ iq_verb * groupsiz, 
         data=SB)
summary(m1)

m1b <- lm(langpost~ iq_verb + groupsiz +iq_verb:groupsiz, 
          data=SB)
summary(m1b)

#compute intercept when grpsiz=5
(-.22+.44*5)
#compute slope when grpsiz=5
(3.35+-0.03*5)

#compute intercept when grpsiz=23
(-.22+.44*23)
#compute slope when grpsiz=23
(3.35+-0.03*23)

vcov(m1)

#use interactions package to probe

# Simple slopes and j-n intervals/plot
sim_slopes(m1, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, mod.range = c(0,37))
# Simple slopes plot
interact_plot(m1, pred = iq_verb, modx = groupsiz)


##MLM with interaction
m2a <- lmer(langpost~ iq_verb+groupsiz +
              (1 + iq_verb|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m2a)

m2 <- lmer(langpost~ iq_verb*groupsiz +
             (1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m2)

#R2 for random slope
(0.2024-0.1661)/0.2024

# Simple slopes and j-n intervals/plot
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, jnplot = TRUE)
# Simple slopes plot
interact_plot(m2, pred = iq_verb, modx = groupsiz)

# Simple slopes with specified values for the moderator
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, modx.values = c(5,37))

sim_slopes(m1, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, modx.values = "terciles")

# Simple slopes and j-n intervals/plot switch moderator
sim_slopes(m2, pred = groupsiz, 
           modx = iq_verb, jnplot = TRUE)

# Use group mean centered data
m2c <- lmer(langpost~ IQV_CWC*groupsiz + IQ_GM*groupsiz +
             (1 + IQV_CWC|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m2c)


m3a <- lmer(langpost~ iq_verb+percmino +(iq_verb|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m3a)

m3 <- lmer(langpost~ iq_verb*percmino +(1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m3)

##dichotomous predictor example with Hox data
pop <- read.csv('popular.csv')
summary(pop)
#For variable SEX: boy=0 girl=1
m3a <- lmer(POPULAR ~ SEX + TEXP + (1 + SEX|SCHOOL), 
            data=pop, REML=FALSE)
summary(m3a)

m3 <- lmer(POPULAR ~ SEX*TEXP + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)
summary(m3)

#R2 for random slope
(.2697-.2202)/.2697

#only for teaching, don't use L1 variable as a moderator!
sim_slopes(m3, pred = TEXP, modx = SEX)
interact_plot(m3, pred = TEXP, modx = SEX)

#this is the way to do it for real
sim_slopes(m3, pred = SEX, modx = TEXP)

#R2 for random slopes
(0.2697 - 0.2202)/0.2697

##MLM with interaction centered

#Grand mean centered
SB <- mutate(SB, groupsizC = groupsiz - mean(SB$groupsiz))

m2aC <- lmer(langpost~ IQV_CGM2+groupsizC +
               (1 + IQV_CGM2|schoolnr),
            data=SB, REML=FALSE)
summary(m2aC)

m2C <- lmer(langpost~ IQV_CGM2*groupsizC +(1 + IQV_CGM2|schoolnr),
           data=SB, REML=FALSE)
summary(m2C)


#Group mean centered
m2aC <- lmer(langpost~  IQV_CWC + IQ_GM+groupsizC +
               (1 + IQV_CWC|schoolnr),
             data=SB, REML=FALSE)
summary(m2aC)

m2C <- lmer(langpost~ IQV_CWC*groupsizC + IQ_GM*groupsizC +
              (1 + IQV_CWC|schoolnr),
            data=SB, REML=FALSE)
summary(m2C)

## 3-way interaction
m3way <- lmer(langpost~ iq_verb*groupsiz*percmino +
             (1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m3way)

### Estimation ###


## Use the popularity data
#For variable SEX: boy=0 girl=1
## Fit the same model with FIML and REML
m1ML <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 + SEX|SCHOOL), 
             data=pop, REML=FALSE)
m1MLa <- lmer(POPULAR ~ 1 + SEX + TEXP + (1|SCHOOL), 
             data=pop, REML=FALSE)
m1REML <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 + SEX|SCHOOL), 
               data=pop, REML=TRUE)
m1REMLa <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 |SCHOOL), 
               data=pop, REML=TRUE)

summary(m1ML)
summary(m1MLa)
summary(m1REML)

anova(m1MLa, m1ML)
anova(m1REMLa, m1REML)

confint(m1REML)

## Compare fixed effects, top row is FIML
rbind(fixef(m1ML), fixef(m1REML))

## Compare random effects
ranEFF <-cbind(data.frame(summary(m1ML)$varcor)[1:2,c(1,4)],data.frame(summary(m1REML)$varcor)[1:2,c(1,4)])
colnames(ranEFF) <- c(rep('ML', 2),rep('REML', 2))
ranEFF

m2REML <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 |SCHOOL), 
               data=pop, REML=TRUE)
summary(m2REML)

anova(m1REML, m2REML)

confint(m1REML, level = .90)



#Use in Hox Popularity data

##Compare nested models on random effects

m1 <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 |SCHOOL), 
           data=pop, REML=FALSE)
m2 <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)



anova(m1, m2)
summary(m1)
summary(m2)

#What about a model with uncorrelated random effects?
m2a <- lmer(POPULAR ~ 1 + SEX + TEXP + 
              (1|SCHOOL) +(0 + SEX|SCHOOL), 
            data=pop, REML=FALSE)

anova(m2,m2a)
summary(m2a)

anova(m2a,m1)

##Compare nested models on fixed effects

m3 <- lmer(POPULAR ~ 1 + SEX + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)
m4 <- lmer(POPULAR ~ 1 + SEX + TEXP + (1 + SEX|SCHOOL), 
           data=pop, REML=FALSE)

anova(m3, m4)
summary(m4)

##Compare non-nested models on fixed effects

m5 <- lmer(POPULAR ~ 1 + SEX + (1|SCHOOL), 
           data=pop, REML=FALSE)
m6 <- lmer(POPULAR ~ 1 + TEXP + (1 |SCHOOL), 
           data=pop, REML=FALSE)

anova(m5, m6) #BE CAREFUL! This still runs!
summary(m5)
summary(m6)

##Multiparamter tests
#Set up a matrix
#Compare sex and teacher experience slopes
k1 <- matrix(c(0, 1, -1), nrow=1)
colnames(k1) <- names(fixef(m4))
k1

#Add joint = FALSE and confint = TRUE to get 95% CI
contest(m4, L = k1, joint = FALSE, confint = TRUE)

#A more complex example
m5 <- lmer(POPULAR ~ 1 + SEX + TEXP + TEACHPOP +
             (1 + SEX|SCHOOL), data=pop, REML=FALSE)
summary(m5)

# Are slopes f0r SEX, TEXP, and TEACHPOP equal?

k2<- matrix(c(0, -1, 0, 1, 
              0, 0, 1, -1), nrow=2, byrow = TRUE)
colnames(k2) <- names(fixef(m5))
k2

#By default it tests both contrasts together
contest(m5, L = k2)

#To test each contrast separately use joint = FALSE
contest(m5, L = k2, joint = FALSE, confint = TRUE)

## Use to test contextual effects

m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1|schoolnr), data=SB, REML=FALSE)
summary(m1AddMeans)

k1 <- matrix(c(0, 1, -1), nrow=1)
colnames(k1) <- names(fixef(m1AddMeans))
k1

#Add joint = FALSE and confint = TRUE to get 95% CI
contest(m1AddMeans, L = k1, joint = FALSE, confint = TRUE)

