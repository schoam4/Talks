#############################
### MLM                   ###
### Summer Stats Camp 2021###
### Alexander Schoemannn  ###
#############################


### Introduction to R ###


##R can be a calculator
3+4

3*4

3   ^    5

(12+
    5)/13



##Everything is an object

x <- 3

x

x+4

#You can overwrite existing objects!
x <- c(1,2)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('C:/Users/schoemanna/Documents/Workshops/Intro2R/hsb2.csv', 
                 stringsAsFactors = TRUE)

dat1

head(dat1)

tail(dat1)

summary(dat1)

library(haven)

dat2 <- read_spss('hsb2.sav')

dat3 <- read.csv("~/Workshops/Stats Camp/MLM_Summer2020/hsb2.csv")

dat2

head(dat2)

tail(dat2)

summary(dat2)

dat1$prog

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

summary(dat1)

summary(dat1$math)

library(rockchalk)

summarize(dat1)

library(psych)

describe(dat1)

##Packages
#Install the mice package
install.packages('mice')

install.packages('haven')

#load the mice package
library(mice)


### Handling Nested Data ###

## Load packages needed
library(lme4)
library(lmerTest)
library(rms)
library(clubSandwich)


##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)

##Disaggregated regression

m1 <- lm(langpost ~ iq_verb, data=SB)
summary(m1)

##Aggregated regression

#use aggregate function to compute group means

langpost<-aggregate(SB$langpost, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)
iq_verb<-aggregate(SB$iq_verb, by=list(SB$schoolnr),FUN=mean,na.rm=TRUE)

grpmeans <- data.frame(cbind(langpost$x, iq_verb$x))
names(grpmeans) <- c('langpost', 'iq_verb')

summary(grpmeans)

m2 <- lm(langpost~iq_verb, data=grpmeans)
summary(m2)

##Adjusting standard errors
# use ols function from rms package

m3 <- ols(langpost~iq_verb, data=SB, x=TRUE, y=TRUE)
robcov(m3, cluster=SB$schoolnr)

## Or use clubSandwich package
# Uses the lm() results
coef_test(m1, vcov = "CR2", 
          cluster = SB$schoolnr, test = "Satterthwaite")

##Fixed effects approach
m4 <- lm(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m4)

##ANCOVA (same as fixed effects approach)
m5 <- aov(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m5)


##Seperate regressions

mL <- lmList(langpost~iq_verb|schoolnr, data=SB, 
             pool=FALSE, na.action=na.omit)
summary(mL)

#Get mean intercept and across schools
colMeans(coef(mL))

#Plot seperate regression lines for all schools
plot(SB$iq_verb, SB$langpost, xlab = "iq_verb", ylab = "langpost", type = 'n')

for(i in 1:dim(coef(mL))[[1]]){
  abline(coef=coef(mL)[i,])
  
}

##Multilevel models

m6 <- lmer(langpost~ 1 + (1 |schoolnr), data = SB, 
           REML = FALSE)
summary(m6)

#compute ICC
19.43/(64.57+19.43)

### Adding Predictors ###

#fixed L1 predictor
m7 <- lmer(langpost~ 1 + iq_verb + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor

m8 <- lmer(langpost ~ 1 + iq_verb + (1+iq_verb|schoolnr), 
           data = SB, REML = FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m8)

#Compare model with fixed and random slopes

anova(m7, m8)

#use ranova to test random effects
ranova(m8)

#confidence interval for all effects
confint(m8)

confint(m8, level = .90)

#fixed L2 predictor
m9 <- lmer(langpost~1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)


## Effect sizes

#Level specific r2 "by hand" for random slopes model
(64.57- 41.48)/64.57
(19.43 - 65.88)/19.43

# For R2 measures use the performance package
library(performance)

# Overall R2 conditional and marginal
r2(m7)
r2(m8)
r2(m9)

# Level specific R2
r2(m7, by_group = TRUE)
r2(m8, by_group = TRUE) #Doesn't make sense with random slopes!
r2(m9, by_group = TRUE)

# Rights and Sterba R2 from r2mlm
library(r2mlm)

r2mlm(m7)
r2mlm(m8)
r2mlm(m9)

#standardized mean difference
m10 <- lmer(langpost~1 + sex + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m10)

sd(SB$langpost)

2.5679/9.003676

# Standardized slopes

# Standardize outcomes and predictors

SB$langpostS <- scale(SB$langpost)
SB$iq_verbS <- scale(SB$iq_verb)
SB$percminoS <- scale(SB$percmino)

# Fit models with L1 and L2 predictors
# DO NOT USE THESE FOR HYPOTHESIS TESTING!
m7S <- lmer(langpostS~1 + iq_verbS + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m7S)

m9S <- lmer(langpostS~1 + percminoS + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9S)

# Use Hox (2010) computations from raw models

#Slope of verbal IQ
fixef(m7)

#SD verbal IQ
sd(SB$iq_verb)

#SD langpost
sd(SB$langpost)

#Standardized slope
(2.488094*2.06889)/9.003676
