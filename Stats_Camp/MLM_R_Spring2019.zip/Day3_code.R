#############################
### MLM with R            ###
### Spring Stats Camp 2019###
### Alexander Schoemannn  ###
#############################

### Three level models ###

library(lme4)
library(lmerTest)
library(foreign)

#Read in loneliness data

#ID1=BEEPNUM;
#ID2=STUDYDAY;
#ID3=SUBNUM;

lonely <- read.csv('loneliness.csv', na.string = '-999')
summary(lonely)
head(lonely)
tail(lonely)

#need to set identifiers as factors
lonely$SUBNUM <- as.factor(lonely$SUBNUM)
lonely$STUDYDAY <- as.factor(lonely$STUDYDAY)
#Create overall identifier
lonely$BEEPNUM <- as.factor(lonely$BEEPNUM)

m0 <- lmer(POSAFF ~ 1 + (1|SUBNUM/STUDYDAY), data = lonely, REML = FALSE)

summary(m0)


#Fixed L1 predictor
m1 <- lmer(POSAFF ~ 1 + POSINT_1 + (1|SUBNUM/STUDYDAY), data = lonely, REML = FALSE)

summary(m1)

#Random L1 predictor
m1r <- lmer(POSAFF ~ 1 + POSINT_1 + (1 + POSINT_1|SUBNUM/STUDYDAY), data = lonely, REML = FALSE)

summary(m1r)

#L2 fixed predictor
m12 <- lmer(POSAFF ~ 1 + WEEKEND + (1 |SUBNUM/STUDYDAY), data = lonely, REML = FALSE)

summary(m12)

#L2 random predictor

#Create variable that is combination of subject and day
lonely$sample <- lonely$STUDYDAY:lonely$SUBNUM

m12r <- lmer(POSAFF ~ 1 + WEEKEND + (1|sample) + (1 + WEEKEND|SUBNUM), data = lonely, REML = FALSE)

summary(m12r)
anova(m12,m12r)

### Cross Classified Models ###

#Data from Hox (2002)

pupcross<-read.dta("https://stats.idre.ucla.edu/stat/stata/examples/mlm_ma_hox/pupcross.dta")

pupcross$pXsschool <- pupcross$sschool*pupcross$pschool

m0<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool), pupcross, REML=FALSE)
summary(m1)

m1<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + (1|pXsschool), pupcross, REML=FALSE)
summary(m1)

m1a<-lmer(achiev ~ pupsex + pupses +(1|sschool) + (1|pschool) , pupcross, REML=FALSE)
summary(m1a)

m2<-lmer(achiev ~ pupsex + pupses +(1|sschool) + (pupsex|pschool) , pupcross, REML=FALSE)
summary(m2)

m3<-lmer(achiev ~ pupsex  + pupses + pdenom + sdenom +(1|sschool) + (pupses|pschool), pupcross, REML=FALSE)
summary(m3)

### Binary outcomes ###


#Read in loop data for categorical outcome
#13,007 students in 369 schools
# interested in predicting if students took a science course

loop <- read.csv('loop.csv')
summary(loop)

#null model

mc0 <- glmer(scisub ~ 1 + (1|school), data = loop, family = binomial)
summary(mc0)

#odds of taking a science class
exp(fixef(mc0))
#probability of taking a science class
exp(fixef(mc0)) / (1 + exp(fixef(mc0)))

#ICC
0.45592 / (0.45592 + (pi/3))

#gender (0=boys, 1= girls) and minority (0=no, 1=yes) status as predictors

mc0 <- glmer(scisub ~ 1 + gender + minority + (1|school), data = loop, family = binomial)
summary(mc0)

#odds ratios for fixed predictors
exp(fixef(mc0))

#Random effect
mc1 <- glmer(scisub ~ 1 + gender + minority + (gender|school), data = loop, family = binomial)
summary(mc1)

#odds ratios for fixed predictors
exp(fixef(mc1))

#Test random effect
anova(mc0, mc1)

