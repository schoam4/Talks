##############################
### MVM with R             ###
### Summer Stats Camp 2024 ###
### Alexander Schoemann    ###
##############################


### Introduction to R ###


##R can be a calculator
3 + 4 

3*4

3 ^       5 #white space doesn't matter

(12+
    5)/13



##Everything is an object

x <- 3

x

x+4

stats_camp_is_awesome <- 2024
stats.camp.is.awesome2024 <- 2024
StatsCampIsAwesome2024 <- 2024

x + stats_camp_is_awesome

stats_camp_is_awesome <- 3000
#Create a vector

c(1,2,3,4)

y <- c(1,2,3,4)

y

y + 3

y + x

mean(y+x, na.rm = TRUE)

#Character vector

char <- c(1, "b2", "c3")

#Logical vector
yl <- y == 2

yl1 <- y < 3

yl2 <- y <= 7

charl <- char == "c3"

# Use is. and as. to check and convert vectors
is.logical(yl)
is.logical(y)

as.numeric(yl)

as.character(y)

#You can overwrite existing objects!
x <- c(1,2)

x

##Read in data
##We will use the hsb2 data set (from the UCLA statistics website)
?read.csv

getwd()

dat1 <- read.csv('C:/Users/schoemanna/Documents/Workshops/Stats Camp/MVM_R_Summer2024/hsb2.csv', 
                 stringsAsFactors = TRUE)

dat1

head(dat1)

head(dat1, n = 9)

tail(dat1)

summary(dat1)

library(haven)

dat2 <- read_spss('hsb2.sav')

dat2

head(dat2)

tail(dat2)

summary(dat2)

dat2 <- as.data.frame(dat2)

#Read in excel file
library(readxl)

dat3 <- read_excel("hsb2.xlsx", sheet = 1)
dat3

## Pick out one variable
dat1$prog

##But prog is a categorical variable with 3 levels! We need to make it a 'factor' so R treats it this way
dat1$prog <- as.factor(dat1$prog)

dat1$progN <- as.numeric(dat1$prog)

summary(dat1)

summary(dat1$math)

library(rockchalk)

summarize(dat1)

library(psych)

describe(dat1)

## Write results to csv
descrip <- describe(dat1)

write.csv(descrip, "descriptives.csv")

## Selecting rows and columns

# use [], dat[rows,columns]

dat1[1,3] #1st row 3rd column

dat1[4,] #whole 4th row

dat1[,4] #Whole 4th column

dat1[,c(4, 7, 11)] #3 columns column

dat1[,c("ses", "read", "socst")] #3 columns column

dat1[dat1$schtyp == 2, ] #rows with school tpye = 2

datPrivF <- dat1[dat1$schtyp == 2 & dat1$female == 1, ] #rows with school tpye = 2 and female


dat1[,c("prog", "read", "socst")] #3 columns column


library(dplyr)

datPrivF2 <- filter(dat1, schtyp == 2, female == 1) #rows with school tpye = 2

select(dat1, female:schtyp)

library(MASS)

dplyr::select(dat1, female:schtyp)


##Plotting!

plot(dat1)

plot(dat1$math)

plot(dat1$prog)

plot(dat1$math, dat1$science)

plot(dat1$prog, dat1$math)

hist(dat1$math)

boxplot(dat1$math)

#Prettier plot
plot(dat1$math, dat1$science, main = "Scatterplot of Math and Science",
         xlab = "Math", ylab = "Science", col = "red")

##Packages
#Install the mice package
install.packages('mice')

install.packages('haven')

#load the mice package
library(mice)

##Data manipulation

#Create total score using base R
dat1$tot <- (dat1$read + dat1$write + dat1$math + dat1$science +
               dat1$socst)/5

dat1$STEM <- (dat1$math + dat1$science)/2

## Same thing with dplyr
#install.packages('dplyr') #Run if dplyr is not installed
library(dplyr)

dat1 <- mutate(dat1, tot2 =  (read + write + math +
                             science + socst)/5,
                   STEM2 = (math + science)/2)

dat1 <- mutate(dat1, tot3 =  mean(c(read, write, math,
                                science, socst)),
               STEM3 = mean(c(math, science))) 

#Specify where new variables go with .before or .after
dat1 <- mutate(dat1, tot4 =  mean(c(read, write, math,
                                    science, socst)),
               STEM4 = mean(c(math, science)), .before = ses) 

## merge

#Add variables
datBig <- merge(dat1, dat2, by = "id", suffixes = c("T1", "T2"))

#Add cases
dat3 <- as.data.frame(dat3)
datLong <- rbind(dat2, dat3)

##Analyses

t.test(write ~ female, data=dat1)

t.test(dat1$write, dat1$science, paired = TRUE)

library(lsr)

independentSamplesTTest(write ~ female, data=dat1)

pairedSamplesTTest(~ write + science, data = dat1)

### Regression ###

mod0 <- lm(math ~ 1, data=dat1)

summary(mod0)

mod1 <- lm(math ~ science, data=dat1)

summary(mod1)

dat1$schtyp <- as.factor(dat1$schtyp)

mod1c <- lm(math ~ schtyp + science, data=dat1)

summary(mod1c)

#Compare to a model with only science as a predictor
anova(mod1, mod1c)

anova(mod1, mod0)#Same F statistic as mod1

## Confidence Intervals for parameters
confint(mod1c)

## Standardized coefficients
## Maybe not the best thing here...
library(effectsize)
effectsize(mod1)
effectsize(mod1c) #be careful of categorical predictors!

#partial r2
eta_squared(mod1c, partial = TRUE)
#semi-partial r2
eta_squared(mod1c, partial = FALSE)


## CI for R2
library(MBESS)

## CI for R2 for model 1
ci.R2(.4011, 2, 197, conf.level = .90)

## CI for R2 difference
ci.R2(.0033, 1, 198, conf.level = .90)

#Report most results together with apaTables
library(apaTables)

apa.reg.table(mod1)

#90% CIs
apa.reg.table(mod1c, prop.var.conf.level = 0.90)

#Output as Word
apa.reg.table(mod1c, filename = "test1.doc",prop.var.conf.level = 0.90)


apa.reg.table(mod1, mod1c)

apa.cor.table(dat1[,c("science", "math", "read")])

#Output to word and only use schtyp = 1
apa.cor.table(dat1[dat1$schtyp == 1,c("science", "math", "read")], 
              filename = "testCor.doc")


## We will use the car package for diagnostics
library(car)

#Now we can pull everything we want out of the 
#mod1c object

#Influence measures
influence.measures(mod1c)

#often this prints too much so we look at each one alone

#residuals
resid(mod1c)

#Standardized Residuals
rstandard(mod1c)

#Studentized Residuals
rstudent(mod1c)

rconcern <- rstudent(mod1c) > 3
dat1[rconcern,]

rconcern <- rstudent(mod1c) < -3
dat1[rconcern,]
rstudent(mod1c)[rconcern]

rconcernA <- abs(rstudent(mod1c)) > 2.5
dat1[rconcernA,]
rstudent(mod1c)[rconcernA]

#leverage
hatvalues(mod1c)
2*(2+1)/200
concern <- hatvalues(mod1c) > .03

#Find cases to investigate
dat1[concern,c("schtyp", "science")]
hatvalues(mod1c)[concern]

# Cook's d
cooks.distance(mod1c)

Cconcern <- cooks.distance(mod1c) > 1
dat1[Cconcern,]

dat1a <- dat1[-21,]

mod1r <- lm(math ~ schtyp + science, 
            data=dat1, subset = !rconcern)
summary(mod1r)

rconcern <- abs(rstudent(mod1r)) > 2.5
dat1[rconcern,]
rstudent(mod1r)[rconcern]

#dfbetas
round(dfbetas(mod1c), 3)

dfconcern <- abs(dfbetas(mod1c)) > 2/sqrt(200)

#Rows with true. Needs work.
rowSums(as.numeric(dfconcern))

dfbetas(mod1c)[dfconcern]

sort(dfbetas(mod1c)[dfconcern])

#Plotting a regression object gives you 4 plots
#including residual plot and q-q plots

plot(mod1c)


#We can also pull out specific plots with the which command

#Residuals plot
plot(mod1, which = 1)

#q-q plot of residuals
plot(mod1, which = 2)

hist(resid(mod1))

#Can also use the car package for this
influenceIndexPlot(mod1c)
influencePlot(mod1)

#Multicollinearity

#VIF 
vif(mod1c)

#Tolerance
1/vif(mod1c)


#Model with the categorical variance prog

#note for prog: 1 = academic, 2 = general, 3 = vocational
## By default R uses dummy coding with the first category as the baseline
mod3 <- lm(math ~ schtyp + science + prog, data=dat1)
summary(mod3)
anova(mod3)
anova(mod1c,mod3)

apa.reg.table(mod1c, mod3)

## The C command (in the regression formula) can change defaults
mod4 <- lm(math ~ schtyp + science + C(prog, base = 2), 
           data=dat1)
summary(mod4)
anova(mod1c,mod4)

levels(dat1$prog) <- c("academic", "general", "vocational")


dat1$ses <- as.factor(dat1$ses)
## The C command (in the regression formula) can change defaults
mod5 <- lm(math ~ schtyp + science + prog + ses, data=dat1)
summary(mod5)
anova(mod4,mod5)

mod5a <- lm(math ~ schtyp + science + ses, data=dat1)
summary(mod5a)
anova(mod5a,mod5)#test of program type controlling for SES...

## Effect coding
## The contr.sum contrasts use effects coding. 
## By default the last category is the baseline category
mod4e <- lm(math ~ schtyp + science + C(prog, contr = "contr.sum"), 
           data=dat1)
summary(mod4e)
anova(mod1c,mod4e)

## Just test program, equivalent to 1-way ANOVA
mod5 <- lm(math ~ prog, data=dat1)
summary(mod5)

mod5m <- lm(math ~ 0 + prog, data=dat1)
summary(mod5m)

mod5a <- aov(math ~ prog, data=dat1)
summary(mod5)
mod5a

oneway.test(math ~ prog, data=dat1)

library(emmeans)

emmeans(mod5, "prog")



emmeans(mod4, "prog")

emmeans(mod4, "prog", by = "schtyp")


#Interaction between categorical variables
mod5i <- lm(math ~ schtyp + science + prog * ses, data=dat1)
summary(mod5i)
anova(mod5,mod5i)

emmeans(mod5i, "prog", by = "ses")
emmeans(mod5i, "ses", by = "prog")


## Example heteroscedastic corrected standard errors

library(sandwich)
library(lmtest)

coeftest(mod1c, vcov = vcovHC)

## Extra Practice

#Read in the data set multiple_moderators.csv
#Compute descriptive statistics for all variables
# Fit a model with age (treated as categorical)
# rum (rumination), and stress predicting selfharm
# Test parameters and compute effect sizes

multmod <- read.csv("multiple_moderators.csv")

head(multmod)

summary(multmod)

multmod$age <- as.factor(multmod$age)

table(multmod$age)

mod1 <- lm(selfharm ~ C(age, base = 2) + rum + stress, data = multmod)
summary(mod1)

mod1a<- lm(selfharm ~ rum + stress, data = multmod)
summary(mod1a)

anova(mod1a, mod1) #Test of age

apa.reg.table(mod1)
