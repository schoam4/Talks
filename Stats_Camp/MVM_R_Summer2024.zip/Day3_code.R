##############################
### MVM with R             ###
### Summer Stats Camp 2024 ###
### Alexander Schoemann    ###
##############################

library(lme4)
library(lmerTest)
library(nlme)
library(interactions)
library(dplyr)
library(clubSandwich)

### Multilevel Modeling ###

### Handling Nested Data ###


##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)

##Disaggregated regression

m1 <- lm(langpost ~ iq_verb, data=SB)
summary(m1)

##Aggregated regression

#use summarise function to compute group means
grpmeans<-summarise(group_by(SB, schoolnr), 
                    iq_verb = mean(iq_verb),
                    langpost = mean(langpost))
grpmeans

summary(grpmeans)

m2 <- lm(langpost~iq_verb, data=grpmeans)
summary(m2)

##Adjusting standard errors
## use clubSandwich package
# Uses the lm() results from disagregated regression

coef_test(m1, vcov = "CR2", 
          cluster = SB$schoolnr, 
          test = "Satterthwaite")

##Fixed effects approach
m4 <- lm(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m4)

##ANCOVA (same as fixed effects approach)
m5 <- aov(langpost~iq_verb+factor(schoolnr), data=SB)
summary(m5)


##Separate regressions

mL <- lmList(langpost~iq_verb | schoolnr, data=SB, 
             pool=FALSE, na.action=na.omit)
summary(mL)

#Get mean intercept and across schools
colMeans(coef(mL))

#Plot seperate regression lines for all schools
plot(SB$iq_verb, SB$langpost, xlab = "iq_verb", ylab = "langpost", type = 'n')

for(i in 1:dim(coef(mL))[[1]]){
  abline(coef=coef(mL)[i,])
  
}




##Multilevel models

m6 <- lmer(langpost~ 1 + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m6)

as.data.frame(VarCorr(m6))

#compute ICC
19.43/(64.57+19.43)

#Automated ICC
m6V <- as.data.frame(VarCorr(m6))

m6V$vcov[1]/sum(m6V$vcov)


### Adding Predictors ###

#fixed L1 predictor
m7 <- lmer(langpost~ 1 + iq_verb + (1 |schoolnr), 
           data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor

m8 <- lmer(langpost ~ 1 + iq_verb + (1+iq_verb|schoolnr), 
           data = SB, REML = FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m8, correlation = FALSE)

#Compare model with fixed and random slopes

anova(m7, m8)

#use ranova to test random effects
ranova(m8)

#confidence interval for all effects
confint(m8)

confint(m8, level = .90)

#fixed L2 predictor
m9 <- lmer(langpost~1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)

#fixed L2 predictor
m10 <- lmer(langpost ~ 1 + iq_verb + percmino + sex + 
              (1+iq_verb|schoolnr), 
            data = SB, REML = FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))

summary(m10)


## Effect sizes

#Level specific r2 "by hand" for fixed slopes model
(64.57- 42.227)/64.57
(19.43 - 9.497)/19.43

#Level specific r2 "by hand" for random slopes model
(64.57- 41.48)/64.57
(19.43 - 65.88)/19.43

# For R2 measures use the performance package
library(performance)

# Overall R2 conditional and marginal
r2(m7)
r2(m8)
r2(m9)

# Level specific R2
r2(m7, by_group = TRUE)
r2(m8, by_group = TRUE) #Doesn't make sense with random slopes!
r2(m9, by_group = TRUE)

# Rights and Sterba R2 from r2mlm
library(r2mlm)

r2mlm(m7)
r2mlm(m8)
r2mlm(m9)


#standardized mean difference
m10 <- lmer(langpost~1 + sex + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m10)

#Total SD
sd(SB$langpost)

2.5679/9.003676

#L1 SD
2.5679/8.035

# Standardized slopes

# Standardize outcomes and predictors

SB$langpostS <- scale(SB$langpost)
SB$iq_verbS <- scale(SB$iq_verb)
SB$percminoS <- scale(SB$percmino)

# Fit models with L1 and L2 predictors
# DO NOT USE THESE FOR HYPOTHESIS TESTING!
m7S <- lmer(langpostS~1 + iq_verbS + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m7S)

m9S <- lmer(langpostS~1 + percminoS + (1 |schoolnr), 
            data = SB, REML = FALSE)
summary(m9S)

# Use Hox (2010) computations from raw models

#Slope of verbal IQ
fixef(m7)

#SD verbal IQ
sd(SB$iq_verb)

#SD langpost
sd(SB$langpost)

#Standardized slope
(2.488094*2.06889)/9.003676


### Interactions ###


##MLM with interaction
m2a <- lmer(langpost~ iq_verb + groupsiz +
              (1 + iq_verb|schoolnr),
            data=SB, REML=FALSE, 
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m2a)

m2 <- lmer(langpost~ iq_verb * groupsiz +
             (1 + iq_verb|schoolnr),
           data=SB, REML=FALSE, 
           control = lmerControl(optimizer="Nelder_Mead"))
summary(m2)

#R2 for random slope
(0.2024-0.1661)/0.2024

# Simple slopes and j-n intervals/plot
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, jnplot = TRUE)
# Simple slopes plot
interact_plot(m2, pred = iq_verb, modx = groupsiz)

# Simple slopes with specified values for the moderator
sim_slopes(m2, pred = iq_verb, 
           modx = groupsiz, modx.values = c(5,37))

sim_slopes(m2, pred = iq_verb, modx = groupsiz, 
           jnplot = TRUE, modx.values = "terciles")

# Simple slopes and j-n intervals/plot switch moderator
sim_slopes(m2, pred = groupsiz, 
           modx = iq_verb, jnplot = TRUE)

## Centering

## Use group mean centering and group means
## To separate L1 and L2 effects for a L1 predictor
# Group mean centering
#Use summarise command to compute group means
grpmeans<-summarise(group_by(SB, schoolnr), 
                    IQ_GM = mean(iq_verb))
grpmeans

##Merge group means back to data set by school (L2 unit)
SB<-merge(SB,grpmeans,by="schoolnr")
head(SB)
summary(SB)

SB <- mutate(SB, IQV_CWC = iq_verb - IQ_GM,
          )

#Group mean centered with means added back in
m1AddMeans <- lmer(langpost ~ 1 + IQV_CWC + IQ_GM + 
                     (1 + IQV_CWC|schoolnr), 
                   data=SB, REML=FALSE)
summary(m1AddMeans)

r2mlm(m1AddMeans)


## Convert data from wide to long
library(tidyr)

## Use hsb data
## Combine all tests into one variable

hsb <- read.csv("hsb2.csv")

head(hsb)

#Use the pivot_longer function in tidyr

hsbL <- pivot_longer(hsb, cols = c(read, write, math, science, socst),
                     names_to = "subject", values_to = "score")
hsbL <- as.data.frame(hsbL)

hsbL

names(hsb)[grep( "s", names(hsb))]

#Use all variables with S
hsbL2 <- pivot_longer(hsb, cols = names(hsb)[grep( "s", names(hsb))],
                     names_to = "subject", values_to = "score")
hsbL2 <- as.data.frame(hsbL2)

### Longitudinal Data ###



##Read in simchild data

simchild <- read.csv('simchild.csv', 
                      na.string = '-999999')
summary(simchild)
head(simchild)

#Fit model with fixed intercept, fixed slope. 
#Need to do this with regression
m1 <- lm(CLOSEDAD ~ 1 + GRADE_C, data = simchild)
summary(m1)

#Null model
m0a <- lmer(CLOSEDAD ~ 1 +  (1|id), data = simchild, 
            REML = FALSE)
summary(m0a)

#ICC
10.09/(10.09+7.85)

#Fit model with random intercept, fixed slope
m1a <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1|id), 
            data = simchild, 
            REML = FALSE)
summary(m1a)

#Fit model with fixed intercept, random slope
m1b <- lmer(CLOSEDAD ~ 1 + GRADE_C + (0 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1b)

#Fit model with random intercept, random slope
m1c <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1c, correlation = FALSE)

#Random intercept, random slope model with uncentered data
m1d <- lmer(CLOSEDAD ~ 1 + GRADE + (1 + GRADE|id), 
            data = simchild, REML = FALSE)
summary(m1d)

#Compare models
anova(m1a,m1c)#test of random slope variance
anova(m1b, m1c)#test of random intercept variance

#profile CI for random intercepts and slopes
#this might take a while...
confint(m1c, method="profile")

confint(m1c, method="profile", level = .90)

#Random intercept, random slope model with rescaled time

simchild$dec <- simchild$GRADE_C/10

m1e <- lmer(CLOSEDAD ~ 1 + dec + (1 + dec|id), 
            data = simchild, REML = FALSE)
summary(m1e)


##The aperature for this model Tau_0,1/Tau_1,1

#Compute covariance (only get correlation in lmer)
tauCor <- matrix(c(1,.47, .47, 1), byrow=TRUE, nrow=2)
library(lavaan)
tauCov <- cor2cov(tauCor, c(2.5775, 0.3904))

.47*2.5775*.3904

#apature
-tauCov[1,2]/tauCov[2,2]

#Create new time variable
simchild$NEW_GRADE <- simchild$GRADE_C - (-tauCov[1,2]/tauCov[2,2])

#Fit model with random intercept, random slope
m1cAP <- lmer(CLOSEDAD ~ 1 + NEW_GRADE + (1 + NEW_GRADE|id), 
              data = simchild, REML = FALSE)
summary(m1cAP)

confint(m1cAP, method="profile", level = .90)


## Plot random intercept random slopes

## use ggplot
randE <- ranef(m1c, condVar = TRUE)
randE$id[,1] <- randE$id[,1]+fixef(m1c)[1]
randE$id[,2] <- randE$id[,2]+fixef(m1c)[2]


library(ggplot2)
dd <- as.data.frame(randE)
ggplot(dd, aes(y=grp,x=condval)) +
  geom_point() + facet_wrap(~term,scales="free_x") +
  geom_errorbarh(aes(xmin=condval -2*condsd,
                     xmax=condval +2*condsd), height=0)



#Plot results for linear model
#Get slopes
slopes <- fixef(m1c)
#Get values of time
GRADE <- 0:5


y <- slopes[1] + slopes[2]*GRADE 

plot(GRADE, y, type = "l")

## Use coef to get regression lines for each person:
reff <- coef(m1c)$id
dim(reff)

ys <- NULL
for(i in 1:dim(reff)[1]){
  ys1 <- reff[i,1] + reff[i,2]*GRADE 
  ys <-rbind(ys,ys1)
}
ys

#Plot separate regression lines for all participants
plot(GRADE, y, ylab = "CLOSEDAD", type = 'n',
     ylim = c(25,40))


for(i in 1:dim(reff)[1]){
  lines(GRADE, ys[i,], col = "grey")
}

lines(GRADE, y, ylab = "CLOSEDAD", lwd = 2, col = "red")



##Does gender predict growth? Use CONFLMOM now
## Boys = 1, girls = 0

##Predicting overall
m1d <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1d)


##Predicting intercept and slope
m1f <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + GRADE_C*SEX + 
              (1 + GRADE_C|id),
            data = simchild, REML = FALSE)
summary(m1f)

#Probe interaction between time and SEX
library(interactions)
sim_slopes(m1f, pred = GRADE_C, modx = SEX)
interact_plot(m1f, pred = GRADE_C, modx = SEX)


#Time varying covariate. Change in CLOSEDAD controlling for CLOSEMOM
#Time varying covariate should be centered so the intercept is interpretable
m1h <- lmer(CLOSEDAD ~ 1 + GRADE_C + CLOSEMOM + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1h)

## Interaction of time and closemom
m1hi <- lmer(CLOSEDAD ~ 1 + GRADE_C * CLOSEMOM + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1hi)

#Random intercept, random slope model with quadratic data
simchild$GRADE_C2 <- simchild$NEW_GRADE*simchild$NEW_GRADE 

m1d2 <- lmer(CLOSEDAD ~ 1 + NEW_GRADE + GRADE_C2 + 
               (1 + NEW_GRADE + GRADE_C2|id), 
            data = simchild, REML = FALSE,
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m1d2)

anova(m1c, m1d2)

#Plot results
#Get slopes
slopes <- fixef(m1d2)
#Get values of time
GRADE <- 3:10
GRADE2 <- GRADE*GRADE

y <- slopes[1] + slopes[2]*GRADE + slopes[3]*GRADE2

plot(GRADE, y, type = "l")

## Complex Error Structures 

#homoscedastic  errors
m1 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML')
summary(m1)

#let errors vary...

m2 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          weights = varIdent(form = ~1|GRADE_C))
summary(m2)

#Should we use heteroscedastic  errors?
anova(m1,m2)

#Add an AR1 correlation structure
m3 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          corr = corAR1())
summary(m3)

anova(m1,m3)

#Add AR1 and heteroskedasticy. Need to increase iterations! 
cont<-lmeControl(maxIter=500, msMaxIter=50,  niterEM=30)

m4 <- lme(CLOSEDAD ~ 1 + GRADE_C, random = ~ 1 + GRADE_C|id, 
          data=simchild, na.action = 'na.omit', method = 'ML', 
          corr = corAR1(), 
          weights = varIdent(form = ~1|GRADE), 
          control=cont)
summary(m4)
anova(m3,m4)
anova(m2,m4)

## Cross Classified models

library(foreign)

### Cross Classified Models ###

#Data from Hox (2002)

pupcross<-read.dta("https://stats.idre.ucla.edu/stat/stata/examples/mlm_ma_hox/pupcross.dta")

pupcross$pschool <- as.factor(pupcross$pschool)
pupcross$sschool <- as.factor(pupcross$sschool)
pupcross$pXsschool <- pupcross$sschool:pupcross$pschool

summary(pupcross)
head(pupcross)

#"Main effects" model without pXs interaction
m0<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool), 
         data = pupcross, REML=FALSE)
summary(m0)

#Full cross-classified model
m1<-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + 
           (1|pXsschool), data = pupcross, REML=FALSE)
summary(m1)

#ICCs
#Secondary School
.06447/(.03362+.16817 + .06447 + .48201)
#Primary School
.16817/(.03362+.16817 + .06447 + .48201)
#PrimaryXSecondary School
.03362/(.03362+.16817 + .06447 + .48201)

anova(m0,m1)

#Full cross-classified model: alternative code
m1b <-lmer(achiev ~ 1 + (1|sschool) + (1|pschool) + 
             (1|sschool:pschool), data = pupcross, REML=FALSE)
summary(m1b)

# Add level 1 predictors
m1a<-lmer(achiev ~ pupsex + pupses +(1|sschool) + 
            (1|pschool),
          pupcross, REML=FALSE)
summary(m1a)


# Use the SB data set for the following:
# Determine the number of minority students and non minority students total across schools
# Determine the number of students that had to repeat a grade, 0, 1, and 2 times.
# Find the mean and (overall) SD of the  language pretest (langpret) variable
# Fit a model to arithmetic tests (aritpost)
# with if a student repeated a grade (repeatgr), treated as categorical
# and language pretest (langpret) as predictors
# test all fixed and random slopes.
# For the final model compute effect sizes

SB$repeatgr <- as.factor(SB$repeatgr)

table(SB$minority)

table(SB$repeatgr)

library(psych)
describe(SB$langpret)

#Null model
m1h <- lmer(aritpost~ 1 + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m1h)
#ICC
12.50/(12.50+32.28)

#Fixed slopes random intercept
m2h <- lmer(aritpost~ 1 + repeatgr + langpret + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m2h)

m2ha <- lmer(aritpost~ 1 + langpret + (1 |schoolnr), 
            data = SB, 
            REML = FALSE)
anova(m2h, m2ha) #test of repeat grade

#All random slopes random intercept
m3h <- lmer(aritpost~ 1 + repeatgr + langpret + (1 + repeatgr + langpret |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m3h)

#test random variances
ranova(m3h)

#Model with only random slope of repeat
#Check ranova results
m4h <- lmer(aritpost~ 1 + repeatgr + langpret + (1 + repeatgr  |schoolnr), 
            data = SB, 
            REML = FALSE)
summary(m4h)

anova(m4h,m3h)

## Final model includes no random slopes
## get r2 values
library(performance)
r2(m2h)
## Multiple group models
## If we have time! 

mMG <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
           random = list(id=pdBlocked(list(pdSymm(form=~ 0+CONSBOY + GRDBOY_C),
                                           pdSymm(form=~0+CONSGRL + GRDGRL_C)))), 
           data=simchild, na.action = 'na.omit', method = 'ML', 
           weights = varIdent(form = ~1|SEX))
summary(mMG)


#Nested model, are intercept and slope variances equal?
mMG1 <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
            random = ~ 1 + GRADE_C|id, 
            data=simchild, na.action = 'na.omit', method = 'ML', 
            weights = varIdent(form = ~1|SEX))
summary(mMG1)

anova(mMG, mMG1)

#All variances equal?
mMG1a <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
             random = ~ 1 + GRADE_C|id, 
             data=simchild, na.action = 'na.omit', method = 'ML')
summary(mMG1a)
rbind(fixef(mMG1), fixef(mMG1a))

##Compare nested MG with interaction effect

#Interaction model
mInt <- lme(CLOSEMOM ~ SEX + GRADE_C + SEX*GRADE_C, random = ~ 1 + GRADE_C|id, 
            data=simchild, na.action = 'na.omit', method = 'ML')
summary(mInt)
anova(mMG1a, mInt)


## Generalized linear models

## Logistic regression
## Use hsb2 data

hsb$schtyp <- as.factor(hsb$schtyp)

mod1 <- glm(schtyp ~ factor(ses) + math, data = hsb, family = binomial())
summary(mod1)
exp(coef(mod1))

mod1a <- glm(schtyp ~ math, data = hsb, family = binomial())
summary(mod1a)
exp(coef(mod1a))

anova(mod1a, mod1, test = "LRT")

library(performance)
r2(mod1)

r2_nagelkerke(mod1)

hsb$ses <- as.factor(hsb$ses)
mod3 <- glm(schtyp ~ ses * math, data = hsb, family = binomial())
summary(mod3)
exp(coef(mod3))

sim_slopes(mod3, pred = math, mod.x = ses)

library(emmeans)

emmeans(mod1, "ses")
