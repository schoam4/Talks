##############################
### MVM with R             ###
### Summer Stats Camp 2024 ###
### Alexander Schoemann    ###
##############################

####Load packages for today
library(lavaan)
library(semPlot)
library(semTools)
library(psych)

### EFA ###


## Read in Holzinger & Swineford Data 
## Mental ability tests of 7th and 8th graders
## Data from 9 tests
## x1 = visual perception
## x2 = cubes
## x3 = lozenges
## x4 = paragraph completion
## x5 = sentence completion
## x6 = word meeting
## x7 = speeded addition
## x8 = speeded counting of dots
## x9 = speeded discrimination of lines

dat <- read.csv("HS.csv")


#Specify dataset of only variables in analysis
dat2 <- dat[, c("x1", "x2", "x3", "x4", "x5", 
                "x6", "x7", "x8", "x9")]

dat3 <- dat[, paste0("x", 1:9)]


## Factor analysis
## Default is oblique rotation (oblimin) 
# and least squares estimation 

#may need
#install.packages("GPAroation")

fa(dat2, 1)
fa(dat2, 2)
fa(dat2, 3)
fa(dat2, 4)
fa(dat2, 5)

## Fit with ML estimation and a different rotation
fa(dat2, 3, rotate = "geominQ", fm = "ml")

## Use fa.parallel for parallel analysis and scree plot

fa.parallel(dat2, fa = "fa")

## Scree plot
scree(dat2)

## Use vss for VSS, and MAP
vss(dat2)

#only look at 1-6 factors
vss(dat2, n = 6)


# Plots of different criteria
nfactors(dat2)

## Bi-factor rotations

## Bi-factor model with Schmid Leiman transformation
schmid(cor(dat2), nfactors = 3, n.obs = 301)

## Bi-factor model with Jennrich-Bentler rotation
fa(dat2, 4, rotate = "bifactor")

## Examples sorting factor loadings
fa3 <- fa(dat2, 3)
print(fa3, sort=TRUE)
print(fa3, cut=.2)
print(fa3, cut=.2, sort = TRUE)

#Compare two models with anova()
fa4 <- fa(dat2, 4)
anova(fa3, fa4)

#### CFA

################################################################################
## data preparation
################################################################################

## read in example data file
dat <- read.csv('CFA.csv')

## look at dat
summary(dat)
round(cor(dat),3)
round(cov(dat),3)

##Find reliability (alpha) using the psych package

#positive affect
alpha(dat[,c("great", "cheerful", "happy")])

omega(dat[,c("great", "cheerful", "happy")])

#negative affect
alpha(dat[,4:6])

omega(dat[,4:6])

################################################################################
## EFA
################################################################################

##Use the fa function in the psych package.
EFA <- fa(dat, nfactors=2, fm="ml")
EFA


################################################################################
## example  CFA fixed factor method
################################################################################
mod51 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          
          Positive ~~ Negative
					'
fit51 <-  cfa(mod51, data=dat, std.lv=TRUE)

summary(fit51, standardized=TRUE, fit.measures=TRUE)

#Same model with the marker variable
fit51m <-  cfa(mod51, data=dat)

summary(fit51m, standardized=TRUE, fit.measures=TRUE)

#Same model with the marker variable
fit51e <-  cfa(mod51, data=dat, effect.coding = TRUE)

summary(fit51e, standardized=TRUE, fit.measures=TRUE)

#Create a path diagram with semPlot
semPaths(fit51, 'est')

#same diagram but with standardized estimates
semPaths(fit51, 'std')

#Get observed covariance a model implied covariance matrix
lavInspect(fit51, 'sampstat')

#Get model implied covariance matrix
fitted.values(fit51)

#Get fitted residuals: Observed covariances - Model implied covariances
lavInspect(fit51, 'sampstat')$cov-fitted.values(fit51)$cov

#Or use
residuals(fit51)

#We can also get standardized residuals (difference between the correlation matrices)
residuals(fit51, type='cor')

#Network plot of residuals
semCors(fit51, include = "difference")

#Get modification indices
modificationIndices(fit51)

#sort modification indices largest to smallest
modificationIndices(fit51, sort. = TRUE)

# Only return modification indices > 5
modificationIndices(fit51, minimum.value = 5)



################################################################################
## example  CFA marker variable method
################################################################################

fit51m <-  cfa(mod51, data=dat)

summary(fit51m, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example  CFA effects coding method
################################################################################

fit51ec <- cfa(mod51, data=dat, effect.coding = TRUE)

summary(fit51ec, standardized=TRUE, fit.measures=TRUE)


################################################################################
## example compare orthogonal (uncorrelated) constructs
################################################################################
mod53 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy

          Positive ~~ 0*Negative
         '


fit53 <- cfa(mod53, data=dat, std.lv=TRUE)

summary(fit53, standardized=TRUE, fit.measures=TRUE)

semPaths(fit53, 'est')


#compare models
anova(fit51, fit53)
#lavTestLRT is the same test as anova()
lavTestLRT(fit51, fit53)

################################################################################
## example compare perfectly correlated constructs (i.e., one construct)
################################################################################
mod54 <- 'Positive =~ great + cheerful + happy
          Negative =~ sad + down + unhappy
          
          Positive ~~ -1*Negative
         '

fit54 <- cfa(mod54, data=dat, std.lv=TRUE)

summary(fit54, standardized=TRUE, fit.measures=TRUE)


semPaths(fit54, 'est')


#compare models
anova(fit51, fit54)


################################################################################
## example compare one Construct
################################################################################
mod55 <- 'PosNeg =~ great + cheerful + happy + 
                    sad + down + unhappy
          '

fit55 <- cfa(mod55, data=dat, std.lv=TRUE)

summary(fit55, standardized=TRUE, fit.measures=TRUE)


semPaths(fit55, 'est')


#compare models
anova(fit51, fit55)

## Robust estimators 
fit51r <- cfa(mod51, data=dat, std.lv=TRUE,
              estimator = "mlr")
summary(fit51r, fit.measures = TRUE)

fit54r <- cfa(mod54, data=dat, std.lv=TRUE,
              estimator = "mlr")
lavTestLRT(fit51r, fit54r)

## Fit indices
fitmeasures(fit51)
moreFitIndices(fit51)

## determine if models are nested
net(fit51, fit53, fit54)

################################################################################
## data preparation
################################################################################

#Read data in 
dat <- read.csv('MG.csv')

dat$Grade <- as.factor(dat$Grade)

summary(dat)
describe(dat)
describeBy(dat, dat$Grade)

################################################################################
## Examples  -- Separate single-Group Models
################################################################################

##Only for example, not needed when fitting
##multiple group model

mod1 <- 'Positive =~ P1 + P2 + P3
         Negative =~ N1 + N2 + N3 

         Positive ~~ Negative
          '


## Fit model to 7th Grade

fitg1 <- cfa(mod1, data=dat[dat$Grade == '7th',],
             std.lv=TRUE)

summary(fitg1, standardized=TRUE, fit.measures=TRUE)

## Same model to 8th Grade

fitg2 <- cfa(mod1, data=dat[dat$Grade == '8th',], std.lv=TRUE)

summary(fitg2, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example -- Configural Invariance Model (Form)
################################################################################

## note, Both groups fit simultaneously, and there are 2 sets of parameter 
## estimates (identical to above), but there is a single set of fit measures

fit1 <- cfa(mod1, data=dat, std.lv=TRUE, 
            group = "Grade")

summary(fit1, standardized=TRUE, fit.measures=TRUE)

semPaths(fit1,'std', panelGroups=TRUE)


## Chi-square for the configural model is the sum of the individual models

fitmeasures(fitg1)["chisq"] + fitmeasures(fitg2)["chisq"]

fitmeasures(fit1)["chisq"]

modindices(fit1, minimum.value = 5)

resid(fit1)

################################################################################
## Examples -- Weak Invariance Models (Loadings)
################################################################################

## Fixed-Factor method of identification
## lavaan automatically frees latent 
## variances in second and third groups

fitWeak1 <- cfa(mod1, data=dat,
                std.lv=TRUE, group = "Grade", 
                group.equal=c("loadings"))
summary(fitWeak1, standardized = TRUE, fit.measures = TRUE)

#Compare configural and weak invariance models
#Non significant nested model test means weal invariance holds
anova(fit1, fitWeak1)

summary(compareFit(config = fit1, weak = fitWeak1))



################################################################################
## Examples -- Strong Invariance Models (Intercepts)
################################################################################


fitStrong1 <- cfa(mod1, data=dat, std.lv=TRUE, 
                  group = "Grade", 
                  group.equal=c("loadings","intercepts"))

summary(fitStrong1, standardized=TRUE, fit.measures=TRUE)


#Compare weak and Strong invariance models
#Non significant nested model test means strong invariance holds
anova(fitWeak1, fitStrong1)

summary(compareFit(config = fit1, weak = fitWeak1, 
           strong = fitStrong1))

## Use univariate Score test (like modification indices) to see
## which equality constraints should be relaxed (if any)

lavTestScore(fitStrong1, cumulative = TRUE)

parameterestimates(fitStrong1)

#Example partial invariance
fitStrong1m <- cfa(mod1, data=dat, std.lv=TRUE, 
                   group = "Grade", 
                   group.equal=c("loadings","intercepts"),
                   group.partial = "P2~1")

summary(fitStrong1m, standardized=TRUE, fit.measures=TRUE)

anova(fitWeak1, fitStrong1m)
anova(fitStrong1, fitStrong1m)

mod1p <- 'Positive =~ P1 + P2 + P3
         Negative =~ N1 + N2 + N3 

         Positive ~~ Negative
         P2 ~ c(a1, a2)*1
          '
fitStrong1m2 <- cfa(mod1p, data=dat, std.lv=TRUE, 
                   group = "Grade", 
                   group.equal=c("loadings","intercepts"))

summary(fitStrong1m2, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example -- measEQ.syntax function
################################################################################

#Here's something cool


mod <- 'Positive =~ P1 + P2 + P3
         Negative =~ N1 + N2 + N3 
          '

confMod <-measEq.syntax(mod, data=dat, 
                        group = "Grade", 
                        return.fit = TRUE )
summary(confMod)

weakMod <-measEq.syntax(mod, data=dat, 
                        group = "Grade", return.fit = TRUE, 
                        group.equal = "loadings" )
summary(weakMod)

strongMod <-measEq.syntax(mod, data=dat, 
                          group = "Grade", return.fit = TRUE, 
                          group.equal = c("loadings", "intercepts") )
summary(strongMod)

summary(compareFit(configural = confMod, weak = weakMod, strong = strongMod))

## See the syntax being created
exSyntax <- measEq.syntax(mod, data=dat, 
              group = "Grade", 
              group.equal = c("loadings", "intercepts") )

cat(as.character(exSyntax))

################################################################################
## Example -- Permutation tests
################################################################################

## fit indices of interest for multiparameter omnibus test
myAFIs <- c("chisq","cfi","rmsea","aic")
moreAFIs <- c("gammaHat","adjGammaHat")

## Use only 20 permutations for a demo.  In practice,
## use > 1000 to reduce sampling variability of estimated p values

## test configural invariance
set.seed(12345)
out.config <- permuteMeasEq(nPermute = 20, 
                            con = confMod)
out.config


## test weak equivalence
set.seed(12345) # same permutations
out.metric <- permuteMeasEq(nPermute = 20, 
                            uncon = confMod, 
                            con = weakMod,
                            param = "loadings", 
                            AFIs = myAFIs,
                            moreAFIs = moreAFIs)
summary(out.metric, nd = 4)

## test strong equivalence
set.seed(12345) # same permutations
out.scalar <- permuteMeasEq(nPermute = 20, uncon = weakMod, con = strongMod,
                            param = "intercepts", AFIs = myAFIs,
                            moreAFIs = moreAFIs)
summary(out.scalar)



################################################################################
## Example -- Mean invariance
################################################################################

## fixed factor example
fitMean1 <- cfa(mod1, data=dat, std.lv=TRUE, 
                group = "Grade", 
                group.equal=c("loadings","intercepts", 
                              "means"))

summary(fitMean1, standardized=TRUE, fit.measures=TRUE)

#Test of mean invariance
#Means do not differ across groups
anova(fitStrong1, fitMean1)

## effect coding example
fitStrong2 <- cfa(mod1, data=dat, effect.coding=TRUE, 
                group = "Grade", 
                group.equal=c("loadings","intercepts" 
                              ))

summary(fitStrong2, standardized=TRUE, fit.measures=TRUE)

fitMean2 <- cfa(mod1, data=dat, effect.coding=TRUE, 
                  group = "Grade", 
                  group.equal=c("loadings","intercepts", 
                  "means"))

summary(fitMean2, standardized=TRUE, fit.measures=TRUE)

################################################################################
## Example -- Variance/covariance invariance
################################################################################

fitVCOV1 <- cfa(mod1, data=dat, std.lv=TRUE, 
                group = "Grade", 
                group.equal=c("loadings","intercepts", 
                              "lv.variances", "lv.covariances"))

summary(fitVCOV1, standardized=TRUE, fit.measures=TRUE)

#Test of variance/covariance invariance
#Variances or covariances differ across groups
anova(fitStrong1, fitVCOV1)

################################################################################
## Example -- Variance invariance
################################################################################

fitVar1 <- cfa(mod1, data=dat, std.lv=TRUE, 
               group = "Grade", 
               group.equal=c("loadings","intercepts", 
                             "lv.variances"))

summary(fitVar1, standardized=TRUE, fit.measures=TRUE)

#Test of variance invariance
#Variances do not differ across groups
#But for teaching purposes let's pretend they did...
anova(fitStrong1, fitVar1)

#Test latent covariances
anova(fitVar1, fitVCOV1)


################################################################################
## Example -- Phantom Variables
################################################################################


modPh1 <- 'Positive =~ P1 + P2 + P3
Negative =~ N1 + N2 + N3

#Fix loading to 1 in first group for scale setting
PhPos =~ c(1, NA)*Positive
PhNeg =~ c(1, NA)*Negative

Positive ~~ c(0, 0)*Positive
Negative ~~ c(0, 0)*Negative
PhPos ~~ c(1, 1)*PhPos
PhNeg ~~ c(1, 1)*PhNeg

Positive ~~ c(0, 0)*Negative
PhPos ~~ PhNeg
PhPos ~~ c(0, 0)*Negative
PhNeg ~~ c(0, 0)*Positive

Positive ~ c(0,NA)*1
Negative ~ c(0,NA)*1
PhPos ~ c(0,0)*1
PhNeg ~ c(0,0)*1

'

fitPh1 <- cfa(modPh1, data=dat, meanstructure=TRUE, 
              group = "Grade", 
              std.lv=TRUE, auto.fix.first=FALSE, 
              group.equal=c("loadings","intercepts"),
              group.partial = c('PhPos =~ Positive',
                                'PhNeg =~ Negative'))


summary(fitPh1, standardized=TRUE, fit.measures=TRUE)


#Equate latent correlations
fitPhCOR1 <- cfa(modPh1, data=dat, meanstructure=TRUE, 
                 group = "Grade", 
                 std.lv=TRUE, auto.fix.first=FALSE, 
                 group.equal=c("loadings","intercepts" , "lv.covariances"),
                 group.partial = c('PhPos =~ Positive','PhNeg =~ Negative'))


summary(fitPhCOR1, standardized=TRUE, fit.measures=TRUE)


#Test of equality of latent correlations
#Correlation between positive and negative affect differs across groups
anova(fitPh1, fitPhCOR1)

##Effect sizes

#Cohen's d from lsr package
#install.packages('lsr')
library(lsr)

dat$positive <- (dat$P1 + dat$P2 + dat$P3)/3

cohensD(positive~Grade, data=dat)

#latent d

(0- (-.162))/sqrt(((380*1+379*1.223)/(380+379)))

