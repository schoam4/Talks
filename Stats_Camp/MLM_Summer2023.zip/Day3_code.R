##############################
### MLM                    ###
### Summer Stats Camp 2022 ###
### Alexander Schoemann    ###
##############################

### Longitudinal Data ###

library(lme4)
library(lmerTest)
library(nlme)

##Read in simchild data

simchild <- read.csv('simchild.csv', 
                      na.string = '-999999')
summary(simchild)
head(simchild)

#Fit model with fixed intercept, fixed slope. 
#Need to do this with regression
m1 <- lm(CLOSEDAD ~ 1 + GRADE_C, data = simchild)
summary(m1)

#Null model
m0a <- lmer(CLOSEDAD ~ 1 +  (1|id), data = simchild, 
            REML = FALSE)
summary(m0a)

#ICC
10.09/(10.09+7.85)

#Fit model with random intercept, fixed slope
m1a <- lmer(CLOSEDAD ~ 1 + GRADE_C + (1|id), 
            data = simchild, 
            REML = FALSE)
summary(m1a)

#Fit model with fixed intercept, random slope
m1b <- lmer(CLOSEDAD ~ 1 + GRADE_C + (0 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1b)

#Fit model with random intercept, random slope
m1c <- lmer(CLOSEDAD ~ 1 + GRADE_C + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1c, correlation = FALSE)

#Random intercept, random slope model with uncentered data
m1d <- lmer(CLOSEDAD ~ 1 + GRADE + (1 + GRADE|id), 
            data = simchild, REML = FALSE)
summary(m1d)

#Random intercept, random slope model with uncentered data
simchild$GRADE_6 <- simchild$GRADE - 6
m1d1 <- lmer(CLOSEDAD ~ 1 + GRADE_6 + (1 + GRADE_6|id), 
            data = simchild, REML = FALSE)
summary(m1d1)

#Compare models
anova(m1a,m1c)
anova(m1b, m1c)

#profile CI for random intercepts and slopes
#this might take a while...
confint(m1c, method="profile")

confint(m1c, method="profile", level = .90)

#Random intercept, random slope model with rescaled time

simchild$dec <- simchild$GRADE_C/10

m1e <- lmer(CLOSEDAD ~ 1 + dec + (1 + dec|id), 
            data = simchild, REML = FALSE)
summary(m1e)

simchild$mon <- simchild$GRADE_C*12

m1e1 <- lmer(CLOSEDAD ~ 1 + mon + (1 + mon|id), 
            data = simchild, REML = FALSE)
summary(m1e1)

##The aperature for this model Tau_0,1/Tau_1,1

#Compute covariance (only get correlation in lmer)
tauCor <- matrix(c(1,.47, .47, 1), byrow=TRUE, nrow=2)
library(lavaan)
tauCov <- cor2cov(tauCor, c(2.5775, 0.3904))

#apature
-tauCov[1,2]/tauCov[2,2]

#Covariance of intercept and slope
.47*2.5775*.3904
#Apature
-(0.4729403/0.1524)

#Create new time variable
simchild$NEW_GRADE <- simchild$GRADE_C - (-tauCov[1,2]/tauCov[2,2])

#Fit model with random intercept, random slope
m1cAP <- lmer(CLOSEDAD ~ 1 + NEW_GRADE + (1 + NEW_GRADE|id), 
              data = simchild, REML = FALSE)
summary(m1cAP)

confint(m1cAP, method="profile", level = .90)

##Does gender predict growth? Use CONFLMOM now
## Boys = 1, girls = 0

##Predicting intercept only
m1d0 <- lmer(CONFLMOM ~ 1 + GRADE_C + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1d0)

##Predicting intercept only
m1d <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1d)


##Predicting intercept and slope
m1f <- lmer(CONFLMOM ~ 1 + GRADE_C + SEX + GRADE_C*SEX + 
              (1 + GRADE_C|id),
            data = simchild, REML = FALSE)
summary(m1f)

#Probe interaction between time and SEX
library(interactions)
sim_slopes(m1f, pred = GRADE_C, modx = SEX)
interact_plot(m1f, pred = GRADE_C, modx = SEX)

sim_slopes(m1f, pred = SEX, modx = GRADE_C)


#Time varying covariate. Change in CLOSEDAD controlling for CLOSEMOM
#Time varying covariate should be centered so the intercept is interpretable
m1h <- lmer(CLOSEDAD ~ 1 + GRADE_C + CLOSEMOM + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1h)

#Test if the slope of CLOSEMOM differs across individuals
m1h1 <- lmer(CLOSEDAD ~ 1 + GRADE_C * CLOSEMOM + 
              (1 + GRADE_C + CLOSEMOM|id), 
            data = simchild, REML = FALSE)
summary(m1h1)
anova(m1h, m1h1)

## Center CLOSEMOM
simchild$CLOSEMOM_C <- simchild$CLOSEMOM-36.97

m1hc <- lmer(CLOSEDAD ~ 1 + GRADE_C + CLOSEMOM_C + 
              (1 + GRADE_C|id), 
            data = simchild, REML = FALSE)
summary(m1hc)

m1i <- lmer(CLOSEDAD ~ 1 + GRADE_C*SEX + CLOSEMOM_C + 
               (1 + GRADE_C|id), 
             data = simchild, REML = FALSE)
summary(m1i)



m1hcI <- lmer(CLOSEDAD ~ 1 + GRADE_C * CLOSEMOM_C + 
               (1 + GRADE_C|id), 
             data = simchild, REML = FALSE)
summary(m1hcI)

#Anti-read example
anti <- read.csv('antiread.csv')
summary(anti)

#Using Wave as the predictor
m2w <- lmer(ANTI ~ 1 + WAVE_C + (1 + WAVE_C|id), 
            data = anti, REML = FALSE)
summary(m2w)

#Using Age as the predictor
m2a <- lmer(ANTI ~ 1 + AGE_C + (1 + AGE_C|id), 
            data = anti, REML = FALSE)
summary(m2a)

# Create cohort variable
head(anti)

cohort <- anti[anti$WAVE == 1, c("id","AGE")]
anti <- merge(anti, cohort, by = "id")

head(anti)
anti$COHORT <- as.factor(anti$AGE.y)
summary(anti)

## Test cohort effect
#Using Age as the predictor
m2ac <- lmer(ANTI ~ 1 + AGE_C*COHORT + (1 + AGE_C|id), 
            data = anti, REML = FALSE)
summary(m2ac)
anova(m2a, m2ac)

## Change baseline category to 8 year olds
m2ac <- lmer(ANTI ~ 1 + AGE_C*C(COHORT, base = 5) + (1 + AGE_C|id), 
             data = anti, REML = FALSE)
summary(m2ac)
anova(m2a, m2ac)

#Quadratic effect of Age
anti$AGE_C2 <- anti$AGE_C*anti$AGE_C 
m2aq <- lmer(ANTI ~ 1 + AGE_C + AGE_C2 + 
               (1 + AGE_C+ AGE_C2|id), data = anti, 
             REML = FALSE, 
             control = lmerControl(optimizer="Nelder_Mead"))
summary(m2aq)

confint(m2aq, method="profile", level = .90)


anova(m2a, m2aq)

#Random intercept, random slope model with quadratic data
simchild$GRADE_C2 <- simchild$GRADE_C*simchild$GRADE_C 
m1d2 <- lmer(CLOSEDAD ~ 1 + GRADE_C + GRADE_C2 + 
               (1 + GRADE_C + GRADE_C2|id), 
            data = simchild, REML = FALSE,
            control = lmerControl(optimizer="Nelder_Mead"))
summary(m1d2)

anova(m1c, m1d2)

#Plot results
#Get slopes
slopes <- fixef(m1d2)
#Get values of time
GRADE <- 0:5
GRADE2 <- GRADE*GRADE

y <- slopes[1] + slopes[2]*GRADE + slopes[3]*GRADE2

plot(GRADE, y, type = "l")

## Use coef to get regression lines for each person:
reff <- coef(m1d2)[[1]]
dim(reff)

ys <- NULL
for(i in 1:dim(reff)[1]){
ys1 <- reff[i,1] + reff[i,2]*GRADE + reff[i,3]*GRADE2 
ys <-rbind(ys,ys1)
}
ys

#Plot separate regression lines for all participants
plot(GRADE, y, ylab = "CLOSEDAD", type = 'n',
     ylim = c(25,40))


for(i in 1:dim(reff)[1]){
  lines(GRADE, ys[i,], col = "grey")
}

lines(GRADE, y, ylab = "CLOSEDAD", lwd = 2, col = "red")


#Spline example using STARS data
STARS <- read.csv('STARS.csv', na.string = '-999999')
summary(STARS)

#Linear-Linear Spline
mSPL <- lmer(SBPSPCH ~ 1 + PHASE1L + PHASE2L + 
               (1 + PHASE1L + PHASE2L|USERID), 
             data = STARS, REML = FALSE)
summary(mSPL)

#Quadradic-Linear Spline
mSPQ <- lmer(SBPSPCH ~ 1 + PHASE1L+ PHASE1Q + PHASE2L + 
               (1 + PHASE1L+ PHASE1Q + PHASE2L|USERID), 
             data = STARS, REML = FALSE, 
             control = lmerControl(optimizer="Nelder_Mead"))
summary(mSPQ)
anova(mSPL, mSPQ)

#Linear slope
mL <- lmer(SBPSPCH ~ 1 + TIME + (1 + TIME|USERID), 
             data = STARS, REML = FALSE)
summary(mL)

#Compare to see if spline is reasonable
anova(mSPL, mL)

## Complex Error Structures 

#homoscedastic  errors
m1 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML')
summary(m1)

#let errors vary...

m2 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          weights = varIdent(form = ~1|GRADE_C))
summary(m2)


#Should we use heteroscedastic  errors?
anova(m1,m2)

#Add an AR1 correlation structure
m3 <- lme(CLOSEDAD ~ 1 + GRADE_C, 
          random = ~ 1 + GRADE_C|id, data=simchild, 
          na.action = 'na.omit', method = 'ML', 
          corr = corAR1())
summary(m3)

anova(m1,m3)

#Add AR1 and heteroskedasticy. Need to increase iterations! 
cont<-lmeControl(maxIter=500, msMaxIter=50,  niterEM=30)

m4 <- lme(CLOSEDAD ~ 1 + GRADE_C, random = ~ 1 + GRADE_C|id, 
          data=simchild, na.action = 'na.omit', method = 'ML', 
          corr = corAR1(), 
          weights = varIdent(form = ~1|GRADE), 
          control=cont)
summary(m4)
anova(m3,m4)
anova(m2,m4)

#Anti-social heteroskdastic errors
m2a <- lme(ANTI ~ 1 + AGE_C, random = ~1 + AGE_C|id, 
            data = anti, na.action = 'na.omit', method = 'ML',
           weights = varIdent(form = ~1|AGE_C))
summary(m2a)

## Multiple group models

mMG <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
           random = list(id=pdBlocked(list(pdSymm(form=~ 0+CONSBOY + GRDBOY_C),
                                           pdSymm(form=~0+CONSGRL + GRDGRL_C)))), 
           data=simchild, na.action = 'na.omit', method = 'ML', 
           weights = varIdent(form = ~1|SEX))
summary(mMG)


#Nested model, are intercept and slope variances equal?
mMG1 <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
            random = ~ 1 + GRADE_C|id, 
            data=simchild, na.action = 'na.omit', method = 'ML', 
            weights = varIdent(form = ~1|SEX))
summary(mMG1)

anova(mMG, mMG1)

#All variances equal?
mMG1a <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
             random = ~ 1 + GRADE_C|id, 
             data=simchild, na.action = 'na.omit', method = 'ML')
summary(mMG1a)
rbind(fixef(mMG1), fixef(mMG1a))

#Hetergenous variance across time
cont<-lmeControl(maxIter=500, msMaxIter=100,  niterEM=30)

simchild$SEXGRADE <- as.factor(simchild$SEX):as.factor(simchild$GRADE)
mMGh <- lme(CLOSEMOM ~ 0 + CONSBOY + CONSGRL + GRDBOY_C + GRDGRL_C, 
           random = list(id=pdBlocked(list(pdSymm(form=~ 0+CONSBOY + GRDBOY_C),
                                           pdSymm(form=~0+CONSGRL + GRDGRL_C)))), 
           data=simchild, na.action = 'na.omit', method = 'ML', 
           weights = varIdent(form = ~1|SEXGRADE),
           control=cont)
summary(mMGh)

##Compare nested MG with interaction effect

#Interaction model
mInt <- lme(CLOSEMOM ~ SEX + GRADE_C + SEX*GRADE_C, random = ~ 1 + GRADE_C|id, 
            data=simchild, na.action = 'na.omit', method = 'ML')
summary(mInt)
anova(mMG1a, mInt)

