################################################################################
## Intro to MLM
## May 27, 2021
## Alexander M. Schoemann
################################################################################

#Use the lme4 package for MLM
library(lme4)
#Use the lmerTest package to get p-values
library(lmerTest)

##Read in data
SB <- read.csv('SB.csv')

##Look at data
summary(SB)
head(SB)
tail(SB)


##Null model
m6 <- lmer(langpost ~ 1 + (1 |schoolnr), data = SB, 
           REML = FALSE)
summary(m6)

#compute ICC
19.43/(64.57+19.43)

#fixed L1 predictor
m7 <- lmer(langpost ~ 1 + iq_verb + (1 |schoolnr), data = SB, 
           REML = FALSE)
summary(m7)

#random L1 predictor
m8 <- lmer(langpost ~ 1 + iq_verb + (1 + iq_verb|schoolnr), 
           data = SB, REML = FALSE)
summary(m8)

#Compare model with fixed and random slopes

anova(m7, m8)

#fixed L2 predictor
m9 <- lmer(langpost ~ 1 + percmino + (1 |schoolnr), 
           data = SB, REML = FALSE)
summary(m9)

# Level 1 and level 2 predictors

m10 <- lmer(langpost  ~1 + iq_verb + percmino + (1 + iq_verb |schoolnr), 
           data = SB, REML = FALSE)
summary(m10)

# Interaction of  Level 1 and level 2 predictors

m11 <- lmer(langpost ~ 1 + iq_verb * percmino + (1 + iq_verb|schoolnr), 
            data = SB, REML = FALSE)
summary(m11)

# Level 1 and level 2 predictors with categorical predictor

SB$denomina <- as.factor(SB$denomina)

m12 <- lmer(langpost  ~1 + iq_verb + percmino + denomina +  (1 + iq_verb |schoolnr), 
            data = SB, REML = FALSE)
summary(m12)

anova(m10, m12)
