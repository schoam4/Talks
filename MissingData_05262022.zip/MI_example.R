##Multiple imputation
##May 2022 ECU
##Alexander M. Schoemann


## Example Regression using nhanes data

dat <- read.csv("nhanes.csv")

## Create dummy codes

dat$age2 <- as.numeric(dat$age == 2)
dat$age3 <- as.numeric(dat$age == 3)

# linear regression model with listwise deletion
mod1 <- lm(bmi~ age2 + age3 + hyp + chl, data =dat)
summary(mod1)

##Use the mice package for MI

#Get rid of the age variable since it will cause problems

dat2 <- dat[,c("age2", "age3", "bmi", "hyp", "chl")]

library(mice)

imps <- mice(dat2, m = 20 )

#Imputation diagnostics

#Plot of MCMC chains
plot(imps)

#Plot observed and imputed data with a strip plot
#and box plots
stripplot(imps)

bwplot(imps)

##Looks like we need to impute with more iterations
imps <- mice(dat2, m = 20, maxit =  20)

#Fit model using the with command

impM <- with(imps, lm(bmi~ age2 + age3 + hyp + chl))

#Pool results with pool, use summary to see more results

results <- pool(impM)
results
summary(results)

pool.r.squared(impM)

#Compare a model without age
impM2 <- with(imps, lm(bmi~ hyp + chl))

D1(impM, impM2)

#Get overall test of a model
#Fit a model with only an intercept
impM3 <- with(imps, lm(bmi~ 1))

#Compare intercept model to model of interest
D1(impM, impM3)
D2(impM, impM3)


md.pattern(dat2)

## Pooling ANOVA from SPSS using miceadds

library(miceadds)

#micombine.F takes F statistics and combines them
Fvalues <- c(22.458, 14.878, 9.563, 11.015, 7.332)
#df1 is df for the numerator
micombine.F(Fvalues, df1 = 4)

## Standardize slopes

## Convert to data list
impsD <- mids2datlist(imps)
#Standardized variables
impsS <- scale_datlist(impsD, orig_var = c("bmi", "hyp", "chl"),
                       trafo_var = c("Sbmi", "Shyp", "Schl"))
#convert back to mids to fit models
impsS <- datlist2mids(impsS)
#Fit model with standardized variables
impM2S <- with(impsS, lm(Sbmi~ Shyp + Schl))
#Pool results, only look at slopes (ignore the intercept too)
resultsS <- pool(impM2S)
summary(resultsS)
