Instructions for using the shiny app "Monte Carlo Power Analysis for Indirect Effects"
Aaron Boulton & Alexander M. Schoemann

Unzip all files to a location on your computer you can easily access. When unzipped all files should be in a folder called "mc_power" In the mc_power folder open the run_app.R file with R or RStudio (we recommend RStudio). 

Set the working directory in R to the file location (easy in RStudio!) and run the included code in run_app.R. If the shiny and MASS packages are not installed on your computer, install them before running the app.