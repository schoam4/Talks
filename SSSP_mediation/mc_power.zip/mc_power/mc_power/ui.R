# ui.R

# This file contains code for creating the user interface. 
# Note correlations are numbered based on vars (X=1, M=2, Y=3)

shinyUI(fluidPage(theme = 'spacelab.css',
  titlePanel("Monte Carlo Power Analysis for Indirect Effects"),
  tags$p(tags$p("Written by Aaron Boulton & Alexander M. Schoemann"), tags$a(href="mailto:schoemanna@ecu.edu", "Contact")),
  fluidRow(
    column(4,
      wellPanel(
        h4("Calculate Power"),
        
        helpText("Choose a Mediation Model:"),
        selectInput(inputId = "model", label = NULL,
                    choices = list("Choose" = "",
                                   "Single Mediator" = 1),
                                   #"Two Mediators" = 2), 
                    selected = 1), 
        
        helpText("Choose an Input Method:"),
        selectInput(inputId = "method", label = NULL,
                    choices = list("Choose" = "",
                                   "Correlations" = 1,
                                   "Variance Explained" = 2), 
                    selected = 1), 
        
        helpText("Sample Size (N)"),
        numericInput(inputId = "N",
                     label = NULL,
                     value = 200),
        
        helpText("Number of Replications for MC Power Analysis"),
        numericInput(inputId = "powReps",
                     label = NULL,
                     value = 1000),
        
        helpText("Number of Draws used to Calculate MC Confidence Intervals"),
        numericInput(inputId = "mcmcReps",
                     label = NULL,
                     value = 20000),
        
        helpText("Confidence Level % (e.g., 95)"),
        numericInput(inputId = "conf",
                     label = NULL,
                     value = 95),
        
        helpText("Random number seed"),
        numericInput(inputId = "seed",
                     label = NULL,
                     value = 1738),        
        
        actionButton("action", label = "Calculate Power"),
        textOutput("help")
      )
    ),
    column(5,
      imageOutput("model")         
    ),
    column(3,
      wellPanel(
        uiOutput("input_options"),         
        wellPanel(textOutput("power"))
      )
    )
  )
)
)