#####################################################
## Monte Carlo Power Analysis for Indirect Effects ##
## Aaron Boulton & Alexander M .Schoemann             ##
## October 22, 2015                                ##
#####################################################

## Both "shiny" and "MASS" packages need to be installed. MASS is loaded
## automatically by the App

## R's working directory must be set to the same location as this file.
## The working directory can be changed with the setwd() command or 
## in RStudio use the "Session" menu, in regular R use the 


## If shiny and MASS are not installed on your computer use the two lines below
## to install them.

# install.packages("shiny")
# install.packages("MASS")

## Run the next two lines to open the app and interact with it
library(shiny)

runApp("../mc_power")
