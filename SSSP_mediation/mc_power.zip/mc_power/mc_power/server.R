# server.R

# This file contains code that runs R calculations on a web server,
# computer, etc., and renders results for display as determined in the ui.R
# file.

library(MASS)


shinyServer(
  function(input, output) {
    calc_power <- eventReactive(input$action, {
      
      # User-entered values, captured when button is pressed
      method <- input$method
      N <- input$N
      mcmcReps <- input$mcmcReps
      powReps <- input$powReps
      conf <- input$conf
      cor12 <- input$cor12
      cor13 <- input$cor13
      cor23 <- input$cor23
      varX <- input$varX
      varM <- input$varM
      varY <- input$varY
      seed <- input$seed
      
      r2a <- input$r2a
      r2b <- input$r2b
      r2cp <- input$r2cp
      varX <- input$varX
      varM <- input$varM
      varY <- input$varY
      
      set.seed(seed)
      #-----------------------------------------------------------------------# 
      # The code below runs a Monte Carlo Power Analysis Simulation for a
      # simple mediation model fit via 2 regression equations. Input for this
      # approach includes R^2 values of the consituent effects (a, b, c') and
      # desired variances for the X, M, and Y variables. See Thoemmes,
      # MacKinnon, and Reiser (2010), Appendix A for details.
      
      # The endpoint for each iteration is whether the XX% Monte Carlo-based
      # confidence interval contains 0. The results of each iteration are
      # stored in a logical vector "pow", and estimated power is calculated as
      # the number of replications in which the confidence interval does NOT
      # include zero (i.e., significant) divided by the 
      
      # Note that because this approach is regression, standard errors are used
      # instead of the full asymptotic covariance matrix, which could be used
      # via path analysis/SEM.
      #-----------------------------------------------------------------------#
      
      if(method == 1){
     # Create correlation matrix
      corMat <- diag(3)
      corMat[2,1] <- cor12
      corMat[1,2] <- cor12
      corMat[3,1] <- cor13
      corMat[1,3] <- cor13
      corMat[2,3] <- cor23
      corMat[3,2] <- cor23
    
      # Get diagonal matrix of SDs
      SDs <- diag(sqrt(c(varX, varM, varY)))
            
      # Convert to covariance matrix
      
      covMat <- SDs%*%corMat%*%SDs
      
      # Start power simulation

      # Use an apply statement instead of a loop
      
      #create function for 1 rep
      
      powRep <- function(seed = 1234, Ns = N, covMatp = covMat){
        set.seed(seed)
        require(MASS)
        
        dat <- mvrnorm(Ns, mu = c(0,0,0), Sigma = covMatp)
        # Run regressions
        m1 <- lm(dat[,2] ~ dat[,1])
        m2 <- lm(dat[,3] ~ dat[,2] + dat[,1])
        
        # Output parameter estimates and standard errors
        pest <- c(coef(m1)[2], coef(m2)[2])
        covmat <- diag(c((diag(vcov(m1)))[2],
                         (diag(vcov(m2)))[2]))
        
        # Simulate draws of a, b from multivariate normal distribution
        mcmc <- mvrnorm(mcmcReps, pest, covmat, empirical = FALSE)
        ab <- mcmc[, 1] * mcmc[, 2]
        
        # Calculate confidence intervals
        low <- (1 - (conf / 100)) / 2
        upp <- ((1 - conf / 100) / 2) + (conf / 100)
        LL <- quantile(ab, low)
        UL <- quantile(ab, upp)
        
        # Is rep significant?
        LL*UL > 0
  
      }
      
      pow <- lapply(sample(1:50000, powReps), powRep)
      

      sum(unlist(pow)) / powReps
      }
      
      else if(method == 2){
    # Calculate a path
    var_eMp <- varM - r2a # residual variance of M
    ap <- sqrt((varM - var_eMp) / varX) # a path
    
    # Calculate b and cp path
    bp <- sqrt(r2b)
    cpp <- sqrt(r2cp / varX)
    
    # Calculate var_eY
    covXM <- ap * varX
    var_eYp <- varY - (cpp ^ 2 * varX) - (bp ^ 2 * varM) - (2 * bp * cpp * covXM)
    
    # Start power simulation
    # pow <- logical()
    # Use an apply statement instead of a loop
    
    #create function for 1 rep
    
    powRep <- function(seed = 1234, Ns = N, a = ap, b = bp, cp = cpp, varXs = varX, 
                       var_eM = var_eMp, var_eY = var_eYp){
      set.seed(seed)
      
      X <- rnorm(Ns, 0, sqrt(varXs))
      M <- a * X + rnorm(Ns, 0, sqrt(var_eM)) 
      Y <- b * M + cp * X + rnorm(Ns, 0, sqrt(var_eY))
      # Run regressions
      m1 <- lm(M ~ X)
      m2 <- lm(Y ~ M + X)
      
      
      # Simulate draws of a, b from multivariate normal distribution
      a <- rnorm(mcmcReps, coef(m1)[2], sqrt(vcov(m1)[2,2]))
      b <- rnorm(mcmcReps, coef(m2)[2], sqrt(vcov(m2)[2,2]))
      ab <- a*b
      # Calculate confidence intervals
      low <- (1 - (conf / 100)) / 2
      upp <- ((1 - conf / 100) / 2) + (conf / 100)
      LL <- quantile(ab, low)
      UL <- quantile(ab, upp)
      
      # Is rep significant?
      LL*UL > 0
      
    }
    
    pow <- lapply(sample(1:50000, powReps), powRep)
    
    sum(unlist(pow)) / powReps
  }    
  
    })
    
    # Render new power estimate
    output$power <- renderText({ 
      paste("The estimated power for detecting ab != 0 is", calc_power())
    })
    #fn <- c("one_med_example.png", "two_med_example.png")

    # Render Image of Mediation Model 
    output$model <- renderImage({
      filename <- normalizePath(file.path(paste0('./images/', 'image', input$model, '.png'))) # Note: This can be reactive
      # Return a list containing the filename and alt text
      list(src = filename,
           alt = paste("Three-variable mediation model"),
           height = 375, width = 400)
      }, deleteFile = FALSE)
    output$help <- renderText({
        input$method
      })

      # Render UI
      output$input_options <- renderUI({
        if (input$method == 1) {
          list(
            h4("Input Options"),
            helpText("Correlation between", em("X"), "and", em("M")),
            numericInput(inputId = "cor12",
                         label = NULL,
                         value = .60),
            
            helpText("Correlation between", em("X"), "and", em("Y")),
            numericInput(inputId = "cor13",
                         label = NULL,
                         value = .20),
            
            helpText("Correlation between", em("M"), "and", em("Y")),
            numericInput(inputId = "cor23",
                         label = NULL,
                         value = .60),
            
            helpText("Variance of X variable"),
            numericInput(inputId = "varX",
                         label = NULL,
                         value = 1.0),
            
            helpText("Variance of M variable"),
            numericInput(inputId = "varM",
                         label = NULL,
                         value = 1.0),
            
            helpText("Variance of Y variable"),
            numericInput(inputId = "varY",
                         label = NULL,
                         value = 1.0)
          )
        } else if (input$method == 2) {
          list(
            h4("Input Options"),
            helpText("R-squared for ", em("a"), "Path"),
            numericInput(inputId = "r2a",
                         label = NULL,
                         value = .13),
            
            helpText("R-squared for ", em("b"), "Path"),
            numericInput(inputId = "r2b",
                         label = NULL,
                         value = .26),
            
            helpText("R-squared for ", em("c'"), "Path"),
            numericInput(inputId = "r2cp",
                         label = NULL,
                         value = .02),
            
            helpText("Variance of X variable"),
            numericInput(inputId = "varX",
                         label = NULL,
                         value = 1.0),
            
            helpText("Variance of M variable"),
            numericInput(inputId = "varM",
                         label = NULL,
                         value = 1.0),
            
            helpText("Variance of Y variable"),
            numericInput(inputId = "varY",
                         label = NULL,
                         value = 1.0)
          )
        }
      })
  }
)